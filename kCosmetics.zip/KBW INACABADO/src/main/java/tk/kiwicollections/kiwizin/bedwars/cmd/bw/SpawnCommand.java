package tk.kiwicollections.kiwizin.bedwars.cmd.bw;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import tk.kiwicollections.kiwizin.bedwars.cmd.SubCommand;
import tk.kiwicollections.kiwizin.bedwars.game.AbstractBedWars;
import tk.kiwicollections.kiwizin.bedwars.game.BedWarsTeam;
import tk.slicecollections.maxteer.player.Profile;
import tk.slicecollections.maxteer.player.hotbar.Hotbar;
import tk.slicecollections.maxteer.plugin.config.MConfig;
import tk.slicecollections.maxteer.utils.BukkitUtils;

import java.util.HashMap;
import java.util.Map;

public class SpawnCommand extends SubCommand {

    public SpawnCommand() {
        super("spawn", "spawn", "Setar os spawns das ilhas.", true);
    }

    public static final Map<Player, Object[]> SETUPING = new HashMap<>();

    @Override
    public void perform(Player player, String[] args) {
        AbstractBedWars game = AbstractBedWars.getByWorldName(player.getWorld().getName());
        if (game == null) {
            player.sendMessage("§cNão existe uma sala neste mundo.");
            return;
        }
        if (game.listTeams().size() >= 8) {
            player.sendMessage("A sala já possui 8 spawns.");
            return;
        }
        player.setGameMode(GameMode.CREATIVE);
        Profile profile = Profile.getProfile(player.getName());
        profile.setHotbar(null);
        Inventory inv = player.getInventory();
        SETUPING.put(player, new Object[6]);
        inv.clear();
        inv.setItem(0, BukkitUtils.deserializeItemStack("BEACON : 1 : nome>&aSpawn"));
        inv.setItem(1, BukkitUtils.deserializeItemStack("GOLD_BLOCK : 1 : nome>&aGerador"));
        inv.setItem(2, BukkitUtils.deserializeItemStack("BED : 1 : nome>&aCama"));
        inv.setItem(3, BukkitUtils.deserializeItemStack("EMERALD : 1 : nome>&aItemShop"));
        inv.setItem(4, BukkitUtils.deserializeItemStack("ENCHANTMENT_TABLE : 1 : nome>&aUpgradeShop"));
        inv.setItem(6, BukkitUtils.deserializeItemStack("WOOL:" + BedWarsTeam.ids[game.listTeams().size()] + " : 1 : nome>&aTime: " + BedWarsTeam.names[game.listTeams().size()]));
        inv.setItem(7, BukkitUtils.deserializeItemStack("STAINED_CLAY:5 : 1 : nome>&aConfirmar"));
        inv.setItem(8, BukkitUtils.deserializeItemStack("STAINED_CLAY:14 : 1 : nome>&cCancelar"));
    }

    public static void handleClick(Profile profile, String display, PlayerInteractEvent evt) {
        Player player = profile.getPlayer();

        switch (display) {
            case "§aSpawn": {
                evt.setCancelled(true);
                Location location = player.getLocation().getBlock().getLocation().clone().add(0.5D, 0.0D, 0.5D);
                location.setYaw(player.getLocation().getYaw());
                location.setPitch(player.getLocation().getPitch());
                SETUPING.get(player)[1] = BukkitUtils.serializeLocation(location);
                player.sendMessage("§aSpawn setado.");
                break;
            }
            case "§aGerador": {
                evt.setCancelled(true);
                SETUPING.get(player)[2] = BukkitUtils.serializeLocation(player.getLocation().getBlock().getLocation().clone().add(0.5, 0, 0.5));
                player.sendMessage("§aGerador setado.");
                break;
            }
            case "§aCama": {
                evt.setCancelled(true);
                if (evt.getClickedBlock() != null && tk.kiwicollections.kiwizin.bedwars.utils.BukkitUtils.isBedBlock(evt.getClickedBlock())) {
                    SETUPING.get(player)[3] = BukkitUtils.serializeLocation(evt.getClickedBlock().getLocation());
                    player.sendMessage("§aCama setada.");
                } else {
                    player.sendMessage("§cClique em uma cama.");
                }
                break;
            }
            case "§aItemShop": {
                evt.setCancelled(true);
                Location location = player.getLocation().getBlock().getLocation().clone().add(0.5, 0.0, 0.5);
                location.setYaw(player.getLocation().getYaw());
                location.setPitch(player.getLocation().getPitch());
                SETUPING.get(player)[4] = BukkitUtils.serializeLocation(location);
                player.sendMessage("§aItemShop setada.");
                break;
            }
            case "§aUpgradeShop": {
                evt.setCancelled(true);
                Location location = player.getLocation().getBlock().getLocation().clone().add(0.5, 0.0, 0.5);
                location.setYaw(player.getLocation().getYaw());
                location.setPitch(player.getLocation().getPitch());
                SETUPING.get(player)[5] = BukkitUtils.serializeLocation(location);
                player.sendMessage("§aUpgradeShop setada.");
                break;
            }
            case "§aConfirmar": {
                evt.setCancelled(true);
                if (SETUPING.get(player)[1] == null) {
                    player.sendMessage("§cSpawn não setado.");
                    return;
                }
                if (SETUPING.get(player)[2] == null) {
                    player.sendMessage("§cGerador não setado.");
                    return;
                }
                if (SETUPING.get(player)[3] == null) {
                    player.sendMessage("§cCama não setada.");
                    return;
                }
                if (SETUPING.get(player)[4] == null) {
                    player.sendMessage("§cItem Shop não setado.");
                    return;
                }
                if (SETUPING.get(player)[5] == null) {
                    player.sendMessage("§cUpgrade Shop não setado.");
                    return;
                }
                AbstractBedWars game = AbstractBedWars.getByWorldName(player.getWorld().getName());
                game.getConfig().addTeam(SETUPING.get(player)[1], SETUPING.get(player)[3], SETUPING.get(player)[4], SETUPING.get(player)[5], SETUPING.get(player)[2]);
                player.sendMessage("§aSpawn adicionado.");
                SETUPING.get(player)[1] = null;
                SETUPING.get(player)[2] = null;
                SETUPING.get(player)[3] = null;
                SETUPING.get(player)[4] = null;
                SETUPING.get(player)[5] = null;
                if (game.listTeams().size() >= 8) {
                    SETUPING.remove(player);
                    profile.setHotbar(Hotbar.getHotbarById("lobby"));
                    profile.refresh();
                } else {
                    player.getInventory().setItem(6, BukkitUtils.deserializeItemStack("WOOL:" + BedWarsTeam.ids[game.listTeams().size()] + " : 1 : nome>&aTime: " + BedWarsTeam.names[game.listTeams().size()]));
                }
                break;
            }
            case "§cCancelar": {
                evt.setCancelled(true);
                profile.setHotbar(Hotbar.getHotbarById("lobby"));
                profile.refresh();
                SETUPING.remove(player);
            }
        }
    }

}
