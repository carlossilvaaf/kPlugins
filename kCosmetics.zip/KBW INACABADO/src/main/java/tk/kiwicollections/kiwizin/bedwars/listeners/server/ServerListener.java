package tk.kiwicollections.kiwizin.bedwars.listeners.server;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.LeavesDecayEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.weather.WeatherChangeEvent;
import tk.kiwicollections.kiwizin.bedwars.game.AbstractBedWars;
import tk.slicecollections.maxteer.game.GameState;

public class ServerListener implements Listener {

    @EventHandler
    public void onBlockIgnite(BlockIgniteEvent evt) {
        AbstractBedWars game = AbstractBedWars.getByWorldName(evt.getBlock().getWorld().getName());
        if (game == null) {
            evt.setCancelled(true);
        } else if (game.getState() != GameState.EMJOGO) {
            evt.setCancelled(true);
        }
    }

    @EventHandler
    public void onBlockBurn(BlockBurnEvent evt) {
        AbstractBedWars game = AbstractBedWars.getByWorldName(evt.getBlock().getWorld().getName());
        if (game == null) {
            evt.setCancelled(true);
        } else if (game.getState() != GameState.EMJOGO) {
            evt.setCancelled(true);
        }
    }

    @EventHandler
    public void onLeavesDecay(LeavesDecayEvent evt) {
        evt.setCancelled(true);
    }

    @EventHandler
    public void onEntityExplode(EntityExplodeEvent evt) {
        AbstractBedWars game = AbstractBedWars.getByWorldName(evt.getEntity().getWorld().getName());
        if (game == null) {
            evt.setCancelled(true);
        } else if (game.getState() != GameState.EMJOGO) {
            evt.setCancelled(true);
        }
    }

    @EventHandler
    public void onWeatherChange(WeatherChangeEvent evt) {
        evt.setCancelled(evt.toWeatherState());
    }
}
