package tk.kiwicollections.kiwizin.bedwars.api.event;

import org.bukkit.event.Cancellable;
import tk.kiwicollections.kiwizin.bedwars.api.BWEvent;
import tk.kiwicollections.kiwizin.bedwars.game.AbstractBedWars;
import tk.slicecollections.maxteer.game.Game;
import tk.slicecollections.maxteer.game.GameTeam;
import tk.slicecollections.maxteer.player.Profile;

public class BWPlayerDeathEvent extends BWEvent implements Cancellable {

    private boolean isCancelled;
    private Game<? extends GameTeam> game;
    private Profile profile, killer;

    public BWPlayerDeathEvent(AbstractBedWars game, Profile profile, Profile killer) {
        this.game = game;
        this.profile = profile;
        this.killer = killer;
    }

    @Override
    public void setCancelled(boolean isCancelled) {
        //this.isCancelled = isCancelled;
    }

    public Game<? extends GameTeam> getGame() {
        return this.game;
    }

    public Profile getProfile() {
        return this.profile;
    }

    public Profile getKiller() {
        return this.killer;
    }

    public boolean hasKiller() { return this.killer != null; }

    @Override
    public boolean isCancelled() {
        return this.isCancelled;
    }
}