package tk.kiwicollections.kiwizin.bedwars.cmd.bw;

import org.bukkit.entity.Player;
import tk.kiwicollections.kiwizin.bedwars.cmd.SubCommand;
import tk.kiwicollections.kiwizin.bedwars.game.AbstractBedWars;
import tk.slicecollections.maxteer.game.GameState;
import tk.slicecollections.maxteer.player.Profile;

public class StartCommand extends SubCommand {

    public StartCommand() {
        super("iniciar", "iniciar", "Iniciar a partida.", true);
    }

    @Override
    public void perform(Player player, String[] args) {
        Profile profile = Profile.getProfile(player.getName());
        if (profile != null) {
            AbstractBedWars game = profile.getGame(AbstractBedWars.class);
            if (game != null) {
                if (game.getState() == GameState.AGUARDANDO) {
                    game.start();
                    player.sendMessage("§aVocê iniciou a partida!");
                } else {
                    player.sendMessage("§cA partida já está em andamento.");
                }
            }
        }
    }
}