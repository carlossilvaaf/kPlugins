package tk.kiwicollections.kiwizin.bedwars.listeners.player;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import tk.kiwicollections.kiwizin.bedwars.Language;
import tk.kiwicollections.kiwizin.bedwars.game.AbstractBedWars;
import tk.kiwicollections.kiwizin.bedwars.game.BedWarsTeam;
import tk.slicecollections.maxteer.game.GameState;
import tk.slicecollections.maxteer.player.Profile;
import tk.slicecollections.maxteer.player.role.Role;
import tk.slicecollections.maxteer.utils.StringUtils;

public class AsyncPlayerChatListener implements Listener {

    private static final Map<String, Long> flood = new HashMap<>();

    private static final DecimalFormat df = new DecimalFormat("###.#");

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent evt) {
        flood.remove(evt.getPlayer().getName());
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void AsyncPlayerChat(AsyncPlayerChatEvent evt) {
        if (evt.isCancelled()) {
            return;
        }

        Player player = evt.getPlayer();
        if (!player.hasPermission("kbedwars.chat.delay")) {
            long start = flood.containsKey(player.getName()) ? flood.get(player.getName()) : 0;
            if (start > System.currentTimeMillis()) {
                double time = (start - System.currentTimeMillis()) / 1000.0;
                if (time > 0.1) {
                    evt.setCancelled(true);
                    String timeString = df.format(time).replace(",", ".");
                    if (timeString.endsWith("0")) {
                        timeString = timeString.substring(0, timeString.lastIndexOf("."));
                    }

                    player.sendMessage(Language.chat$delay.replace("{time}", timeString));
                    return;
                }
            }

            flood.put(player.getName(), System.currentTimeMillis() + TimeUnit.SECONDS.toMillis(3));
        }

        Role role = Role.getPlayerRole(player);
        if (player.hasPermission("kbedwars.chat.color")) {
            evt.setMessage(StringUtils.formatColors(evt.getMessage()));
        }

        Profile profile = Profile.getProfile(player.getName());
        AbstractBedWars game = profile.getGame(AbstractBedWars.class);
        if (game == null || !game.isSpectator(player)) {
            if (game == null) {
                evt.setFormat(
                        Language.chat$format$lobby.replace("{player}", role.getPrefix() + "%s").replace("{color}", role.isDefault() ? Language.chat$color$default : Language.chat$color$custom)
                                .replace("{message}", "%s"));
            } else {
                BedWarsTeam team = game.getTeam(player);
                if (team != null) {
                    if (game.getState() == GameState.AGUARDANDO) {
                        evt.setFormat(
                                Language.chat$format$lobby.replace("{player}", role.getPrefix() + "%s").replace("{color}", role.isDefault() ? Language.chat$color$default : Language.chat$color$custom)
                                        .replace("{message}", "%s"));
                    } else {
                        evt.setFormat(
                                Language.chat$format$ingame.replace("{team}", team.getTag()).replace("{player}", role.getPrefix() + "%s").replace("{color}", role.isDefault() ? Language.chat$color$default : Language.chat$color$custom)
                                        .replace("{message}", "%s"));
                    }
                }
            }
        } else {
            evt.setFormat(
                    Language.chat$format$spectator.replace("{player}", role.getPrefix() + "%s").replace("{color}", role.isDefault() ? Language.chat$color$default : Language.chat$color$custom)
                            .replace("{message}", "%s"));
        }
        evt.getRecipients().clear();
        for (Player players : player.getWorld().getPlayers()) {
            Profile profiles = Profile.getProfile(players.getName());
            if (profiles != null) {
                if (game == null) {
                    if (!profiles.playingGame()) {
                        evt.getRecipients().add(players);
                    }
                } else if (profiles.playingGame() && profiles.getGame().equals(game)) {
                    if (!game.isSpectator(player)) {
                        BedWarsTeam team = game.getTeam(player);
                        if (team != null) {
                            if (game.getState() == GameState.AGUARDANDO) {
                                evt.getRecipients().add(players);
                            } else {
                                if (team.getTeamSize() > 1) {
                                    List<Player> playerList = team.listPlayers();
                                    playerList.remove(player);
                                    playerList.forEach(playerListr -> evt.getRecipients().add(playerListr));
                                } else {
                                    evt.getRecipients().add(players);
                                }
                            }
                        }
                    } else if (game.isSpectator(players)) {
                        evt.getRecipients().add(players);
                    }
                }
            }
        }
    }
}
