package tk.kiwicollections.kiwizin.bedwars.nms.interfaces;

import org.bukkit.entity.Entity;

public interface BalloonEntity {
  
  void kill();

  Entity getBukkitEntity();
}
