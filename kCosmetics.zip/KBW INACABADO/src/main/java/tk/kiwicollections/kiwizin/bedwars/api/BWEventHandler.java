package tk.kiwicollections.kiwizin.bedwars.api;

import java.util.List;

public interface BWEventHandler {

    public void handleEvent(BWEvent evt);

    public List<Class<?>> getEventTypes();
}
