package tk.kiwicollections.kiwizin.bedwars.game.enums;

import tk.kiwicollections.kiwizin.bedwars.game.AbstractBedWars;
import tk.kiwicollections.kiwizin.bedwars.game.interfaces.LoadCallback;
import tk.kiwicollections.kiwizin.bedwars.game.types.NormalBedWars;
import tk.slicecollections.maxteer.reflection.Accessors;

public enum BedWarsMode {
    SOLO("Solo", "1v1", 1, NormalBedWars.class, 1),
    DUPLA("Duplas", "2v2", 2, NormalBedWars.class, 1);

    private int size;
    private String stats;
    private String name;
    private Class<? extends AbstractBedWars> gameClass;
    private int cosmeticIndex;

    BedWarsMode(String name, String stats, int size, Class<? extends AbstractBedWars> gameClass, int cosmeticIndex) {
        this.name = name;
        this.stats = stats;
        this.size = size;
        this.gameClass = gameClass;
        this.cosmeticIndex = cosmeticIndex;
    }

    public AbstractBedWars buildGame(String name, LoadCallback callback) {
        return Accessors.getConstructor(this.gameClass, String.class, LoadCallback.class).newInstance(name, callback);
    }

    public int getSize() {
        return this.size;
    }


    public String getStats() {
        return this.stats;
    }

    public String getName() {
        return this.name;
    }

    public int getCosmeticIndex() {
        return cosmeticIndex;
    }

    private static final BedWarsMode[] VALUES = values();

    public static BedWarsMode fromName(String name) {
        for (BedWarsMode mode : VALUES) {
            if (name.equalsIgnoreCase(mode.name())) {
                return mode;
            }
        }

        return null;
    }
}
