package tk.kiwicollections.kiwizin.bedwars;

import org.apache.commons.codec.language.bm.Lang;
import org.bukkit.Bukkit;
import tk.kiwicollections.kiwizin.bedwars.cmd.Commands;
import tk.kiwicollections.kiwizin.bedwars.cosmetics.Cosmetic;
import tk.kiwicollections.kiwizin.bedwars.game.AbstractBedWars;
import tk.kiwicollections.kiwizin.bedwars.game.BedWarsEvent;
import tk.kiwicollections.kiwizin.bedwars.hook.BWCoreHook;
import tk.kiwicollections.kiwizin.bedwars.listeners.Listeners;
import tk.kiwicollections.kiwizin.bedwars.lobby.DeliveryNPC;
import tk.kiwicollections.kiwizin.bedwars.lobby.Lobby;
import tk.kiwicollections.kiwizin.bedwars.lobby.PlayNPC;
import tk.slicecollections.maxteer.Core;
import tk.slicecollections.maxteer.deliveries.Delivery;
import tk.slicecollections.maxteer.libraries.MinecraftVersion;
import tk.slicecollections.maxteer.plugin.MPlugin;
import tk.slicecollections.maxteer.utils.BukkitUtils;

public class Main extends MPlugin {

    private static Main instance;
    private static boolean validInit;
    public static boolean mCosmetics, mLootChests;
    public static String currentServerName;

    @Override
    public void load() {}

    @Override
    public void start() {
        instance = this;
    }

    @Override
    public void enable() {
        if (MinecraftVersion.getCurrentVersion().getCompareId() != 183) {
            this.setEnabled(false);
            this.getLogger().warning("O plugin apenas funciona na versao 1_8_R3 (Atual: " + MinecraftVersion.getCurrentVersion().getVersion() + ")");
            return;
        }

        saveDefaultConfig();
        currentServerName = getConfig().getString("lobby");
        if (getConfig().getString("spawn") != null) {
            Core.setLobby(BukkitUtils.deserializeLocation(getConfig().getString("spawn")));
        }
        mCosmetics = Bukkit.getPluginManager().getPlugin("mCosmetics") != null;
        mLootChests = Bukkit.getPluginManager().getPlugin("mLootChests") != null;

        BWCoreHook.setupHook();
        Listeners.setupListeners();
        Language.setupLanguage();

        PlayNPC.setupNPCs();
        Cosmetic.setupCosmetics();
        Lobby.setupLobbies();

        DeliveryNPC.setupNPCs();
        AbstractBedWars.setupGames();
        Commands.setupCommands();

        validInit = true;
        this.getLogger().info("O plugin foi ativado.");
    }

    @Override
    public void disable() {

    }

    public static Main getInstance() {
        return instance;
    }

}
