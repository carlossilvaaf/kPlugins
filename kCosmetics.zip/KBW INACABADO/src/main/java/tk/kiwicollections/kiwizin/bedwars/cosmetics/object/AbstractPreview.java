package tk.kiwicollections.kiwizin.bedwars.cosmetics.object;

import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import tk.kiwicollections.kiwizin.bedwars.Main;
import tk.kiwicollections.kiwizin.bedwars.cosmetics.Cosmetic;
import tk.slicecollections.maxteer.player.Profile;
import tk.slicecollections.maxteer.plugin.config.MConfig;

public abstract class AbstractPreview<T extends Cosmetic> extends BukkitRunnable {

    protected Player player;
    protected T cosmetic;

    public AbstractPreview(Profile profile, T cosmetic) {
        this.player = profile.getPlayer();
        this.cosmetic = cosmetic;
    }

    public abstract void returnToMenu();

    public static final MConfig CONFIG = Main.getInstance().getConfig("previewLocations");

    public static boolean canDoKillEffect() {
        return CONFIG.getSection("killeffect") != null && CONFIG.getSection("killeffect").getKeys(false).size() > 2;
    }

    public static boolean canDoCage() {
        return CONFIG.getSection("cage") != null && CONFIG.getSection("cage").getKeys(false).size() > 1;
    }
}
