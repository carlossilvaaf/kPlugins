package tk.kiwicollections.kiwizin.bedwars.cmd.bw;

import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import tk.kiwicollections.kiwizin.bedwars.cmd.SubCommand;
import tk.kiwicollections.kiwizin.bedwars.cosmetics.Cosmetic;
import tk.kiwicollections.kiwizin.bedwars.hook.lootchests.LootChestsHook;
import tk.slicecollections.maxteer.player.Profile;

public class LootChestsCommand extends SubCommand {

    public LootChestsCommand() {
        super("lc", "lc sync", "Sincronizar cosméticos com o mLootChests.", false);
    }

    @Override
    public void perform(CommandSender sender, String[] args) {
        if (args.length == 0) {
            sender.sendMessage("§cUtilize /bw " + this.getUsage());
            return;
        }

        String action = args[0];
        if (action.equalsIgnoreCase("sync")) {
            sender.sendMessage("§aSincronizando cosméticos...");
            LootChestsHook.sync(sender);
        } else if ((!(sender instanceof Player)) && action.equalsIgnoreCase("give")) {
            if (args.length <= 2) {
                return;
            }

            Profile profile = Profile.getProfile(args[1]);
            if (profile == null) {
                return;
            }

            Cosmetic cosmetic = Cosmetic.findById(args[2]);
            if (cosmetic.has(profile)) {
                double coins = cosmetic.getCoins();
                if (coins <= 0) {
                    coins = 100;
                }
                coins /= 10;
                if (coins < 100) {
                    coins += 100;
                }
                profile.addCoins("mCoreBedWars", coins);
                profile.getPlayer().sendMessage("§aVocê recebeu §6" + coins + " Coins §apor já possuir " + cosmetic.getRarity().getTagged() + " " + cosmetic.getName() + "§a!");
            } else {
                cosmetic.give(profile);
                profile.getPlayer().sendMessage("§aVocê recebeu " + cosmetic.getRarity().getTagged() + " " + cosmetic.getName() + " §aatravés de uma Caixa de Saque!");
            }
        } else {
            sender.sendMessage("§cUtilize /bw " + this.getUsage());
        }
    }
}
