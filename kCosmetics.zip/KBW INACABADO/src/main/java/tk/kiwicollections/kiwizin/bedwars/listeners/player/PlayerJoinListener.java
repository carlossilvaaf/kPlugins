package tk.kiwicollections.kiwizin.bedwars.listeners.player;

import net.md_5.bungee.api.ChatColor;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import tk.kiwicollections.kiwizin.bedwars.Language;
import tk.kiwicollections.kiwizin.bedwars.Main;
import tk.kiwicollections.kiwizin.bedwars.hook.BWCoreHook;
import tk.kiwicollections.kiwizin.bedwars.hook.lootchests.LootChestsHook;
import tk.kiwicollections.kiwizin.bedwars.tagger.TagUtils;
import tk.slicecollections.maxteer.Core;
import tk.slicecollections.maxteer.nms.NMS;
import tk.slicecollections.maxteer.player.Profile;
import tk.slicecollections.maxteer.player.hotbar.Hotbar;
import tk.slicecollections.maxteer.player.role.Role;
import tk.slicecollections.maxteer.titles.TitleManager;
import tk.slicecollections.maxteer.utils.enums.EnumSound;

public class PlayerJoinListener implements Listener {

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent evt) {
        evt.setJoinMessage(null);

        Player player = evt.getPlayer();
        TagUtils.sendTeams(player);

        Profile profile = Profile.getProfile(player.getName());
        BWCoreHook.reloadScoreboard(profile);
        profile.setHotbar(Hotbar.getHotbarById("lobby"));
        profile.refresh();

        Bukkit.getScheduler().runTaskLaterAsynchronously(Main.getInstance(), () -> {
            TagUtils.setTag(evt.getPlayer());
            if (Role.getPlayerRole(player).isBroadcast()) {
                String broadcast = Language.lobby$broadcast
                        .replace("{player}", Role.getPrefixed(player.getName()));
                Profile.listProfiles().forEach(pf -> {
                    if (!pf.playingGame()) {
                        Player players = pf.getPlayer();
                        if (players != null) {
                            players.sendMessage(broadcast);
                        }
                    }
                });
            }
        }, 5);

        Bukkit.getScheduler().runTaskLaterAsynchronously(Core.getInstance(), () -> {
            TitleManager.joinLobby(profile);
        }, 10);

        NMS.sendTitle(player, "", "", 0, 1, 0);
        if (Language.lobby$tab$enabled) {
            NMS.sendTabHeaderFooter(player, Language.lobby$tab$header, Language.lobby$tab$footer);
        }

        if (player.hasPermission("kbedwars.cmd.bedwars")) {
            if (Main.mLootChests) {
                if (LootChestsHook.isUnsynced()) {
                    TextComponent component = new TextComponent("");
                    for (BaseComponent components : TextComponent
                            .fromLegacyText(
                                    " \n §6§lLOOT CHESTS\n \n §7O kBedWars aparentemente não está sincronizado com o mLootChests, para prosseguir basta clicar ")) {
                        component.addExtra(components);
                    }
                    TextComponent click = new TextComponent("AQUI");
                    click.setColor(ChatColor.GREEN);
                    click.setBold(true);
                    click.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/sw lc sync"));
                    click.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, TextComponent
                            .fromLegacyText("§7Clique aqui para sincronizar o kBedWars com o mLootChests.")));
                    component.addExtra(click);
                    for (BaseComponent components : TextComponent.fromLegacyText("§7.\n ")) {
                        component.addExtra(components);
                    }

                    player.spigot().sendMessage(component);
                    EnumSound.ORB_PICKUP.play(player, 1.0F, 1.0F);
                }
            }
        }
    }
}
