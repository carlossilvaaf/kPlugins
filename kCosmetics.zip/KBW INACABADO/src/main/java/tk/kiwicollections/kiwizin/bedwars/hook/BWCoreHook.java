package tk.kiwicollections.kiwizin.bedwars.hook;

import com.comphenix.protocol.ProtocolLibrary;
import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import tk.kiwicollections.kiwizin.bedwars.Language;
import tk.kiwicollections.kiwizin.bedwars.Main;
import tk.kiwicollections.kiwizin.bedwars.game.AbstractBedWars;
import tk.kiwicollections.kiwizin.bedwars.game.BedWarsTeam;
import tk.kiwicollections.kiwizin.bedwars.hook.hotbar.BWHotbarActionType;
import tk.kiwicollections.kiwizin.bedwars.hook.protocollib.HologramAdapter;
import tk.slicecollections.maxteer.Core;
import tk.slicecollections.maxteer.achievements.Achievement;
import tk.slicecollections.maxteer.achievements.types.BedWarsAchievement;
import tk.slicecollections.maxteer.game.GameState;
import tk.slicecollections.maxteer.player.Profile;
import tk.slicecollections.maxteer.player.hotbar.Hotbar;
import tk.slicecollections.maxteer.player.hotbar.HotbarAction;
import tk.slicecollections.maxteer.player.hotbar.HotbarActionType;
import tk.slicecollections.maxteer.player.hotbar.HotbarButton;
import tk.slicecollections.maxteer.player.scoreboard.MScoreboard;
import tk.slicecollections.maxteer.player.scoreboard.scroller.ScoreboardScroller;
import tk.slicecollections.maxteer.plugin.config.MConfig;
import tk.slicecollections.maxteer.utils.StringUtils;

import java.util.List;
import java.util.logging.Level;

public class BWCoreHook {

    public static void setupHook() {
        Core.minigame = "Bed Wars";

        setupHotbars();
        new BukkitRunnable() {
            @Override
            public void run() {
                Profile.listProfiles().forEach(profile -> {
                    if (profile.getScoreboard() != null) {
                        profile.getScoreboard().scroll();
                    }
                });
            }
        }.runTaskTimerAsynchronously(Main.getInstance(), 0, Language.scoreboards$scroller$every_tick);

        new BukkitRunnable() {
            @Override
            public void run() {
                Profile.listProfiles().forEach(profile -> {
                    if (!profile.playingGame() && profile.getScoreboard() != null) {
                        profile.update();
                    }
                });
            }
        }.runTaskTimerAsynchronously(Main.getInstance(), 0, 20);

        ProtocolLibrary.getProtocolManager().addPacketListener(new HologramAdapter());
    }

    public static void checkAchievements(Profile profile) {
        Bukkit.getScheduler().runTaskAsynchronously(Main.getInstance(), () -> {
            Achievement.listAchievements(BedWarsAchievement.class).stream().filter(bwa -> bwa.canComplete(profile)).forEach(bwa -> {
                bwa.complete(profile);
                profile.getPlayer().sendMessage(Language.lobby$achievement.replace("{name}", bwa.getName()));
            });
        });
    }


    public static void reloadScoreboard(Profile profile) {
        if (!profile.playingGame()) {
            checkAchievements(profile);
        }
        Player player = profile.getPlayer();
        AbstractBedWars game = profile.getGame(AbstractBedWars.class);
        List<String> lines = game == null ?
                Language.scoreboards$lobby :
                game.getState() == GameState.AGUARDANDO ?
                        Language.scoreboards$waiting : Language.scoreboards$ingame;
        profile.setScoreboard(new MScoreboard() {
            @Override
            public void update() {
                for (int index = 0; index < Math.min(lines.size(), 15); index++) {
                    String line = lines.get(index);
                    if (game != null) {
                        int var13 = 0;
                        String[] var16;
                        int var8 = (var16 = new String[]{"red", "blue", "green", "yellow", "aqua", "white", "pink", "gray"}).length;

                        for(int var14 = 0; var14 < var8; ++var14) {
                            String var6 = var16[var14];
                            if (line.equals("{" + var6 + "}")) {
                                BedWarsTeam team = game.listTeams().size() > var13 ? game.listTeams().get(var13) : null;
                                if (team != null) {
                                    String name = StringUtils.stripColors(team.getName());
                                    line = game.getTeamAlpha(team, true) + (team.isAlive() ? "§8" : "§f") + " " + name + " " + (team.bed() ? "§c§l✖ " : "§a§l✔ ") + (team.hasMember(player) ? "§e*" : "");
                                    break;
                                }

                                line = "removethatline";
                            } else {
                                ++var13;
                            }
                        }
                        line = line.replace("{next_event}", game.getEvent()).replace("{alive}", StringUtils.formatNumber(game.listTeams().stream().filter(BedWarsTeam::isAlive).count()));
                    } else {
                        line = PlaceholderAPI.setPlaceholders(player, line);
                    }

                    if (line.equals("removethatline")) {
                        continue;
                    }
                    this.add(15 - index, line);
                }
            }
        }.scroller(new ScoreboardScroller(Language.scoreboards$scroller$titles)).to(player).build());
        if (game != null && game.getState() != GameState.AGUARDANDO) {
            profile.getScoreboard().health().updateHealth();
        }


        profile.update();
        profile.getScoreboard().scroll();
    }

    private static void setupHotbars() {
        HotbarActionType.addActionType("bedwars", new BWHotbarActionType());

        MConfig config = Main.getInstance().getConfig("hotbar");
        for (String id : new String[] {"lobby", "waiting", "spectator"}) {
            Hotbar hotbar = new Hotbar(id);

            ConfigurationSection hb = config.getSection(id);
            for (String button : hb.getKeys(false)) {
                try {
                    hotbar.getButtons().add(new HotbarButton(hb.getInt(button + ".slot"), new HotbarAction(hb.getString(button + ".execute")), hb.getString(button + ".icon")));
                } catch (Exception ex) {
                    Main.getInstance().getLogger().log(Level.WARNING, "Falha ao carregar o botao \"" + button + "\" da hotbar \"" + id + "\": ", ex);
                }
            }

            Hotbar.addHotbar(hotbar);
        }
    }
}
