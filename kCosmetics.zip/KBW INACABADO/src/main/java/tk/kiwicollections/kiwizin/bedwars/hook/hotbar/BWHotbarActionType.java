package tk.kiwicollections.kiwizin.bedwars.hook.hotbar;

import tk.kiwicollections.kiwizin.bedwars.game.AbstractBedWars;
import tk.kiwicollections.kiwizin.bedwars.menus.MenuLobbies;
import tk.kiwicollections.kiwizin.bedwars.menus.MenuPlay;
import tk.kiwicollections.kiwizin.bedwars.menus.MenuShop;
import tk.slicecollections.maxteer.player.Profile;
import tk.slicecollections.maxteer.player.hotbar.HotbarActionType;

public class BWHotbarActionType extends HotbarActionType {

    @Override
    public void execute(Profile profile, String action) {
        if (action.equalsIgnoreCase("loja")) {
            new MenuShop(profile);
        } else if (action.equalsIgnoreCase("lobbies")) {
            new MenuLobbies(profile);
        } else if (action.equalsIgnoreCase("espectar")) {
          /*  AbstractSkyWars game = profile.getGame(AbstractSkyWars.class);
            if (game != null) {
                new MenuSpectator(profile.getPlayer(), game);
            }

           */
        } else if (action.equalsIgnoreCase("jogar")) {
            AbstractBedWars game = profile.getGame(AbstractBedWars.class);
            if (game != null) {
                new MenuPlay(profile, game.getMode());
            }
        } else if (action.equalsIgnoreCase("sair")) {
            AbstractBedWars game = profile.getGame(AbstractBedWars.class);
            if (game != null) {
                game.leave(profile, null);
            }
        }
    }
}
