package tk.kiwicollections.kiwizin.bedwars.game.events;

import tk.kiwicollections.kiwizin.bedwars.Language;
import tk.kiwicollections.kiwizin.bedwars.game.AbstractBedWars;
import tk.kiwicollections.kiwizin.bedwars.game.BedWarsEvent;
import tk.kiwicollections.kiwizin.bedwars.game.BedWarsTeam;

public class BedWarsDeathMatchEvent extends BedWarsEvent {
    @Override
    public void execute(AbstractBedWars game) {
        game.listPlayers().forEach(player -> player.sendMessage("\n§aTodas as camas foram destruidas!\n"));
        game.listTeams().forEach(BedWarsTeam::breakBed);
    }

    @Override
    public String getName() {
        return Language.options$events$death_match;
    }
}
