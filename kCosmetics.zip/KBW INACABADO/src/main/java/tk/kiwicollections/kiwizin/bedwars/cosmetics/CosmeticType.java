package tk.kiwicollections.kiwizin.bedwars.cosmetics;

public enum CosmeticType {
    KIT("Kit"),
    PERK("Habilidade"),
    KILL_EFFECT("Efeitos de Abate"),
    CAGE("Jaulas"),
    DEATH_CRY("Gritos de Morte"),
    BALLOON("Balões"),
    SHOPKEEPERSKINS("Skins dos Vendedores"),
    WIN_ANIMATION("Comemorações de Vitória");

    private String[] names;

    CosmeticType(String... names) {
        this.names = names;
    }

    public String getName(long index) {
        return this.names[(int) (index - 1)];
    }
}
