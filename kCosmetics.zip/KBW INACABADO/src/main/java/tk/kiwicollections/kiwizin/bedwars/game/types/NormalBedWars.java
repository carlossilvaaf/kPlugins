package tk.kiwicollections.kiwizin.bedwars.game.types;

import tk.kiwicollections.kiwizin.bedwars.game.AbstractBedWars;
import tk.kiwicollections.kiwizin.bedwars.game.interfaces.LoadCallback;

public class NormalBedWars extends AbstractBedWars {

    public NormalBedWars(String name, LoadCallback callback) {
        super(name, callback);
    }
}
