package tk.kiwicollections.kiwizin.bedwars.game.object;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.block.Block;
import org.bukkit.craftbukkit.v1_8_R3.CraftServer;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import tk.kiwicollections.kiwizin.bedwars.Main;
import tk.kiwicollections.kiwizin.bedwars.game.AbstractBedWars;
import tk.kiwicollections.kiwizin.bedwars.game.BedWarsTeam;
import tk.kiwicollections.kiwizin.bedwars.game.enums.BedWarsMode;
import tk.kiwicollections.kiwizin.bedwars.game.enums.GeneratorType;
import tk.slicecollections.maxteer.plugin.config.MConfig;
import tk.slicecollections.maxteer.utils.BukkitUtils;
import tk.slicecollections.maxteer.utils.CubeID;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static tk.kiwicollections.kiwizin.bedwars.utils.VoidChunkGenerator.VOID_CHUNK_GENERATOR;

public class BedWarsConfig {

    private AbstractBedWars game;
    private MConfig config;

    private String yaml;
    private World world;
    private String name;
    private BedWarsMode mode;
    private List<BedWarsTeam> teams;
    private List<String> balloons;
    private List<String> shops;
    private List<String> generators;
    private List<BedWarsGenerator> gameGenerators;
    private List<BedWarsTeamGenerator> gameTeamGenerators;
    private List<String> teamGenerators;
    private CubeID cubeId;
    private int minPlayers;

    public BedWarsConfig(AbstractBedWars game) {
        this.game = game;
        this.yaml = game.getGameName();
        this.config = Main.getInstance().getConfig("arenas", this.yaml);
        this.name = this.config.getString("name");
        this.mode = BedWarsMode.fromName(this.config.getString("mode"));
        this.minPlayers = config.getInt("minPlayers");
        this.cubeId = new CubeID(config.getString("cubeId"));
        this.teams = new ArrayList<>();
        this.gameGenerators = new ArrayList<>();
        if (!this.config.contains("balloons")) {
            this.config.set("balloons", new ArrayList<>());
        }
        this.balloons = this.config.getStringList("balloons");
        this.shops = this.config.getStringList("shops");
        this.generators = this.config.getStringList("generators");
        this.teamGenerators = this.config.getStringList("teamgenerators");
        this.gameGenerators = new ArrayList<>();
        this.gameTeamGenerators = new ArrayList<>();
        this.reload(null);
    }

    public void setupGenerators() {
        this.config.getStringList("generators").forEach(generator -> {
            gameGenerators
                    .add(new BedWarsGenerator(GeneratorType.fromName(generator.split(" : ")[1]), BukkitUtils.deserializeLocation(generator.split(" : ")[0])));

        });
    }

    public void setupSpawns() {
        this.config.getStringList("spawns").forEach(spawn -> {
            String[] a = this.config.getStringList("shops").get(this.teams.size()).split(" : ");
            String item = a[0];
            String upgrade = a[1];
            this.teams.add(new BedWarsTeam(this.game, spawn.split(" : ")[0], spawn.split(" : ")[1], this.mode.getSize(), item, upgrade));
        });
    }

    public void setupTeamGenerators() {
        this.config.getStringList("teamgenerators").forEach(generator -> gameTeamGenerators.add(new BedWarsTeamGenerator(this.teams.get(gameTeamGenerators.size()), generator)));
    }

    public void destroy() {
        if ((this.world = Bukkit.getWorld(this.yaml)) != null) {
            Bukkit.unloadWorld(this.world, false);
        }

        Main.getInstance().getFileUtils().deleteFile(new File(this.yaml));
        this.game = null;
        this.yaml = null;
        this.name = null;
        this.mode = null;
        this.teams.clear();
        this.teams = null;
        this.cubeId = null;
        this.world = null;
        this.config = null;
    }

    public void addGenerator(Location location, GeneratorType type) {
        this.generators.add(BukkitUtils.serializeLocation(location) + " : " + type.name());
        this.config.set("generators", generators);
        this.gameGenerators.add(new BedWarsGenerator(type, location));
    }

    public void addTeamGenerator(String location) {
        this.teamGenerators.add(location);
        this.config.set("teamgenerators", teamGenerators);
    }

    public void addShop(String typed) {
        this.shops.add(typed);
        this.config.set("shops", shops);
    }

    public void addSpawn(String location, String bed) {
        List<String> spawns = this.config.getStringList("spawns");
        spawns.add(location + " : " + bed);
        this.config.set("spawns", spawns);
    }

    public void addTeam(Object spawn, Object bed, Object shopLoc, Object upgradeLoc, Object generatorLoc) {
        addTeamGenerator((String) generatorLoc);
        addShop((String) shopLoc + " : " + upgradeLoc);
        addSpawn((String) spawn, (String) bed);
        this.teams.add(new BedWarsTeam(this.game, (String) spawn, (String) bed, this.mode.getSize(), (String) shopLoc, (String) upgradeLoc));
    }

    public void reload(final Runnable async) {
        File file = new File("plugins/kBedWars/mundos/" + this.yaml);
        if (Bukkit.getWorld(file.getName()) != null) {
            Bukkit.unloadWorld(file.getName(), false);
        }

        Runnable delete = () -> {
            Main.getInstance().getFileUtils().deleteFile(new File(file.getName()));
            Main.getInstance().getFileUtils().copyFiles(file, new File(file.getName()));

            Runnable newWorld = () -> {
                WorldCreator wc = WorldCreator.name(file.getName());
                wc.generator(VOID_CHUNK_GENERATOR);
                wc.generateStructures(false);
                this.world = wc.createWorld();
                this.world.setTime(0L);
                this.world.setStorm(false);
                this.world.setThundering(false);
                this.world.setAutoSave(false);
                this.world.setAnimalSpawnLimit(0);
                this.world.setWaterAnimalSpawnLimit(0);
                this.world.setKeepSpawnInMemory(false);
                this.world.setGameRuleValue("doMobSpawning", "false");
                this.world.setGameRuleValue("doDaylightCycle", "false");
                this.world.setGameRuleValue("mobGriefing", "false");
                this.world.getEntities().stream().filter(entity -> !(entity instanceof Player)).forEach(Entity::remove);
                if (async != null) {
                    async.run();
                }
            };

            if (async == null) {
                newWorld.run();
                return;
            }

            Bukkit.getScheduler().runTask(Main.getInstance(), newWorld);
        };

        if (async == null) {
            delete.run();
            return;
        }

        Bukkit.getScheduler().runTaskAsynchronously(Main.getInstance(), delete);
    }

    public void addBalloon(String balloon) {
        this.balloons.add(balloon);
        this.config.set("balloons", this.balloons);
    }

    public World getWorld() {
        return this.world;
    }

    public MConfig getConfig() {
        return this.config;
    }

    public String getMapName() {
        return this.name;
    }

    public BedWarsMode getMode() {
        return this.mode;
    }

    public List<BedWarsGenerator> listGenerators() {
        return this.gameGenerators;
    }

    public List<BedWarsTeamGenerator> listTeamGenerators() {
        return this.gameTeamGenerators;
    }

    public List<BedWarsTeam> listTeams() {
        return this.teams;
    }

    public List<String> listBalloons() {
        return this.balloons;
    }

    public String getBalloonLocation(int teamIndex) {
        return teamIndex >= this.balloons.size() ? null : this.balloons.get(teamIndex);
    }

    public CubeID getCubeId() {
        return this.cubeId;
    }

    public int getMinPlayers() {
        return minPlayers;
    }
}
