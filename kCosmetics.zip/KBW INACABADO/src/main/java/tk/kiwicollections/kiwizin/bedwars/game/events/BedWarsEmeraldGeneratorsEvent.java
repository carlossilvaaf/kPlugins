package tk.kiwicollections.kiwizin.bedwars.game.events;

import tk.kiwicollections.kiwizin.bedwars.Language;
import tk.kiwicollections.kiwizin.bedwars.game.AbstractBedWars;
import tk.kiwicollections.kiwizin.bedwars.game.BedWarsEvent;
import tk.kiwicollections.kiwizin.bedwars.game.enums.GeneratorType;

public class BedWarsEmeraldGeneratorsEvent extends BedWarsEvent {

    @Override
    public void execute(AbstractBedWars game) {
        game.listGenerators().stream()
                .filter(generator -> generator.getType() == GeneratorType.EMERALD)
                .forEach(generator -> generator.upgrade());
    }

    @Override
    public String getName() {
        return Language.options$events$emerald;
    }
}
