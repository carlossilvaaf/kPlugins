package tk.kiwicollections.kiwizin.bedwars.game;


import tk.kiwicollections.kiwizin.bedwars.Language;
import tk.kiwicollections.kiwizin.bedwars.Main;
import tk.kiwicollections.kiwizin.bedwars.game.events.BedWarsDeathMatchEvent;
import tk.kiwicollections.kiwizin.bedwars.game.events.BedWarsDiamondGeneratorsEvent;
import tk.kiwicollections.kiwizin.bedwars.game.events.BedWarsEmeraldGeneratorsEvent;
import tk.slicecollections.maxteer.plugin.logger.MLogger;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Level;

public abstract class BedWarsEvent {

    public abstract void execute(AbstractBedWars game);

    public abstract String getName();

    private static BedWarsEvent DEATHMATCH_EVENT, DIAMOND_EVENT, EMERALD_EVENT;
    public static final Map<Integer, BedWarsEvent> GERAL = new LinkedHashMap<>();
    public static MLogger LOGGER = ((MLogger) Main.getInstance().getLogger()).getModule("EVENTS");

    public static void setupEvents() {
        DEATHMATCH_EVENT = new BedWarsDeathMatchEvent();
        DIAMOND_EVENT = new BedWarsDiamondGeneratorsEvent();
        EMERALD_EVENT = new BedWarsEmeraldGeneratorsEvent();
        for (String evt : Language.options$events$timings) {
            Object[] event = parseEvent(evt);
            if (event == null) {
                LOGGER.log(Level.WARNING, "O evento \"" + evt + "\" nao e valido");
                continue;
            }

            GERAL.put((int) event[0], (BedWarsEvent) event[1]);
        }
    }

    private static Object[] parseEvent(String evt) {
        String[] splitter = evt.split(":");
        if (splitter.length <= 1) {
            return null;
        }

        int time = 0;
        try {
            if (splitter[1].startsWith("-")) {
                throw new Exception();
            }
            time = Integer.parseInt(splitter[1]);
        } catch (Exception ex) {
            return null;
        }

        String eventName = splitter[0];
        if (eventName.equalsIgnoreCase("deathmatch")) {
            return new Object[] {time, DEATHMATCH_EVENT};
        } else if (eventName.equalsIgnoreCase("diamond")) {
            return new Object[] {time, DIAMOND_EVENT};
        } else if (eventName.equalsIgnoreCase("emerald")) {
            return new Object[] {time, EMERALD_EVENT};
        }

        return null;
    }
}