package tk.kiwicollections.kiwizin.bedwars.game.enums;

import tk.kiwicollections.kiwizin.bedwars.Language;
import tk.slicecollections.maxteer.utils.StringUtils;

public enum GeneratorLevel {
    I(30, 60),
    II(20, 40),
    III(10, 20);

    private int diamond;
    private int emerald;

    GeneratorLevel(int diamond, int emerald) {
        this.diamond = diamond;
        this.emerald = emerald;
    }

    public static void translate() {
        I.diamond = Language.enum$generatorlevel$1_diamond;
        I.emerald = Language.enum$generatorlevel$1_emerald;
        II.diamond = Language.enum$generatorlevel$2_diamond;
        II.emerald = Language.enum$generatorlevel$2_emerald;
        III.diamond = Language.enum$generatorlevel$3_diamond;
        III.emerald = Language.enum$generatorlevel$3_emerald;
    }

    public int getDiamond() {
        return diamond;
    }

    public int getEmerald() {
        return emerald;
    }

    public static GeneratorLevel getFromInt(int level) {
        for (GeneratorLevel l : values()) {
            if (l.name().equals(StringUtils.repeat("I", level))) {
                return l;
            }
        }

        return null;
    }
}