package tk.kiwicollections.kiwizin.bedwars.game;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.BlockState;
import org.bukkit.entity.EntityType;
import org.bukkit.inventory.ItemStack;
import tk.kiwicollections.kiwizin.bedwars.Language;
import tk.kiwicollections.kiwizin.bedwars.Main;
import tk.kiwicollections.kiwizin.bedwars.container.SelectedContainer;
import tk.kiwicollections.kiwizin.bedwars.cosmetics.CosmeticType;
import tk.kiwicollections.kiwizin.bedwars.cosmetics.types.Cage;
import tk.kiwicollections.kiwizin.bedwars.cosmetics.types.ShopkeeperSkin;
import tk.kiwicollections.kiwizin.bedwars.lobby.trait.NPCSkinTrait;
import tk.slicecollections.maxteer.game.GameTeam;
import tk.slicecollections.maxteer.libraries.holograms.HologramLibrary;
import tk.slicecollections.maxteer.libraries.holograms.api.Hologram;
import tk.slicecollections.maxteer.libraries.npclib.NPCLibrary;
import tk.slicecollections.maxteer.libraries.npclib.api.npc.NPC;
import tk.slicecollections.maxteer.player.Profile;
import tk.slicecollections.maxteer.plugin.config.MConfig;
import tk.slicecollections.maxteer.utils.BukkitUtils;
import tk.slicecollections.maxteer.utils.StringUtils;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;

public class BedWarsTeam extends GameTeam {

    private final String name;
    private boolean breakBed;
    private Hologram hologramItem;
    private Hologram hologramUpgrade;
    private String bed, item, upgrade;
    public static final String[] names =
            {"§cVermelho", "§dRosa", "§bCiano", "§9Azul", "§fBranco", "§6Laranja", "§5Roxo", "§2Verde"};
    private static final Map<String, String> tags = new HashMap<>();
    public static final String[] ids = {"14", "6", "9", "11", "0", "1", "10", "13"};

    public BedWarsTeam(AbstractBedWars game, String location, String bed, int size, String item, String upgrade) {
        super(game, location, size);
        this.bed = bed;
        this.item = item;
        this.upgrade = upgrade;
        this.name = names[game.listTeams().size()];
        this.removeBed();
        this.spawnBed();
    }

    private NPC npcItem;
    private NPC npcUpgrade;

    public void breakBed() {
        this.breakBed = true;

        Location var1 = BukkitUtils.deserializeLocation(this.bed);
        var1.getBlock().breakNaturally(new ItemStack(Material.AIR));
    }


    private String bed1, bed2;
    private byte data1, data2;

    @SuppressWarnings("deprecation")
    public void removeBed() {
        Location loc = BukkitUtils.deserializeLocation(bed);
        if (!loc.getChunk().isLoaded()) {
            loc.getChunk().load(true);
        }

        Block teamBed = BukkitUtils.deserializeLocation(bed).getBlock();
        Block neighbor = tk.kiwicollections.kiwizin.bedwars.utils.BukkitUtils.getBedNeighbor(teamBed);
        this.data1 = teamBed.getData();
        this.data2 = neighbor.getData();
        teamBed.setType(Material.AIR);
        neighbor.setType(Material.AIR);

        this.bed1 = BukkitUtils.serializeLocation(teamBed.getLocation());
        this.bed2 = BukkitUtils.serializeLocation(neighbor.getLocation());
    }

    @SuppressWarnings("deprecation")
    public void spawnBed() {
        Location loc = BukkitUtils.deserializeLocation(bed);
        if (!loc.getChunk().isLoaded()) {
            loc.getChunk().load(true);
        }

        Block teamBed = BukkitUtils.deserializeLocation(bed1).getBlock();
        Block neighbor = BukkitUtils.deserializeLocation(bed2).getBlock();
        teamBed.setTypeIdAndData(Material.BED_BLOCK.getId(), data1, true);
        neighbor.setTypeIdAndData(Material.BED_BLOCK.getId(), data2, true);
    }

    public String getName() {
        return this.name;
    }

    public String getTag() {
        return StringUtils.getFirstColor(this.name) + "[" + this.name + "]";
    }

    public boolean bed() {
        return this.breakBed;
    }

    @Override
    public void reset() {
        this.breakBed = false;
        this.spawnBed();
        if (npcUpgrade != null) {
            npcUpgrade.destroy();
            npcUpgrade = null;
        }
        if (npcItem != null) {
            npcItem.destroy();
            npcItem = null;
        }
        if (this.hologramItem != null) {
            HologramLibrary.removeHologram(this.hologramItem);
            this.hologramItem = null;
        }
        if (this.hologramUpgrade != null) {
            HologramLibrary.removeHologram(this.hologramUpgrade);
            this.hologramUpgrade= null;
        }
    }

    public boolean isBed(Block var1) {
        Block var2 = BukkitUtils.deserializeLocation(this.bed).getBlock();
        Block var3 = tk.kiwicollections.kiwizin.bedwars.utils.BukkitUtils.getBedNeighbor(var2);
        return var3.equals(var1) || var2.equals(var1);
    }

    public void spawn() {
        if (this.isAlive()) {
            ShopkeeperSkin skin = null;
            List<Profile> profiles = this.listPlayers().stream().map(player -> Profile.getProfile(player.getName()))
                    .filter(profile -> profile.getAbstractContainer("mCoreBedWars", "selected", SelectedContainer.class).getSelected(CosmeticType.SHOPKEEPERSKINS, ShopkeeperSkin.class) != null)
                    .collect(Collectors.toList());
            if (profiles.size() > 0) {
                skin = profiles.get(ThreadLocalRandom.current().nextInt(profiles.size())).getAbstractContainer("mCoreBedWars", "selected", SelectedContainer.class)
                        .getSelected(CosmeticType.SHOPKEEPERSKINS, ShopkeeperSkin.class);
            }
            if (this.hologramUpgrade != null) {
                hologramUpgrade.despawn();
                hologramUpgrade = null;
            }
            if (this.hologramItem != null) {
                hologramItem.despawn();
                hologramItem = null;
            }
            Location item = BukkitUtils.deserializeLocation(this.item);
            Location upgrade = BukkitUtils.deserializeLocation(this.upgrade);
            this.npcItem = NPCLibrary.createNPC(EntityType.PLAYER, "§8[NPC] ");
            this.npcUpgrade = NPCLibrary.createNPC(EntityType.PLAYER, "§8[NPC] ");
            this.npcItem.data().set("upgrade-npc", true);
            this.npcUpgrade.data().set("item-npc", true);
            this.npcUpgrade.data().set(NPC.HIDE_BY_TEAMS_KEY, true);
            this.npcItem.data().set(NPC.HIDE_BY_TEAMS_KEY, true);
            if (skin == null || skin.getId() == 0) {
                MConfig df = Main.getInstance().getConfig("cosmetics", "shopkeeperskins");
                this.npcItem.addTrait(new NPCSkinTrait(this.npcItem, df.getString("default.value"), df.getString("default.signature")));
                this.npcUpgrade.addTrait(new NPCSkinTrait(this.npcUpgrade, df.getString("default.value"), df.getString("default.signature")));
            } else if (skin.copyPlayerSkin()) {
                this.npcUpgrade.data().set(NPC.COPY_PLAYER_SKIN, true);
                this.npcItem.data().set(NPC.COPY_PLAYER_SKIN, true);
            } else {
                this.npcItem.addTrait(new NPCSkinTrait(this.npcItem, skin.getValue(), skin.getSignature()));
                this.npcUpgrade.addTrait(new NPCSkinTrait(this.npcUpgrade, skin.getValue(), skin.getSignature()));
            }
            this.hologramItem = HologramLibrary.createHologram(item.clone().add(0, 0.5, 0), Arrays.asList("§b§lITEMS", "§b§lLOJA DE"));
            this.hologramUpgrade = HologramLibrary.createHologram(upgrade.clone().add(0, 0.5, 0), Arrays.asList("§b§lMELHORIAS", "§b§lLOJA DE"));
            this.npcItem.spawn(item);
            this.npcUpgrade.spawn(upgrade);
        }
    }

    public void startGame() {
        this.breakCage();
        if (!this.isAlive()) {
            this.breakBed();
        }
        this.spawn();
    }

    public void buildCage(/*Cage cage*/) {
       /* if (cage == null || this.getTeamSize() > 1) {
            Cage.applyCage(this.getLocation().clone().add(0, -1, 0), this.getTeamSize() > 1);
            return;
        }

        cage.apply(this.getLocation().clone().add(0, -1, 0));

        */
        Cage.applyCage(this.getLocation().clone().add(0, -1, 0), this.getTeamSize() > 1);
    }

    public void breakCage() {
        Cage.destroyCage(this.getLocation().clone().add(0, -1, 0));
    }

}
