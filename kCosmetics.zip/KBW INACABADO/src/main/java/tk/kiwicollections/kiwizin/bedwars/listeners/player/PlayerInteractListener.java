package tk.kiwicollections.kiwizin.bedwars.listeners.player;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import tk.kiwicollections.kiwizin.bedwars.cmd.bw.BuildCommand;
import tk.kiwicollections.kiwizin.bedwars.cmd.bw.CreateCommand;
import tk.kiwicollections.kiwizin.bedwars.cmd.bw.SpawnCommand;
import tk.kiwicollections.kiwizin.bedwars.game.AbstractBedWars;
import tk.kiwicollections.kiwizin.bedwars.game.enums.BedWarsMode;
import tk.kiwicollections.kiwizin.bedwars.menus.MenuPlay;
import tk.slicecollections.maxteer.game.GameState;
import tk.slicecollections.maxteer.libraries.npclib.api.event.NPCLeftClickEvent;
import tk.slicecollections.maxteer.libraries.npclib.api.event.NPCRightClickEvent;
import tk.slicecollections.maxteer.libraries.npclib.api.npc.NPC;
import tk.slicecollections.maxteer.menus.MenuDeliveries;
import tk.slicecollections.maxteer.player.Profile;

import static tk.kiwicollections.kiwizin.bedwars.cmd.bw.CreateCommand.CREATING;
import static tk.kiwicollections.kiwizin.bedwars.cmd.bw.SpawnCommand.SETUPING;

public class PlayerInteractListener implements Listener {

    @EventHandler
    public void onNPCLeftClick(NPCLeftClickEvent evt) {
        Player player = evt.getPlayer();
        Profile profile = Profile.getProfile(player.getName());

        if (profile != null) {
            NPC npc = evt.getNPC();
            if (npc.data().has("play-npc")) {
                new MenuPlay(profile, BedWarsMode.fromName(npc.data().get("play-npc")));
            }
        }
    }

    @EventHandler
    public void onNPCRightClick(NPCRightClickEvent evt) {
        Player player = evt.getPlayer();
        Profile profile = Profile.getProfile(player.getName());

        if (profile != null) {
            NPC npc = evt.getNPC();
            if (npc.data().has("play-npc")) {
                new MenuPlay(profile, BedWarsMode.fromName(npc.data().get("play-npc")));
            } else if (npc.data().has("delivery-npc")) {
                new MenuDeliveries(profile);
            } else if (npc.data().has("stats-npc")) {
          //      new MenuStatsNPC(profile);
            }
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onPlayerInteract(PlayerInteractEvent evt) {
        Player player = evt.getPlayer();
        Profile profile = Profile.getProfile(player.getName());

        if (profile != null) {
            if (CREATING.containsKey(player) && CREATING.get(player)[0].equals(player.getWorld())) {
                ItemStack item = player.getItemInHand();
                if (item != null && item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
                    CreateCommand.handleClick(profile, item.getItemMeta().getDisplayName(), evt);
                }
            } else if (SETUPING.containsKey(player)) {
                ItemStack item = player.getItemInHand();
                if (item != null && item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
                    SpawnCommand.handleClick(profile, item.getItemMeta().getDisplayName(), evt);
                }
           /* } else if (BALLOONS.containsKey(player) && BALLOONS.get(player)[0].equals(player.getWorld())) {
                ItemStack item = player.getItemInHand();
                if (item != null && item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
                    BalloonsCommand.handleClick(profile, item.getItemMeta().getDisplayName(), evt);
                }

            */
            }

            AbstractBedWars game = profile.getGame(AbstractBedWars.class);
            if (game == null && !BuildCommand.hasBuilder(player)) {
                evt.setCancelled(true);
            } else if (game != null && (game.getState() != GameState.EMJOGO || game.isSpectator(player))) {
                player.updateInventory();
                evt.setCancelled(true);
            }
        }
    }

}
