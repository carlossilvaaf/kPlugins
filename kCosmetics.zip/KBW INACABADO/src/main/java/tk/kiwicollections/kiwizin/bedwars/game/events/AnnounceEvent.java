package tk.kiwicollections.kiwizin.bedwars.game.events;

import tk.kiwicollections.kiwizin.bedwars.game.AbstractBedWars;
import tk.kiwicollections.kiwizin.bedwars.game.BedWarsEvent;

public class AnnounceEvent extends BedWarsEvent {
    @Override
    public void execute(AbstractBedWars game) {

    }

    @Override
    public String getName() {
        return null;
    }
}
