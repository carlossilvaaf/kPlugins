package tk.kiwicollections.kiwizin.bedwars.game.object;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Item;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;
import tk.kiwicollections.kiwizin.bedwars.game.BedWarsTeam;
import tk.slicecollections.maxteer.utils.BukkitUtils;

public class BedWarsTeamGenerator {

    private BedWarsTeam team;
    private int iron, gold;
    private String serialized;

    public BedWarsTeamGenerator(BedWarsTeam team, String serialized) {
        this.team = team;
        this.iron = 3;
        this.gold = 9;
        this.serialized = serialized;
    }

    public void update() {
        if (!team.isAlive()) {
            return;
        }

        Location location = BukkitUtils.deserializeLocation(serialized).add(0, 1, 0);
        if (iron == 0) {
            iron = 3;
            Item i = location.getWorld().dropItem(location, new ItemStack(Material.IRON_INGOT, team.getTeamSize()));
            i.setPickupDelay(0);
            i.setVelocity(new Vector());
        } else {
            iron--;
        }

        if (gold == 0) {
            gold = 9;
            Item i = location.getWorld().dropItem(location, new ItemStack(Material.GOLD_INGOT, team.getTeamSize()));
            i.setPickupDelay(0);
            i.setVelocity(new Vector());
        } else {
            gold--;
        }
    }

    public void reset() {
        this.iron = 3;
        this.gold = 9;
    }
}
