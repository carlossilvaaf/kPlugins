package tk.kiwicollections.kiwizin.bedwars.menus;

import java.util.List;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import tk.kiwicollections.kiwizin.bedwars.Main;
import tk.kiwicollections.kiwizin.bedwars.cosmetics.Cosmetic;
import tk.kiwicollections.kiwizin.bedwars.cosmetics.types.ShopkeeperSkin;
import tk.kiwicollections.kiwizin.bedwars.cosmetics.types.WinAnimation;
import tk.kiwicollections.kiwizin.bedwars.menus.cosmetics.MenuCosmetics;
import tk.slicecollections.maxteer.cash.CashManager;
import tk.slicecollections.maxteer.libraries.menu.PlayerMenu;
import tk.slicecollections.maxteer.player.Profile;
import tk.slicecollections.maxteer.utils.BukkitUtils;
import tk.slicecollections.maxteer.utils.enums.EnumSound;

public class MenuShop extends PlayerMenu {

    @EventHandler
    public void onInventoryClick(InventoryClickEvent evt) {
        if (evt.getInventory().equals(this.getInventory())) {
            evt.setCancelled(true);

            if (evt.getWhoClicked().equals(this.player)) {
                Profile profile = Profile.getProfile(this.player.getName());
                if (profile == null) {
                    this.player.closeInventory();
                    return;
                }

                if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getInventory())) {
                    ItemStack item = evt.getCurrentItem();

                    if (item != null && item.getType() != Material.AIR) {
                        if (evt.getSlot() == 10) {
                            if (!Main.mLootChests) {
                                EnumSound.ENDERMAN_TELEPORT.play(this.player, 0.5F, 1.0F);
                                this.player.sendMessage("§cEm breve.");
                                return;
                            }

                            if (!CashManager.CASH && tk.slicecollections.maxteer.lootchests.api.LootChestsAPI.getLootChests(profile) == 0) {
                                EnumSound.ENDERMAN_TELEPORT.play(this.player, 0.5F, 1.0F);
                                this.player.sendMessage("§cVocê não possui §b§lCaixas de Saque§c!");
                                return;
                            }

                            EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                            tk.slicecollections.maxteer.lootchests.api.LootChestsAPI.openMenu(this.player);
                            this.player.closeInventory();
                        } else if (evt.getSlot() == 16) {
                            EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                            new MenuCosmetics<>(profile, "Skins dos Vendedores", ShopkeeperSkin.class);
                        } else if (evt.getSlot() == 34) {
                            EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                            new MenuCosmetics<>(profile, "Comemorações", WinAnimation.class);
                        }
                    }
                }
            }
        }
    }

    public MenuShop(Profile profile) {
        super(profile.getPlayer(), "Loja - Sky Wars", 5);

        this.setItem(10, BukkitUtils.deserializeItemStack(
                "SKULL_ITEM:3 : 1 : skin>eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYWMxNzc4N2QwNjQ4NWNjOWUxOWNjY2FmM2ZiNTk3YzBlZTM2MGFkZDU5ZDI0M2M2ZmVhZDUzZTBhNDY5YmYyZiJ9fX0= : nome>&aCaixas de Saque : desc>&7Clique para abrir uma Caixa\n&7de Saque que lhe garante\n&7um cosmético &9COMUM&7, &dRARO&7,\n&6ÉPICO &7ou &bDIVINO&7.\n \n&eClique para abrir!"));

        List<ShopkeeperSkin> skins = Cosmetic.listByType(ShopkeeperSkin.class);
        long max = skins.size();
        long owned = skins.stream().filter(balloon -> balloon.has(profile)).count();
        long percentage = max == 0 ? 100 : (owned * 100) / max;
        String color = (owned == max) ? "&a" : (owned > max / 2) ? "&7" : "&c";
        skins.clear();
        this.setItem(16, BukkitUtils.deserializeItemStack(
                "SKULL_ITEM:3 : 1 : skin>eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNDFiODMwZWI0MDgyYWNlYzgzNmJjODM1ZTQwYTExMjgyYmI1MTE5MzMxNWY5MTE4NDMzN2U4ZDM1NTU1ODMifX19 : nome>&aSkins dos Vendedores : desc>&7Escolha uma Skin decorativa para\n&7ser colocada nos Vendedores em sua ilha.\n \n&8Em modos de times maiores a Skin\n&8será escolhida aleatoriamente pelo\n&8sistema. Um pré-requesito é o jogador\n&8ter uma Skin selecionada. Sendo assim,\n&8você ou seu companheiro poderá alterar o\n&8a Skin dos Vendedores em sua ilha.\n \n&fDesbloqueados: " + color + owned + "/" + max + " &8(" + percentage + "%)\n \n&eClique para comprar ou selecionar!"));

        List<WinAnimation> animations = Cosmetic.listByType(WinAnimation.class);
        max = animations.size();
        owned = animations.stream().filter(animation -> animation.has(profile)).count();
        percentage = max == 0 ? 100 : (owned * 100) / max;
        color = (owned == max) ? "&a" : (owned > max / 2) ? "&7" : "&c";
        animations.clear();
        this.setItem(34, BukkitUtils.deserializeItemStack(
                "DRAGON_EGG : 1 : nome>&aComemorações de Vitória : desc>&7Esbanje estilo nas suas vitórias\n&7com comemorações exclusivas.\n \n&fDesbloqueados: " + color + owned + "/" + max + " &8(" + percentage + "%)\n \n&eClique para comprar ou selecionar!"));

        this.register(Main.getInstance());
        this.open();
    }

    public void cancel() {
        HandlerList.unregisterAll(this);
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent evt) {
        if (evt.getPlayer().equals(this.player)) {
            this.cancel();
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent evt) {
        if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getInventory())) {
            this.cancel();
        }
    }
}
