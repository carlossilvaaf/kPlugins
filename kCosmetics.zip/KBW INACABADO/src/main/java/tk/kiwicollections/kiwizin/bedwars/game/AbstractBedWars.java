package tk.kiwicollections.kiwizin.bedwars.game;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Chest;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;
import tk.kiwicollections.kiwizin.bedwars.Language;
import tk.kiwicollections.kiwizin.bedwars.Main;
import tk.kiwicollections.kiwizin.bedwars.api.BWEvent;
import tk.kiwicollections.kiwizin.bedwars.api.event.BWPlayerDeathEvent;
import tk.kiwicollections.kiwizin.bedwars.game.enums.BedWarsMode;
import tk.kiwicollections.kiwizin.bedwars.game.enums.GeneratorLevel;
import tk.kiwicollections.kiwizin.bedwars.game.events.AnnounceEvent;
import tk.kiwicollections.kiwizin.bedwars.game.interfaces.LoadCallback;
import tk.kiwicollections.kiwizin.bedwars.game.object.*;
import tk.kiwicollections.kiwizin.bedwars.tagger.TagUtils;
import tk.slicecollections.maxteer.Manager;
import tk.slicecollections.maxteer.bukkit.BukkitParty;
import tk.slicecollections.maxteer.bukkit.BukkitPartyManager;
import tk.slicecollections.maxteer.database.data.container.SelectedContainer;
import tk.slicecollections.maxteer.game.FakeGame;
import tk.slicecollections.maxteer.game.Game;
import tk.slicecollections.maxteer.game.GameState;
import tk.slicecollections.maxteer.game.GameTeam;
import tk.slicecollections.maxteer.nms.NMS;
import tk.slicecollections.maxteer.party.PartyPlayer;
import tk.slicecollections.maxteer.player.Profile;
import tk.slicecollections.maxteer.player.hotbar.Hotbar;
import tk.slicecollections.maxteer.player.role.Role;
import tk.slicecollections.maxteer.plugin.config.MConfig;
import tk.slicecollections.maxteer.plugin.logger.MLogger;
import tk.slicecollections.maxteer.utils.BukkitUtils;
import tk.slicecollections.maxteer.utils.CubeID;
import tk.slicecollections.maxteer.utils.StringUtils;
import tk.slicecollections.maxteer.utils.enums.EnumSound;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;
import java.util.stream.Collectors;

import static tk.kiwicollections.kiwizin.bedwars.hook.BWCoreHook.reloadScoreboard;

public abstract class AbstractBedWars implements Game<BedWarsTeam> {

    private String name;
    private BedWarsConfig config;
    private BedWarsTask task;

    private int timer;
    private GameState state;
    private List<UUID> players;
    private List<UUID> spectators;
    private Map<String, Integer> kills;
    private Map<String, BedWarsBlock> blocks = new HashMap<>();

    private List<Map.Entry<String, Integer>> topKills = new ArrayList<>();
    private List<BedWarsGenerator> generators = new ArrayList<>();
    private Map<String, Object[]> streak = new HashMap<>();


    public void breakBed(BedWarsTeam team, Profile profile) {
        team.breakBed();
        if (profile != null) {
            profile.addStats("mCoreBedWars", this.getMode().getStats() + "beds");
            this.listPlayers(true).forEach(player -> {
                player.sendMessage(Language.ingame$broadcast$beddestroyed.replace("{team}", team.getName()).replace("{player}", Role.getColored(profile.getPlayer().getName())));
                EnumSound.ENDERDRAGON_GROWL.play(player, 1.0F, 1.0F);
                if (team.hasMember(player)) {
                    NMS.sendTitle(player, Language.ingame$titles$beddestroyed$header, Language.ingame$titles$beddestroyed$footer);
                }
            });
        }

    }


    public String getTeamAlpha(BedWarsTeam team) {
        return getTeamAlpha(team, false);
    }

    public String getTeamAlpha(BedWarsTeam team, boolean replace) {
        if (replace) {
            return StringUtils.getFirstColor(team.getName()) + "§l" + team.getName().substring(2, 3);
        } else {
            return StringUtils.getFirstColor(team.getName()) + "[" + team.getName().substring(2) + "] ";
        }
    }

    public AbstractBedWars(String name, LoadCallback callback) {
        this.name = name;
        this.timer = Language.options$start$waiting + 1;

        this.task = new BedWarsTask(this);

        this.config = new BedWarsConfig(this);
        GeneratorLevel.translate();
        this.config.setupSpawns();
        this.config.setupTeamGenerators();
        this.config.setupGenerators();

        this.state = GameState.AGUARDANDO;

        this.players = new ArrayList<>();
        this.spectators = new ArrayList<>();
        this.kills = new HashMap<>();
        this.task.reset();

        if (!Language.options$regen$world_reload) {
            MConfig config = Main.getInstance().getConfig("blocos", name);
            if (config.contains("dataBlocks")) {
                for (String blockdata : config.getStringList("dataBlocks")) {
                    blocks.put(blockdata.split(" : ")[0],
                            new BedWarsBlock(Material.matchMaterial(blockdata.split(" : ")[1].split(", ")[0]), Byte.parseByte(blockdata.split(" : ")[1].split(", ")[1])));
                }
            } else {
                this.state = GameState.ENCERRADO;
                ArenaRollbackerTask.scan(this, config, callback);
            }
        } else if (callback != null) {
            callback.finish();
        }
    }

    public String addKills(Player player) {
        this.kills.put(player.getName(), this.getKills(player) + 1);
        this.topKills = this.kills.entrySet().stream().sorted((e1, e2) -> Integer.compare(e2.getValue(), e1.getValue())).collect(Collectors.toList());
        Object[] lastKill = this.streak.get(player.getName());
        if (lastKill != null) {
            if ((long) lastKill[0] + 6000 > System.currentTimeMillis()) {
                long streak = (long) lastKill[1];
                this.streak.get(player.getName())[0] = System.currentTimeMillis();
                this.streak.get(player.getName())[1] = streak + 1L;
                return streak == 2 ?
                        Language.ingame$broadcast$double_kill :
                        streak == 3 ? Language.ingame$broadcast$triple_kill : streak == 4 ? Language.ingame$broadcast$quadra_kill : Language.ingame$broadcast$monster_kill;
            }
        }

        lastKill = new Object[2];
        lastKill[0] = System.currentTimeMillis();
        lastKill[1] = 2L;
        this.streak.put(player.getName(), lastKill);
        return "";
    }

    public int getKills(Player player) {
        return this.kills.get(player.getName()) != null ? kills.get(player.getName()) : 0;
    }

    public String getTopKill(int ranking) {
        Map.Entry<String, Integer> entry = this.topKills.size() < ranking ? null : this.topKills.get(ranking - 1);
        if (entry == null) {
            return Language.scoreboards$ranking$empty;
        }

        return Language.scoreboards$ranking$format.replace("{name}", Role.getColored(entry.getKey())).replace("{kills}", StringUtils.formatNumber(entry.getValue()));
    }

    @Override
    public void killLeave(Profile profile, Profile killer) {
        Player player = profile.getPlayer();

        Player pk = killer != null ? killer.getPlayer() : null;
        if (player.equals(pk)) {
            pk = null;
        }

        profile.addStats("mCoreBedWars", this.getMode().getStats() + "deaths");
        if (pk == null) {
            this.broadcastMessage(Language.ingame$broadcast$suicide.replace("{name}", Role.getColored(player.getName())));
        } else {
            if (player.getLastDamageCause() == null || player.getLastDamageCause().getCause() != EntityDamageEvent.DamageCause.VOID) {
            //    KillEffect ke = killer.getAbstractContainer("mCoreSkyWars", "selected", SelectedContainer.class).getSelected(CosmeticType.KILL_EFFECT, KillEffect.class);
              //  if (ke != null) {
                //    ke.execute(player.getLocation());
                //}
            }

            String suffix = this.addKills(pk);
            EnumSound.ORB_PICKUP.play(pk, 1.0F, 1.0F);
            killer.addCoinsWM("mCoreBedWars", Language.options$coins$kills);
            killer.addStats("mCoreBedWars", this.getMode().getStats() + "kills");
            BedWarsTeam team = this.getTeam(profile.getPlayer());
            if (team.bed()) {
                killer.addStats("mCoreBedWars", this.getMode().getStats() + "finalkills");
                profile.addStats("mCoreBedWars", this.getMode().getStats() + "finaldeaths");
                this.broadcastMessage(Language.ingame$broadcast$killed.replace("{name}", Role.getColored(player.getName())).replace("{killer}", Role.getColored(pk.getName())) + suffix + " §f§lABATE FINAL.");
                if (team.listPlayers().size() == 1) {
                    this.broadcastMessage("§aO time " + team.getName() + " §afoi eliminado.");
                }
            } else {
                this.broadcastMessage(Language.ingame$broadcast$killed.replace("{name}", Role.getColored(player.getName())).replace("{killer}", Role.getColored(pk.getName())) + suffix);
            }
        }

      /*  DeathCry dc = profile.getAbstractContainer("mCoreSkyWars", "selected", SelectedContainer.class).getSelected(CosmeticType.DEATH_CRY, DeathCry.class);
        if (dc != null) {
            dc.getSound().play(player.getWorld(), player.getLocation(), dc.getVolume(), dc.getSpeed());
        }
       */
    }

    private void updateTags() {
        for (Player player : this.listPlayers()) {
            Scoreboard scoreboard = player.getScoreboard();

            for (Player players : this.listPlayers()) {
                BedWarsTeam gt;

                if (this.isSpectator(players)) {
                    Team team = scoreboard.getEntryTeam(players.getName());
                    if (team != null && !team.getName().equals("spectators")) {
                        if (team.getSize() == 1) {
                            team.unregister();
                        } else {
                            team.removeEntry(players.getName());
                        }
                        team = null;
                    }

                    if (team == null) {
                        team = scoreboard.getTeam("spectators");
                        if (team == null) {
                            team = scoreboard.registerNewTeam("spectators");
                            team.setPrefix("§8");
                            team.setCanSeeFriendlyInvisibles(true);
                        }

                        if (!team.hasEntry(players.getName())) {
                            team.addEntry(players.getName());
                        }
                    }
                } else if ((gt = this.getTeam(players)) != null) {
                    Team team = scoreboard.getTeam(gt.getName());
                    if (team == null) {
                        team = scoreboard.registerNewTeam(gt.getName());
                        team.setPrefix(gt.hasMember(player) ? "§a" : "§c");
                    }

                    if (!team.hasEntry(players.getName())) {
                        team.addEntry(players.getName());
                    }
                }
            }
        }
    }

    private void check() {
        if (this.state != GameState.EMJOGO) {
            return;
        }

        List<BedWarsTeam> teams = this.listTeams().stream().filter(GameTeam::isAlive).collect(Collectors.toList());
        if (teams.size() <= 1) {
            this.stop(teams.isEmpty() ? null : teams.get(0));
        }

        teams.clear();
    }

    @Override
    public void stop(BedWarsTeam winners) {
        this.state = GameState.ENCERRADO;

        StringBuilder name = new StringBuilder();
        List<Player> players = winners != null ? winners.listPlayers() : null;
        if (players != null) {
            for (Player player : players) {
                if (!name.toString().isEmpty()) {
                    name.append(" §ae ").append(Role.getColored(player.getName()));
                } else {
                    name = new StringBuilder(Role.getColored(player.getName()));
                }
            }

            players.clear();
        }
        if (name.toString().isEmpty()) {
            this.broadcastMessage(Language.ingame$broadcast$end);
        } else {
            this.broadcastMessage((this.getMode() == BedWarsMode.SOLO ? Language.ingame$broadcast$win$solo : Language.ingame$broadcast$win$dupla).replace("{name}", name.toString()));
        }
        for (Player player : this.listPlayers(false)) {
            Profile profile = Profile.getProfile(player.getName());
            profile.update();
            BedWarsTeam team = this.getTeam(player);
            if (team != null) {
                int coinsWin = (int) (team.equals(winners) ? profile.calculateWM(Language.options$coins$wins) : 0);
                int coinsKill = (int) profile.calculateWM(this.getKills(player) * Language.options$coins$kills);
                int totalCoins = coinsWin + coinsKill;

                if (totalCoins > 0) {
                    Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> player.sendMessage(
                            Language.ingame$messages$coins$base.replace("{coins}", StringUtils.formatNumber(totalCoins))
                                    .replace("{coins_win}", coinsWin > 0 ? Language.ingame$messages$coins$win.replace("{coins}", StringUtils.formatNumber(coinsWin)) : "").replace("{coins_kills}",
                                    coinsKill > 0 ?
                                            Language.ingame$messages$coins$kills.replace("{coins}", StringUtils.formatNumber(coinsKill)).replace("{kills}", StringUtils.formatNumber(this.getKills(player)))
                                                    .replace("{s}", this.getKills(player) > 1 ? "s" : "") :
                                            "")), 30);
                }
            }

            if (winners != null && winners.hasMember(player)) {
                profile.addCoinsWM("mCoreBedWars", Language.options$coins$wins);
                profile.addStats("mCoreBedWars", this.getMode().getStats() + "wins");
                NMS.sendTitle(player, Language.ingame$titles$win$header, Language.ingame$titles$win$footer, 10, 80, 10);
            } else {
                NMS.sendTitle(player, Language.ingame$titles$lose$header, Language.ingame$titles$lose$footer, 10, 80, 10);
            }

            this.spectators.add(player.getUniqueId());
            profile.setHotbar(Hotbar.getHotbarById("spectator"));
            profile.refresh();
            player.setGameMode(GameMode.ADVENTURE);
            player.setAllowFlight(true);
            player.setFlying(true);
        }

        this.updateTags();
        this.task.swap(winners);
    }


    @Override
    public void kill(Profile profile, Profile killer) {
        Player player = profile.getPlayer();
        BWPlayerDeathEvent evt = new BWPlayerDeathEvent(this, profile, killer);
        BWEvent.callEvent(evt);
        BedWarsTeam team = this.getTeam(player);
        if (evt.isCancelled()) {
            // TODO: Reviver
            return;
        }
        final int[] count = {5};
        if (team.bed()) {
            if (team != null) {
                team.removeMember(player);
            }
            for (Player players : this.listPlayers()) {
                if (isSpectator(players)) {
                    player.showPlayer(players);
                } else {
                    players.hidePlayer(player);
                }
            }
            this.killLeave(profile, killer);
            this.players.remove(player.getUniqueId());
            this.spectators.add(player.getUniqueId());
            profile.setHotbar(Hotbar.getHotbarById("spectator"));
            Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> {
                if (player.isOnline()) {
                    profile.refresh();
                    player.setGameMode(GameMode.ADVENTURE);
                    player.spigot().setCollidesWithEntities(false);
                    player.setAllowFlight(true);
                    player.setFlying(true);
                    player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, 1));
                    if (killer != null) {
                        player.setVelocity(player.getLocation().getDirection().multiply(-1.6));
                    }
                    Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> {
                        if (player.isOnline()) {
                            int coinsKill = (int) profile.calculateWM(this.getKills(player) * Language.options$coins$kills);

                            if (coinsKill > 0) {
                                player.sendMessage(Language.ingame$messages$coins$base.replace("{coins}", StringUtils.formatNumber(coinsKill)).replace("{coins_win}", "").replace("{coins_kills}",
                                        Language.ingame$messages$coins$kills.replace("{coins}", StringUtils.formatNumber(coinsKill)).replace("{kills}", StringUtils.formatNumber(this.getKills(player)))
                                                .replace("{s}", this.getKills(player) > 1 ? "s" : "")));
                            }

                            NMS.sendTitle(player, Language.ingame$titles$death$header, Language.ingame$titles$death$footer, 0, 60, 0);
                        }
                    }, 27);
                }
            }, 3);
        } else {
            for (Player players : this.listPlayers()) {
                players.hidePlayer(player);
            }
            new BukkitRunnable() {
                @Override
                public void run() {
                    if (count[0] == 0) {
                        this.cancel();
                        if (player.isOnline() && profile.getGame().equals(this)) {
                            NMS.sendTitle(player, "", "");
                            // equip player
                            player.teleport(team.getLocation());
                            listPlayers(true).forEach((var1) -> {
                                var1.showPlayer(player);
                            });
                        }

                    } else {
                        if (player.isOnline()) {
                            NMS.sendTitle(player, "§c§lVOCÊ MORREU!".replace("5", StringUtils.formatNumber(count[0])), "§7Renascendo em §c5s".replace("5", StringUtils.formatNumber(count[0])), 0, 20, 0);
                        }

                        --count[0];
                    }
                }
            }.runTaskTimerAsynchronously(Main.getInstance(), 0, 20);
        }
        this.updateTags();
        this.check();
    }

    private void joinParty(Profile profile, boolean ignoreLeader) {
        Player player = profile.getPlayer();
        if (player == null || !this.state.canJoin() || this.players.size() >= this.getMaxPlayers()) {
            return;
        }

        if (profile.getGame() != null && profile.getGame().equals(this)) {
            return;
        }

        BedWarsTeam team = null;
        boolean fullSize = false;
        BukkitParty party = BukkitPartyManager.getMemberParty(player.getName());
        if (party != null) {
            if (!ignoreLeader) {
                if (!party.isLeader(player.getName())) {
                    player.sendMessage("§cApenas o líder da Party pode buscar por partidas.");
                    return;
                }

                if (party.onlineCount() + players.size() > getMaxPlayers()) {
                    return;
                }

                fullSize = true;
                Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(),
                        () -> party.listMembers().stream().filter(PartyPlayer::isOnline).map(pp -> Profile.getProfile(pp.getName()))
                                .filter(pp -> pp != null && pp.getGame(FakeGame.class) == null).forEach(pp -> joinParty(pp, true)), 5);
            } else {
                team =
                        listTeams().stream().filter(st -> st.canJoin() && (party.listMembers().stream().anyMatch(pp -> pp.isOnline() && st.hasMember((Player) Manager.getPlayer(pp.getName())))))
                                .findAny().orElse(null);
            }
        }

        team = team == null ? getAvailableTeam(fullSize ? this.getMode().getSize() : 1) : team;
        if (team == null) {
            return;
        }

        team.addMember(player);
        if (profile.getGame() != null) {
            profile.getGame().leave(profile, profile.getGame());
        }

        this.players.add(player.getUniqueId());
        profile.setGame(this);

        if (team.listPlayers().size() == 1) {
            team.buildCage();
        }
        player.teleport(team.getLocation());
        reloadScoreboard(profile);

        profile.setHotbar(Hotbar.getHotbarById("waiting"));
        profile.refresh();
        for (Player players : Bukkit.getOnlinePlayers()) {
            if (!players.getWorld().equals(player.getWorld())) {
                player.hidePlayer(players);
                players.hidePlayer(player);
                continue;
            }

            if (isSpectator(players)) {
                player.hidePlayer(players);
            } else {
                player.showPlayer(players);
            }
            players.showPlayer(player);
        }

        this.broadcastMessage(Language.ingame$broadcast$join.replace("{player}", Role.getColored(player.getName())).replace("{players}", String.valueOf(this.getOnline()))
                .replace("{max_players}", String.valueOf(this.getMaxPlayers())));
        if (this.getOnline() == this.getMaxPlayers() && this.timer > Language.options$start$full) {
            this.timer = Language.options$start$full;
        }
    }

    @Override
    public void broadcastMessage(String message) {
        this.broadcastMessage(message, true);
    }

    @Override
    public void broadcastMessage(String message, boolean spectators) {
        this.listPlayers().forEach(player -> player.sendMessage(message));
    }

    @Override
    public void join(Profile profile) {
        this.joinParty(profile, false);
    }

    @Override
    public void leave(Profile profile, Game<?> game) {
        Player player = profile.getPlayer();
        if (player == null || profile.getGame() != this) {
            return;
        }

        BedWarsTeam team = this.getTeam(player);

        boolean alive = this.players.contains(player.getUniqueId());
        this.players.remove(player.getUniqueId());
        this.spectators.remove(player.getUniqueId());

        if (game != null) {
            if (alive && this.state == GameState.EMJOGO) {
                List<Profile> hitters = profile.getLastHitters();
                Profile killer = hitters.size() > 0 ? hitters.get(0) : null;
                killLeave(profile, killer);
                for (Profile hitter : hitters) {
                    if (!hitter.equals(killer) && hitter.playingGame() && hitter.getGame().equals(this) && !this.isSpectator(hitter.getPlayer())) {
                        hitter.addStats("mCoreBedWars", this.getMode().getStats() + "assists");
                    }
                }
                hitters.clear();
            }

            if (team != null) {
                team.removeMember(player);
                if (this.state == GameState.AGUARDANDO && !team.isAlive()) {
                    team.breakCage();
                }
            }
            if (Profile.isOnline(player.getName())) {
                profile.setGame(null);
                TagUtils.setTag(player);
            }
            if (this.state == GameState.AGUARDANDO) {
                this.broadcastMessage(Language.ingame$broadcast$leave.replace("{player}", Role.getColored(player.getName())).replace("{players}", String.valueOf(this.getOnline()))
                        .replace("{max_players}", String.valueOf(this.getMaxPlayers())));
            }
            this.check();
            return;
        }

        if (alive && this.state == GameState.EMJOGO) {
            List<Profile> hitters = profile.getLastHitters();
            Profile killer = hitters.size() > 0 ? hitters.get(0) : null;
            killLeave(profile, killer);
            for (Profile hitter : hitters) {
                if (!hitter.equals(killer) && hitter.playingGame() && hitter.getGame().equals(this) && !this.isSpectator(hitter.getPlayer())) {
                    hitter.addStats("mCoreBedWars", this.getMode().getStats() + "assists");
                }
            }
            hitters.clear();
        }

        if (team != null) {
            team.removeMember(player);
            if (this.state == GameState.AGUARDANDO && !team.isAlive()) {
                team.breakCage();
            }
        }
        profile.setGame(null);
        TagUtils.setTag(player);
        reloadScoreboard(profile);
        profile.setHotbar(Hotbar.getHotbarById("lobby"));
        profile.refresh();
        if (this.state == GameState.AGUARDANDO) {
            this.broadcastMessage(Language.ingame$broadcast$leave.replace("{player}", Role.getColored(player.getName())).replace("{players}", String.valueOf(this.getOnline()))
                    .replace("{max_players}", String.valueOf(this.getMaxPlayers())));
        }
        this.check();
    }
    @Override
    public void start() {
        this.state = GameState.EMJOGO;
        this.task.swap(null);
        this.listGenerators().forEach(BedWarsGenerator::enable);
        this.listTeams().forEach(BedWarsTeam::startGame);
        this.listPlayers(false).forEach(player -> {
            Profile profile = Profile.getProfile(player.getName());
            reloadScoreboard(profile);
            profile.setHotbar(null);
            profile.addStats("mCoreBedWars", this.getMode().getStats() + "games");
            profile.refresh();
            player.getInventory().clear();
            player.getInventory().setArmorContents(null);
            player.updateInventory();
            player.setGameMode(GameMode.SURVIVAL);
            player.setNoDamageTicks(80);
        });

        this.updateTags();
        this.check();
    }


    public void destroy() {
        this.name = null;
        this.config.destroy();
        this.config = null;
        this.timer = 0;
        this.state = null;
        this.task.cancel();
        this.task = null;
        this.players.clear();
        this.players = null;
        this.spectators.clear();
        this.spectators = null;
        this.kills.clear();
        this.kills = null;
        this.topKills.clear();
        this.topKills = null;
    }

    @Override
    public void reset() {
        this.event = null;
        this.nextEvent = null;
        this.topKills.clear();
        this.kills.clear();
        this.streak.clear();
        this.players.clear();
        this.spectators.clear();
        this.task.cancel();
        this.listGenerators().forEach(BedWarsGenerator::reset);
        this.listTeams().forEach(BedWarsTeam::reset);
        addToQueue(this);
    }

    @Override
    public String getGameName() {
        return this.name;
    }

    @Override
    public GameState getState() {
        return this.state;
    }

    public BedWarsMode getMode() {
        return this.config.getMode();
    }

    public CubeID getCubeId() {
        return this.config.getCubeId();
    }

    public BedWarsTeam getAvailableTeam(int teamSize) {
        return this.listTeams().stream().filter(team -> team.canJoin(teamSize)).findAny().orElse(null);
    }


    @Override
    public boolean isSpectator(Player player) {
        return this.spectators.contains(player.getUniqueId());
    }

    @Override
    public int getOnline() {
        return this.players.size();
    }

    public void setState(GameState state) {
        this.state = state;
    }

    public World getWorld() {
        return this.config.getWorld();
    }

    private static final SimpleDateFormat SDF = new SimpleDateFormat("mm:ss");

    private Map.Entry<Integer, BedWarsEvent> event;
    private Map.Entry<Integer, BedWarsEvent> nextEvent;

    public Map<Integer, BedWarsEvent> listEvents() {
        return BedWarsEvent.GERAL;
    }

    public void generateEvent() {
        this.event =
                this.listEvents().entrySet().stream().filter(e -> !(e.getValue() instanceof AnnounceEvent) && this.getTimer() < e.getKey()).min(Comparator.comparingInt(Map.Entry::getKey))
                        .orElse(null);
        this.nextEvent = this.listEvents().entrySet().stream().filter(e -> this.getTimer() < e.getKey()).min(Comparator.comparingInt(Map.Entry::getKey)).orElse(null);
    }

    public String getEvent() {
        if (this.event == null) {
            return "Nenhum";
        }

        return this.event.getValue().getName() + " " + SDF.format((this.event.getKey() - this.getTimer()) * 1000);
    }

    public BedWarsTask getTask() {
        return this.task;
    }

    public Map.Entry<Integer, BedWarsEvent> getNextEvent() {
        return this.nextEvent;
    }

    public int getTimeUntilEvent() {
        return (this.event == null ? this.getTimer() : this.event.getKey()) - this.getTimer();
    }

    public void setTimer(int timer) {
        this.timer = timer;
    }

    public String getMapName() {
        return this.config.getMapName();
    }

    public int getTimer() {
        return this.timer;
    }

    public BedWarsConfig getConfig() {
        return this.config;
    }

    @Override
    public int getMaxPlayers() {
       return this.listTeams().size() * this.getMode().getSize();
    }

    @Override
    public BedWarsTeam getTeam(Player player) {
        return this.listTeams().stream().filter(team -> team.hasMember(player)).findAny().orElse(null);
    }

    public Map<String, BedWarsBlock> getBlocks() {
        return this.blocks;
    }

    public void resetBlock(Block block) {
        BedWarsBlock sb = this.blocks.get(BukkitUtils.serializeLocation(block.getLocation()));

        if (sb != null) {
            block.setType(sb.getMaterial());
            BlockState state = block.getState();
            state.getData().setData(sb.getData());
            if (state instanceof Chest) {
                ((Chest)state).getInventory().clear();
            }
            state.update(true);
        } else {
            block.setType(Material.AIR);
        }
    }


    @Override
    public List<BedWarsTeam> listTeams() {
       return this.config.listTeams();
    }

    public List<BedWarsGenerator> listGenerators() {
        return this.config.listGenerators();
    }

    public List<BedWarsTeamGenerator> listTeamGenerators() {
        return this.config.listTeamGenerators();
    }

    @Override
    public List<Player> listPlayers() {
        return this.listPlayers(true);
    }

    @Override
    public List<Player> listPlayers(boolean spectators) {
        List<Player> players = new ArrayList<>(spectators ? this.spectators.size() + this.players.size() : this.players.size());
        this.players.forEach(id -> players.add(Bukkit.getPlayer(id)));
        if (spectators) {
            this.spectators.stream().filter(id -> !this.players.contains(id)).forEach(id -> players.add(Bukkit.getPlayer(id)));
        }

        return players.stream().filter(Objects::nonNull).collect(Collectors.toList());
    }

    public static final MLogger LOGGER = ((MLogger) Main.getInstance().getLogger()).getModule("GAME");
    public static final List<AbstractBedWars> QUEUE = new ArrayList<>();
    private static final Map<String, AbstractBedWars> GAMES = new HashMap<>();

    public static void addToQueue(AbstractBedWars game) {
        if (QUEUE.contains(game)) {
            return;
        }

        QUEUE.add(game);
    }

    public static void setupGames() {
        BedWarsEvent.setupEvents();
        new ArenaRollbackerTask().runTaskTimer(Main.getInstance(), 0, Language.options$regen$world_reload ? 100 : 1);

        File ymlFolder = new File("plugins/kBedWars/arenas");
        File mapFolder = new File("plugins/kBedWars/mundos");

        if (!ymlFolder.exists() || !mapFolder.exists()) {
            if (!ymlFolder.exists()) {
                ymlFolder.mkdirs();
            }
            if (!mapFolder.exists()) {
                mapFolder.mkdirs();
            }
        }

        for (File file : ymlFolder.listFiles()) {
            load(file, null);
        }

        LOGGER.info("Foram carregadas " + GAMES.size() + " salas.");
    }

    public static void load(File yamlFile, LoadCallback callback) {
        String arenaName = yamlFile.getName().split("\\.")[0];

        try {
            File backup = new File("plugins/kBedWars/mundos", arenaName);
            if (!backup.exists() || !backup.isDirectory()) {
                throw new IllegalArgumentException("Backup do mapa nao encontrado para a arena \"" + yamlFile.getName() + "\"");
            }

            BedWarsMode mode = BedWarsMode.fromName(Main.getInstance().getConfig("arenas", arenaName).getString("mode"));
            if (mode == null) {
                throw new IllegalArgumentException("Modo do mapa \"" + yamlFile.getName() + "\" nao e valido");
            }

            GAMES.put(arenaName, mode.buildGame(arenaName, callback));
        } catch (Exception ex) {
            LOGGER.log(Level.WARNING, "load(\"" + yamlFile.getName() + "\"): ", ex);
        }
    }

    public static AbstractBedWars getByWorldName(String worldName) {
        return GAMES.get(worldName);
    }

    public static int getWaiting(BedWarsMode mode) {
        int waiting = 0;
        List<AbstractBedWars> games = listByMode(mode);
        for (AbstractBedWars game : games) {
            if (game.getState() != GameState.EMJOGO) {
                waiting += game.getOnline();
            }
        }

        return waiting;
    }

    public static int getPlaying(BedWarsMode mode) {
        int playing = 0;
        List<AbstractBedWars> games = listByMode(mode);
        for (AbstractBedWars game : games) {
            if (game.getState() == GameState.EMJOGO) {
                playing += game.getOnline();
            }
        }

        return playing;
    }

    public static AbstractBedWars findRandom(BedWarsMode mode) {
        List<AbstractBedWars> games = GAMES.values().stream().filter(game -> game.getMode().equals(mode) && game.getState().canJoin() && game.getOnline() < game.getMaxPlayers())
                .sorted((g1, g2) -> Integer.compare(g2.getOnline(), g1.getOnline())).collect(Collectors.toList());
        AbstractBedWars game = games.stream().findFirst().orElse(null);
        if (game != null && game.getOnline() == 0) {
            game = games.get(ThreadLocalRandom.current().nextInt(games.size()));
        }

        return game;
    }

    public static Map<String, List<AbstractBedWars>> getAsMap(BedWarsMode mode) {
        Map<String, List<AbstractBedWars>> result = new HashMap<>();
        GAMES.values().stream().filter(game -> game.getMode().equals(mode) && game.getState().canJoin() && game.getOnline() < game.getMaxPlayers()).forEach(game -> {
            List<AbstractBedWars> list = result.computeIfAbsent(game.getMapName(), k -> new ArrayList<>());

            if (game.getState().canJoin() && game.getOnline() < game.getMaxPlayers()) {
                list.add(game);
            }
        });

        return result;
    }

    public static List<AbstractBedWars> listByMode(BedWarsMode mode) {
        return GAMES.values().stream().filter(tb -> tb.getMode().equals(mode)).collect(Collectors.toList());
    }
}
