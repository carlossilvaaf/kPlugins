package tk.kiwicollections.kiwizin.bedwars.utils;

import org.bukkit.Location;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import tk.kiwicollections.kiwizin.bedwars.Main;
import tk.slicecollections.maxteer.nms.NMS;
import tk.slicecollections.maxteer.nms.interfaces.entity.IArmorStand;

public class FloatingItem {

    private BukkitTask task;
    private Location location;
    private IArmorStand armorStand;

    public FloatingItem(Location location) {
        this.location = location;
    }

    public void spawn(ItemStack item, boolean big) {
        if (this.task != null) {
            return;
        }

        this.armorStand = NMS.createArmorStand(this.location, "", null);
        this.armorStand.getEntity().setMetadata("BW_ARMOR",
                new FixedMetadataValue(Main.getInstance(), true));
        this.armorStand.getEntity().setGravity(false);
        this.armorStand.getEntity().setVisible(false);
        this.armorStand.getEntity().setBasePlate(false);
        this.armorStand.getEntity().setHelmet(item);
        this.armorStand.getEntity().setSmall(!big);
        this.armorStand.getEntity().teleport(this.location);

        this.task = new BukkitRunnable() {

            @Override
            public void run() {
                Location location = armorStand.getEntity().getLocation();

                location.setYaw((location.getYaw() - 7.5F));
                armorStand.getEntity().teleport(location);
            }
        }.runTaskTimer(Main.getInstance(), 0, 1);
    }

    public void disable() {
        if (this.task == null) {
            return;
        }

        this.task.cancel();
        this.task = null;
        this.armorStand.killEntity();
        this.armorStand = null;
    }

    public Location getLocation() {
        return location;
    }

    public IArmorStand getArmorStand() {
        return armorStand;
    }
}