package tk.kiwicollections.kiwizin.bedwars.cmd.bw;


import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import tk.kiwicollections.kiwizin.bedwars.Main;
import tk.kiwicollections.kiwizin.bedwars.cmd.SubCommand;
import tk.slicecollections.maxteer.plugin.logger.MLogger;

import java.util.logging.Level;

public class UnloadCommand extends SubCommand {

    public static final MLogger LOGGER = ((MLogger) Main.getInstance().getLogger()).getModule("UNLOAD_WORLD");

    public UnloadCommand() {
        super("unload", "unload [world]", "Descarregue um mundo.", false);
    }

    @Override
    public void perform(CommandSender sender, String[] args) {
        if (args.length == 0) {
            sender.sendMessage("§cUtilize /bw " + this.getUsage());
            return;
        }

        World world = Bukkit.getWorld(args[0]);
        if (world != null) {
            try {
                Bukkit.unloadWorld(world, true);
                sender.sendMessage("§aMundo descarregado com sucesso.");
            } catch (Exception ex) {
                LOGGER.log(Level.WARNING, "Cannot unload world \"" + world.getName() + "\"", ex);
                sender.sendMessage("§cErro ao descarregar mundo.");
            }
        } else {
            sender.sendMessage("§cMundo não encontrado.");
        }
    }
}
