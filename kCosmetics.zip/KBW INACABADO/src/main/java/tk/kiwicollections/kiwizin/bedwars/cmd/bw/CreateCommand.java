package tk.kiwicollections.kiwizin.bedwars.cmd.bw;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import tk.kiwicollections.kiwizin.bedwars.Main;
import tk.kiwicollections.kiwizin.bedwars.cmd.SubCommand;
import tk.kiwicollections.kiwizin.bedwars.game.AbstractBedWars;
import tk.kiwicollections.kiwizin.bedwars.game.enums.BedWarsMode;
import tk.slicecollections.maxteer.player.Profile;
import tk.slicecollections.maxteer.player.hotbar.Hotbar;
import tk.slicecollections.maxteer.plugin.config.MConfig;
import tk.slicecollections.maxteer.utils.BukkitUtils;
import tk.slicecollections.maxteer.utils.CubeID;
import tk.slicecollections.maxteer.utils.StringUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CreateCommand extends SubCommand {

    public CreateCommand() {
        super("criar", "criar [solo/dupla] [nome]", "Criar uma sala.", true);
    }

    public static final Map<Player, Object[]> CREATING = new HashMap<>();


    @Override
    public void perform(Player player, String[] args) {
        if (AbstractBedWars.getByWorldName(player.getWorld().getName()) != null) {
            player.sendMessage("§cJá existe uma sala neste mundo.");
            return;
        }

        if (args.length <= 1) {
            player.sendMessage("§cUtilize /bw " + this.getUsage());
            return;
        }

        BedWarsMode mode = BedWarsMode.fromName(args[0]);
        if (mode == null) {
            player.sendMessage("§cUtilize /bw " + this.getUsage());
            return;
        }

        String name = StringUtils.join(args, 1, " ");
        Object[] array = new Object[5];
        array[0] = player.getWorld();
        array[1] = name;
        array[2] = mode.name();
        CREATING.put(player, array);

        player.getInventory().clear();
        player.getInventory().setArmorContents(null);

        player.getInventory().setItem(0, BukkitUtils.deserializeItemStack("BLAZE_ROD : 1 : nome>&aCuboID da Arena"));
        player.getInventory().setItem(1, BukkitUtils.deserializeItemStack("STAINED_CLAY:13 : 1 : nome>&aConfirmar"));

        player.updateInventory();

        Profile.getProfile(player.getName()).setHotbar(null);
    }

    public static void handleClick(Profile profile, String display, PlayerInteractEvent evt) {
        Player player = profile.getPlayer();

        switch (display) {
            case "§aCuboID da Arena": {
                evt.setCancelled(true);
                if (evt.getAction() == Action.LEFT_CLICK_BLOCK) {
                    CREATING.get(player)[3] = evt.getClickedBlock().getLocation();
                    player.sendMessage("§aBorda da Arena 1 setada.");
                } else if (evt.getAction() == Action.RIGHT_CLICK_BLOCK) {
                    CREATING.get(player)[4] = evt.getClickedBlock().getLocation();
                    player.sendMessage("§aBorda da Arena 2 setada.");
                } else {
                    player.sendMessage("§cClique em um bloco.");
                }
                break;
            }
            case "§aConfirmar": {
                evt.setCancelled(true);
                if (CREATING.get(player)[3] == null) {
                    player.sendMessage("§cBorda da Arena 1 não setada.");
                    return;
                }

                if (CREATING.get(player)[4] == null) {
                    player.sendMessage("§cBorda da Arena 2 não setada.");
                    return;
                }

                Object[] array = CREATING.get(player);
                World world = player.getWorld();
                MConfig config = Main.getInstance().getConfig("arenas", world.getName());
                player.getInventory().clear();
                player.getInventory().setArmorContents(null);
                player.updateInventory();
                CREATING.remove(player);
                player.sendMessage("§aCriando sala...");

                CubeID cube = new CubeID((Location) array[3], (Location) array[4]);

                config.set("name", array[1]);
                config.set("mode", array[2]);
                config.set("minPlayers", 4);
                config.set("cubeId", cube.toString());
                config.set("spawns", new ArrayList< >());
                config.set("balloons", new ArrayList<>());
                config.set("shops", new ArrayList<>());
                config.set("generators", new ArrayList<>());
                config.set("teamgenerators", new ArrayList<>());
                world.save();

                player.sendMessage("§aCriando backup do mapa...");
                Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> {
                    Main.getInstance().getFileUtils().copyFiles(new File(world.getName()), new File("plugins/kBedWars/mundos/" + world.getName()), "playerdata", "stats", "uid.dat");

                    profile.setHotbar(Hotbar.getHotbarById("lobby"));
                    profile.refresh();
                    AbstractBedWars.load(config.getFile(), () -> player.sendMessage("§aSala criada com sucesso."));
                }, 60);
                break;
            }
        }
    }

}
