package tk.kiwicollections.kiwizin.bedwars.game.interfaces;

public interface LoadCallback {
    void finish();
}
