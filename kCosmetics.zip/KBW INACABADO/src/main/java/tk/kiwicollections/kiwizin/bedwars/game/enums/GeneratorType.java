package tk.kiwicollections.kiwizin.bedwars.game.enums;

public enum GeneratorType {

    DIAMOND("Diamante", "§b", "DIAMOND : 1"),
    EMERALD("Esmeralda", "§2", "EMERALD : 1");

    private String name;
    private String color;
    private String stack;

    GeneratorType(String name, String color, String stack) {
        this.name = name;
        this.color = color;
        this.stack = stack;
    }

    public String getStack() {
        return stack;
    }

    public String getName() {
        return name;
    }

    public String getColor() {
        return color;
    }

    public String getColoredName() {
        return color + name;
    }

    public static GeneratorType fromName(String name) {
        for (GeneratorType type : values()) {
            if (type.getName().toLowerCase().equals(name.toLowerCase())
                    || type.name().toLowerCase().equals(name.toLowerCase())) {
                return type;
            }
        }

        return null;
    }
}
