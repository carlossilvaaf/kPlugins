package tk.kiwicollections.kiwizin.bedwars.hook.lootchests;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.model.Filters;
import org.bson.Document;
import org.bukkit.command.CommandSender;
import tk.kiwicollections.kiwizin.bedwars.Main;
import tk.kiwicollections.kiwizin.bedwars.cosmetics.Cosmetic;
import tk.slicecollections.maxteer.database.Database;
import tk.slicecollections.maxteer.database.HikariDatabase;
import tk.slicecollections.maxteer.database.MongoDBDatabase;
import tk.slicecollections.maxteer.database.MySQLDatabase;

import javax.sql.rowset.CachedRowSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static com.mongodb.client.model.Projections.fields;
import static com.mongodb.client.model.Projections.include;

public class LootChestsHook {

    private static Boolean unsynced;

    public static void sync(CommandSender sender) {
        if (Database.getInstance() instanceof MongoDBDatabase) {
            MongoDBDatabase database = (MongoDBDatabase) Database.getInstance();
            MongoCollection<Document> collection = database.getDatabase().getCollection("mLootChestsContent");
            database.getExecutor().execute(() -> {
                collection.deleteMany(Filters.eq("dependency", "kBedWars"));

                List<Document> documents = new ArrayList<>();
                Cosmetic.listCosmetics().forEach(cosmetic -> {
                    documents.add(
                            new Document("_id", cosmetic.getLootChestsID()).append("name", "&f" + cosmetic.getName() + " &7(BedWars - " + cosmetic.getType().getName(cosmetic.getIndex()) + ")")
                                    .append("rarity", cosmetic.getRarity().name())
                                    .append("action", "bw lc give {player} " + cosmetic.getLootChestsID() + " ; bw lc give {player} " + cosmetic.getLootChestsID()).append("dependency", "kBedWars"));
                });

                collection.insertMany(documents);
                tk.slicecollections.maxteer.lootchests.api.LootChestsAPI.reloadContents();
                sender.sendMessage("§aA sincronização terminou!");
            });
        } else {
            if (Database.getInstance() instanceof MySQLDatabase) {
                ((MySQLDatabase) Database.getInstance()).update("DELETE FROM `mLootChestsContent` WHERE `dependency` = ?", "kBedWars");
            } else {
                ((HikariDatabase) Database.getInstance()).update("DELETE FROM `mLootChestsContent` WHERE `dependency` = ?", "kBedWars");
            }

            StringBuilder query = new StringBuilder("INSERT INTO `mLootChestsContent` VALUES ");
            Cosmetic.listCosmetics().forEach(
                    cosmetic -> query.append("('").append(cosmetic.getLootChestsID()).append("', '").append("&f").append(cosmetic.getName()).append(" &7(BedWars - ")
                            .append(cosmetic.getType().getName(cosmetic.getIndex())).append(")', '").append(cosmetic.getRarity().name()).append("', 'bw lc give {player} ")
                            .append(cosmetic.getLootChestsID()).append(" ; bw lc give {player} ").append(cosmetic.getLootChestsID()).append("', 'kBedWars'),"));

            query.deleteCharAt(query.length() - 1);
            if (Database.getInstance() instanceof MySQLDatabase) {
                ((MySQLDatabase) Database.getInstance()).update(query.toString());
            } else {
                ((HikariDatabase) Database.getInstance()).update(query.toString());
            }
            tk.slicecollections.maxteer.lootchests.api.LootChestsAPI.reloadContents();
            sender.sendMessage("§aA sincronização terminou!");
        }
        unsynced = false;
    }

    public static boolean isUnsynced() {
        if (unsynced == null) {
            if (Main.mLootChests) {
                List<String> verified = new ArrayList<>();
                if (Database.getInstance() instanceof MongoDBDatabase) {
                    MongoDBDatabase database = (MongoDBDatabase) Database.getInstance();
                    try {
                        MongoCursor<Document> rs =
                                database.getExecutor().submit(() -> database.getDatabase().getCollection("mLootChestsContent").find(new Document("dependency", "kBedWars")).projection(fields(include("_id"))).cursor()).get();
                        while (rs.hasNext()) {
                            Document document = rs.next();
                            if (Cosmetic.findById(document.getString("_id")) == null) {
                                unsynced = true;
                                return unsynced;
                            }
                            verified.add(document.getString("_id"));
                        }
                    } catch (Exception ignore) {}
                } else {
                    CachedRowSet rs;
                    if (Database.getInstance() instanceof MySQLDatabase) {
                        rs = ((MySQLDatabase) Database.getInstance()).query("SELECT * FROM `mLootChestsContent` WHERE `dependency` = ?", "kBedWars");
                    } else {
                        rs = ((HikariDatabase) Database.getInstance()).query("SELECT * FROM `mLootChestsContent` WHERE `dependency` = ?", "kBedWars");
                    }

                    try {
                        if (rs != null) {
                            rs.beforeFirst();
                            while (rs.next()) {
                                if (Cosmetic.findById(rs.getString("id")) == null) {
                                    unsynced = true;
                                    return unsynced;
                                }

                                verified.add(rs.getString("id"));
                            }
                        }
                    } catch (SQLException ignore) {} finally {
                        if (rs != null) {
                            try {
                                rs.close();
                            } catch (SQLException ignore) {}
                        }
                    }
                }
                unsynced = Cosmetic.listCosmetics().stream().anyMatch(c -> !verified.contains(c.getLootChestsID()));
                verified.clear();
                return unsynced;
            }

            unsynced = false;
        }

        return unsynced;
    }
}
