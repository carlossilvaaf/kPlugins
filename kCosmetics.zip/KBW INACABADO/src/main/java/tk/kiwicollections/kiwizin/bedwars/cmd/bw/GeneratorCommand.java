package tk.kiwicollections.kiwizin.bedwars.cmd.bw;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import tk.kiwicollections.kiwizin.bedwars.cmd.SubCommand;
import tk.kiwicollections.kiwizin.bedwars.game.AbstractBedWars;
import tk.kiwicollections.kiwizin.bedwars.game.enums.GeneratorType;

import java.util.HashMap;
import java.util.Map;

public class GeneratorCommand extends SubCommand {

    public GeneratorCommand() {
        super("gerador", "gerador [diamante/esmeralda]", "Adicionar um gerador na sua localização.", true);
    }

    public static final Map<Player, Object[]> CREATING = new HashMap<>();


    @Override
    public void perform(Player player, String[] args) {
        if (AbstractBedWars.getByWorldName(player.getWorld().getName()) == null) {
            player.sendMessage("§cNão existe uma sala neste mundo.");
            return;
        }
        if (args.length == 0) {
            player.sendMessage("§cUtilize /bw " + this.getUsage());
            return;
        }
        String typed;
        typed = args[0];
        if (args[0].equalsIgnoreCase("diamante")) {
            typed = "diamond";
        } else if (args[0].equalsIgnoreCase("esmeralda")) {
            typed = "esmerald";
        }
        GeneratorType type = GeneratorType.fromName(typed.toUpperCase());
        if (type == null) {
            player.sendMessage("§cUtilize /bw " + this.getUsage());
            return;
        }

        Location location = player.getLocation().getBlock().getLocation().clone().add(0.5, 0, 0.5);
        location.setYaw(player.getLocation().getYaw());
        location.setPitch(player.getLocation().getPitch());
        AbstractBedWars.getByWorldName(player.getWorld().getName()).getConfig().addGenerator(location, type);
        player.sendMessage("§aO gerador foi adicionado.");
    }
}
