package tk.kiwicollections.kiwizin.bedwars.game.object;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Item;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;
import tk.kiwicollections.kiwizin.bedwars.game.enums.GeneratorLevel;
import tk.kiwicollections.kiwizin.bedwars.game.enums.GeneratorType;
import tk.kiwicollections.kiwizin.bedwars.utils.FloatingItem;
import tk.slicecollections.maxteer.libraries.holograms.HologramLibrary;
import tk.slicecollections.maxteer.libraries.holograms.api.Hologram;
import tk.slicecollections.maxteer.utils.BukkitUtils;
import tk.slicecollections.maxteer.utils.StringUtils;

public class BedWarsGenerator {

    public int level, countdown;
    private Location serialized;
    private GeneratorType type;
    private FloatingItem item;
    private Hologram hologram;

    public BedWarsGenerator(GeneratorType type, Location serialized) {
        this.level = 1;
        this.countdown = type == GeneratorType.DIAMOND ? GeneratorLevel.getFromInt(level).getDiamond()
                : GeneratorLevel.getFromInt(level).getEmerald();
        this.type = type;
        this.serialized = serialized;
    }

    public void upgrade() {
        level++;
        countdown = type == GeneratorType.DIAMOND ? GeneratorLevel.getFromInt(level).getDiamond()
                : GeneratorLevel.getFromInt(level).getEmerald();
        this.hologram.updateLine(3, "§eNível§c " + StringUtils.repeat("I", level));
        this.update();
    }

    public void update() {
        this.hologram.updateLine(1, "§eGera em §c" + countdown + " §esegundos");
        if (countdown == 0) {
            countdown = type == GeneratorType.DIAMOND ? GeneratorLevel.getFromInt(level).getDiamond()
                    : GeneratorLevel.getFromInt(level).getEmerald();
            Item i = item.getLocation().getWorld().dropItem(item.getLocation(), new ItemStack(Material.valueOf(type.name())));
            i.setPickupDelay(0);
            i.setVelocity(new Vector());
            return;
        }

        countdown--;
    }

    public void enable() {
        if (this.item != null) {
            this.item.disable();
            this.item = null;
        }
        this.item =
                new FloatingItem(serialized.clone().add(0, 1.5, 0));
        this.hologram = HologramLibrary.createHologram(this.item.getLocation().clone().add(0, 0.6, 0),
                "§eGera em §f0 §esegundos", type.getColoredName(), "§eNível §cI");
        this.item.spawn(new ItemStack(Material.valueOf(type.name() + "_BLOCK")), true);
        this.update();
    }

    public void reset() {
        this.level = 1;
        this.item.disable();
        this.item = null;
        this.hologram.despawn();
        this.hologram = null;
    }

    public GeneratorType getType() {
        return type;
    }
}
