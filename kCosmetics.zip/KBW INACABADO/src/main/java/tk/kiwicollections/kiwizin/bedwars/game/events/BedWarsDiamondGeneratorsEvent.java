package tk.kiwicollections.kiwizin.bedwars.game.events;

import tk.kiwicollections.kiwizin.bedwars.Language;
import tk.kiwicollections.kiwizin.bedwars.game.AbstractBedWars;
import tk.kiwicollections.kiwizin.bedwars.game.BedWarsEvent;
import tk.kiwicollections.kiwizin.bedwars.game.enums.GeneratorType;
import tk.kiwicollections.kiwizin.bedwars.game.object.BedWarsGenerator;
import tk.slicecollections.maxteer.nms.NMS;
import tk.slicecollections.maxteer.utils.enums.EnumSound;

public class BedWarsDiamondGeneratorsEvent extends BedWarsEvent {

    @Override
    public void execute(AbstractBedWars game) {
        game.listGenerators().stream()
                .filter(generator -> generator.getType() == GeneratorType.DIAMOND)
                .forEach(generator -> generator.upgrade());
    }

    @Override
    public String getName() {
        return Language.options$events$diamond;
    }
}
