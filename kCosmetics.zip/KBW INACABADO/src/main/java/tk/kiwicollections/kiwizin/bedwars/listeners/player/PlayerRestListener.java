package tk.kiwicollections.kiwizin.bedwars.listeners.player;


import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.inventory.ItemStack;
import tk.kiwicollections.kiwizin.bedwars.cmd.bw.BuildCommand;
import tk.kiwicollections.kiwizin.bedwars.game.AbstractBedWars;
import tk.kiwicollections.kiwizin.bedwars.game.BedWarsTeam;
import tk.slicecollections.maxteer.game.GameState;
import tk.slicecollections.maxteer.player.Profile;

public class PlayerRestListener implements Listener {

    @EventHandler
    public void onPlayerDropItem(PlayerDropItemEvent evt) {
        Profile profile = Profile.getProfile(evt.getPlayer().getName());
        if (profile != null) {
            AbstractBedWars game = profile.getGame(AbstractBedWars.class);
            if (game == null) {
                evt.setCancelled(true);
            } else {
                ItemStack item = evt.getItemDrop().getItemStack();
                if (item.getType().name().contains("_SWORD") || item.getType().name().contains("_HELMET") || item.getType().name().contains("_CHESTPLATE") || item.getType().name().contains("_LEGGINGS") || item.getType().name().contains("_BOOTS") || item.getType().name().contains("BOW") || item.getType().name().contains("_PICKAXE") || item.getType().name().contains("_AXE") || item.getType().name().contains("SHEARS") || item.getType().name().contains("COMPASS")) {
                    evt.setCancelled(true);
                    return;
                }
                evt.setCancelled(game.getState() != GameState.EMJOGO || game.isSpectator(evt.getPlayer()));
            }
        }
    }

    @EventHandler
    public void onPlayerPickupItem(PlayerPickupItemEvent evt) {
        Profile profile = Profile.getProfile(evt.getPlayer().getName());
        if (profile != null) {
            AbstractBedWars game = profile.getGame(AbstractBedWars.class);
            if (game == null) {
                evt.setCancelled(true);
            } else {
                evt.setCancelled(game.getState() != GameState.EMJOGO || game.isSpectator(evt.getPlayer()));
            }
        }
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent evt) {
        Profile profile = Profile.getProfile(evt.getPlayer().getName());
        if (profile != null) {
            AbstractBedWars game = profile.getGame(AbstractBedWars.class);
            if (game == null) {
                evt.setCancelled(!BuildCommand.hasBuilder(evt.getPlayer()));
            } else {
                Block block = evt.getBlock();
                if (block.getType().name().contains("BED_BLOCK")) {
                    game.listTeams().stream().filter(BedWarsTeam::isAlive).forEach(team -> {
                        if (team.isBed(block)) {
                            if (!team.hasMember(evt.getPlayer())) {
                                game.breakBed(team, profile);
                                return;
                            }

                            evt.getPlayer().sendMessage("§cVocê não pode destruir sua propria cama.");
                        }
                    });
                } else {
                    evt.setCancelled(game.getState() != GameState.EMJOGO || game.isSpectator(evt.getPlayer()) || !game.getCubeId().contains(evt.getBlock().getLocation()));
                }
            }
        }
    }

    @EventHandler
    public void onBlockPlace(BlockPlaceEvent evt) {
        Profile profile = Profile.getProfile(evt.getPlayer().getName());
        if (profile != null) {
            AbstractBedWars game = profile.getGame(AbstractBedWars.class);
            if (game == null) {
                evt.setCancelled(!BuildCommand.hasBuilder(evt.getPlayer()));
            } else {
                evt.setCancelled(game.getState() != GameState.EMJOGO || game.isSpectator(evt.getPlayer()) || !game.getCubeId().contains(evt.getBlock().getLocation()));
            }
        }
    }
}