package tk.kiwicollections.kiwizin.bedwars.cmd;

import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import tk.kiwicollections.kiwizin.bedwars.Language;
import tk.kiwicollections.kiwizin.bedwars.game.AbstractBedWars;
import tk.slicecollections.maxteer.game.GameState;
import tk.slicecollections.maxteer.player.Profile;
import tk.slicecollections.maxteer.player.role.Role;
import tk.slicecollections.maxteer.utils.StringUtils;

public class GlobalCommand extends Commands {

    public GlobalCommand() {
        super("global", "g");
    }

    @Override
    public void perform(CommandSender sender, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cApenas jogadores podem executar este comando.");
            return;
        }
        Player player = (Player) sender;
        Profile profile = Profile.getProfile(player.getName());
        AbstractBedWars game = profile.getGame(AbstractBedWars.class);
        if (game == null) {
            player.sendMessage("§fComando desconhecido.");
            return;
        }
        if (game.getState() != GameState.EMJOGO) {
            player.sendMessage("§fComando desconhecido.");
            return;
        }
        if (game.isSpectator(player)) {
            player.sendMessage("§fComando desconhecido.");
            return;
        }
        if (args.length == 0) {
            player.sendMessage("§cUtilize /g [mensagem]");
            return;
        }
        String msg = StringUtils.join(args, " ");
        if (player.hasPermission("kbedwars.chat.color")) {
            msg = StringUtils.formatColors(msg);
        }
        game.broadcastMessage(Language.chat$format$global.replace("{team}",
                game.getTeam(player).getTag()).replace("{player}", Role.getPrefixed(player.getName())).replace("{color}",
                (Role.getPlayerRole(player).isDefault() ? Language.chat$color$default : Language.chat$color$custom)).replace("{message}", msg), true);
    }
}
