package dev.slickcollections.kiwizin.thebridge.game;

public interface LoadCallback {
  void finish();
}
