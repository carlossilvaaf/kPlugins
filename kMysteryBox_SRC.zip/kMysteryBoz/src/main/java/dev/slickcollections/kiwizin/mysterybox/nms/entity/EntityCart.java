package dev.slickcollections.kiwizin.mysterybox.nms.entity;

import net.minecraft.server.v1_8_R3.AxisAlignedBB;
import net.minecraft.server.v1_8_R3.DamageSource;
import net.minecraft.server.v1_8_R3.EntitySkeleton;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_8_R3.CraftWorld;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftEntity;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftSkeleton;

import static dev.slickcollections.kiwizin.mysterybox.nms.NMS.ATTACHED_ENTITY;

public class EntityCart extends EntitySkeleton {
  
  private final String owner;
  
  public EntityCart(String owner, Location location) {
    super(((CraftWorld) location.getWorld()).getHandle());
    this.owner = owner;
    setInvisible(true);
    
    this.setPosition(location.getX(), location.getY(), location.getZ());
    super.a(new NullBoundingBox());
  }
  
  @Override
  public void a(AxisAlignedBB axisalignedbb) {}
  
  public boolean isInvulnerable(DamageSource source) {
    return true;
  }
  
  public void setCustomName(String customName) {}
  
  public void setCustomNameVisible(boolean visible) {}
  
  @Override
  public void t_() {
    if (this.dead) {
      super.t_();
    }
    
    if (this.owner == null) {
      this.killEntity();
    }
  }
  
  @Override
  public void die() {}
  
  public void killEntity() {
    ATTACHED_ENTITY.remove(this.getId());
    this.dead = true;
  }
  
  public void makeSound(String sound, float f1, float f2) {}
  
  @Override
  public CraftEntity getBukkitEntity() {
    if (bukkitEntity == null) {
      bukkitEntity = new CraftCart(this);
    }
    
    return super.getBukkitEntity();
  }
  
  static class CraftCart extends CraftSkeleton {
    
    public CraftCart(EntityCart entity) {
      super(entity.world.getServer(), entity);
    }
    
    public int getId() {
      return entity.getId();
    }
    
    @Override
    public void remove() {
      ((EntityCart) entity).killEntity();
    }
  }
}
