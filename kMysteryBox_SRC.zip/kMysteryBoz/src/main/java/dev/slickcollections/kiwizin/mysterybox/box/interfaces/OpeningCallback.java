package dev.slickcollections.kiwizin.mysterybox.box.interfaces;

public interface OpeningCallback {
  void finish();
}
