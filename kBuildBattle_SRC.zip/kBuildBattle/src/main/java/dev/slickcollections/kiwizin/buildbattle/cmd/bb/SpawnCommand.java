package dev.slickcollections.kiwizin.buildbattle.cmd.bb;

import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import dev.slickcollections.kiwizin.buildbattle.Main;
import dev.slickcollections.kiwizin.buildbattle.cmd.SubCommand;
import dev.slickcollections.kiwizin.buildbattle.game.BuildBattle;
import dev.slickcollections.kiwizin.player.Profile;
import dev.slickcollections.kiwizin.player.hotbar.Hotbar;
import dev.slickcollections.kiwizin.utils.BukkitUtils;
import dev.slickcollections.kiwizin.utils.CubeID;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;

import java.util.HashMap;

public class SpawnCommand extends SubCommand {
  
  public static final HashMap<Player, Object[]> SPAWN = new HashMap<>();
  
  public SpawnCommand() {
    super("spawn", "spawn", "Adicionar spawns em uma arena.", true);
  }
  
  public static void apply(Profile profile, BuildBattle game) {
    Player player = profile.getPlayer();
    
    profile.setHotbar(null);
    
    player.setGameMode(GameMode.CREATIVE);
    player.getInventory().clear();
    player.getInventory().setArmorContents(null);
    
    player.getInventory().setItem(0, BukkitUtils.deserializeItemStack("BEACON : 1 : nome>&aSpawn"));
    player.getInventory().setItem(1, BukkitUtils.deserializeItemStack("BLAZE_ROD : 1 : nome>&aCuboID da Plot"));
    player.getInventory().setItem(2, BukkitUtils.deserializeItemStack("BLAZE_ROD : 1 : nome>&aCuboID do Chão da Plot"));
  
    player.getInventory().setItem(8, BukkitUtils.deserializeItemStack("STAINED_CLAY:5 : 1 : nome>&aPróximo"));
    
    player.updateInventory();
  }
  
  public static void handleClick(Profile profile, String display, PlayerInteractEvent evt) {
    Player player = profile.getPlayer();
    BuildBattle game = BuildBattle.getByWorldName(player.getWorld().getName());
    
    switch (display) {
      case "§aSpawn": {
        evt.setCancelled(true);
        Location location = player.getLocation().getBlock().getLocation().clone().add(0.5, 0.0, 0.5);
        location.setYaw(player.getLocation().getYaw());
        location.setPitch(player.getLocation().getPitch());
        SPAWN.get(player)[1] = BukkitUtils.serializeLocation(location);
        player.sendMessage("§aSpawn setado.");
        break;
      }
      case "§aCuboID da Plot": {
        evt.setCancelled(true);
        if (evt.getAction() == Action.LEFT_CLICK_BLOCK) {
          SPAWN.get(player)[2] = evt.getClickedBlock().getLocation();
          player.sendMessage("§aBorda da Plot 1 setada.");
        } else if (evt.getAction() == Action.RIGHT_CLICK_BLOCK) {
          SPAWN.get(player)[3] = evt.getClickedBlock().getLocation();
          player.sendMessage("§aBorda da Arena Plot setada.");
        } else {
          player.sendMessage("§cClique em um bloco.");
        }
        break;
      }
      case "§aCuboID do Chão da Plot": {
        evt.setCancelled(true);
        if (evt.getAction() == Action.LEFT_CLICK_BLOCK) {
          SPAWN.get(player)[4] = evt.getClickedBlock().getLocation();
          player.sendMessage("§aBorda do Chão da Plot 1 setada.");
        } else if (evt.getAction() == Action.RIGHT_CLICK_BLOCK) {
          SPAWN.get(player)[5] = evt.getClickedBlock().getLocation();
          player.sendMessage("§aBorda do Chão da Plot 2 setada.");
        } else {
          player.sendMessage("§cClique em um bloco.");
        }
        break;
      }
      case "§aPróximo": {
        evt.setCancelled(true);
        if (SPAWN.get(player)[1] == null) {
          player.sendMessage("§cSpawn não setado.");
          return;
        } else if (SPAWN.get(player)[2] == null) {
          player.sendMessage("§cBorda 1 da Plot não setada.");
          return;
        } else if (SPAWN.get(player)[3] == null) {
          player.sendMessage("§cBorda 2 da Plot não setada.");
          return;
        } else if (SPAWN.get(player)[3] == null) {
          player.sendMessage("§cBorda 1 do Chão da Plot não setada.");
          return;
        } else if (SPAWN.get(player)[4] == null) {
          player.sendMessage("§cBorda 2 do Chão da Plot não setada.");
          return;
        }
        
        Object[] array = SPAWN.get(player);
        CubeID cube = new CubeID((Location) array[2], (Location) array[3]);
        CubeID cubeDown = new CubeID((Location) array[4], (Location) array[5]);
  
        JsonObject spawn = new JsonObject();
        spawn.add("spawn", new JsonPrimitive((String) array[1]));
        spawn.add("cubeId", new JsonPrimitive(cube.toString()));
        spawn.add("cubeIdDown", new JsonPrimitive(cubeDown.toString()));
        game.addSpawn(spawn);
        player.sendMessage("§aSpawn adicionado.");
        if (game.listTeams().size() >= 8) {
          SPAWN.remove(player);
          profile.setHotbar(Hotbar.getHotbarById("lobby"));
          profile.refresh();
          return;
        }
        
        SPAWN.get(player)[1] = null;
        SPAWN.get(player)[2] = null;
        SPAWN.get(player)[3] = null;
        SPAWN.get(player)[4] = null;
        SPAWN.get(player)[5] = null;
  
        Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> apply(profile, game));
        break;
      }
      case "§cCancelar": {
        evt.setCancelled(true);
        SPAWN.remove(player);
        profile.setHotbar(Hotbar.getHotbarById("lobby"));
        profile.refresh();
        break;
      }
    }
  }
  
  @Override
  public void perform(Player player, String[] args) {
    BuildBattle game = BuildBattle.getByWorldName(player.getWorld().getName());
    if (game == null) {
      player.sendMessage("§cNão existe uma arena neste mundo.");
      return;
    }
    
    if (game.listTeams().size() >= 8) {
      player.sendMessage("§cEssa arena já possui o máximo de spawns.");
      return;
    }
    
    Object[] arr = new Object[6];
    arr[0] = game;
    SPAWN.put(player, arr);
    
    Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> apply(Profile.getProfile(player.getName()), game));
  }
}