package dev.slickcollections.kiwizin.buildbattle.listeners.player;


import dev.slickcollections.kiwizin.buildbattle.cmd.bb.BuildCommand;
import dev.slickcollections.kiwizin.buildbattle.game.BuildBattle;
import dev.slickcollections.kiwizin.game.GameState;
import dev.slickcollections.kiwizin.player.Profile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.inventory.ItemStack;

public class PlayerRestListener implements Listener {
  
  @EventHandler
  public void onPlayerDropItem(PlayerDropItemEvent evt) {
    Profile profile = Profile.getProfile(evt.getPlayer().getName());
    if (profile != null) {
      BuildBattle game = profile.getGame(BuildBattle.class);
      ItemStack item = evt.getItemDrop().getItemStack();
      evt.setCancelled(true);
    }
  }
  
  @EventHandler
  public void onPlayerPickupItem(PlayerPickupItemEvent evt) {
    Profile profile = Profile.getProfile(evt.getPlayer().getName());
    if (profile != null) {
      evt.setCancelled(true);
    }
  }
  
  @EventHandler
  public void onBlockBreak(BlockBreakEvent evt) {
    Profile profile = Profile.getProfile(evt.getPlayer().getName());
    if (profile != null) {
      BuildBattle game = profile.getGame(BuildBattle.class);
      if (game == null) {
        evt.setCancelled(!BuildCommand.hasBuilder(evt.getPlayer()));
      } else {
        if (game.getState() != GameState.EMJOGO && (game.isSpectator(evt.getPlayer()) || !game.getCubeId().contains(evt.getBlock().getLocation()))) {
          evt.setCancelled(true);
        } else if (game.getState() == GameState.EMJOGO) {
          if (game.isPlacedBlock(evt.getBlock()))  {
            evt.setCancelled(true);
            return;
          }
          if (game.getTeam(evt.getPlayer()).getCubeId().contains(evt.getBlock().getLocation())) {
            evt.setCancelled(!game.getCubeId().contains(evt.getBlock().getLocation()));
          } else {
            evt.setCancelled(true);
          }
        }
        if (!evt.isCancelled()) {
          game.removePlacedBlock(evt.getBlock());
        }
      }
    }
  }
  
  @EventHandler
  public void onBlockPlace(BlockPlaceEvent evt) {
    Profile profile = Profile.getProfile(evt.getPlayer().getName());
    if (profile != null) {
      BuildBattle game = profile.getGame(BuildBattle.class);
      if (game == null) {
        evt.setCancelled(!BuildCommand.hasBuilder(evt.getPlayer()));
      } else {
        if (game.getState() != GameState.EMJOGO && (game.isSpectator(evt.getPlayer()) || !game.getCubeId().contains(evt.getBlock().getLocation()))) {
          evt.setCancelled(true);
        } else if (game.getState() == GameState.EMJOGO) {
          if (game.getTeam(evt.getPlayer()).getCubeId().contains(evt.getBlock().getLocation())) {
            evt.setCancelled(!game.getCubeId().contains(evt.getBlock().getLocation()));
          } else {
            evt.setCancelled(true);
          }
        }
        if (!evt.isCancelled()) {
          game.addPlacedBlock(evt.getBlock());
        }
      }
    }
  }
}