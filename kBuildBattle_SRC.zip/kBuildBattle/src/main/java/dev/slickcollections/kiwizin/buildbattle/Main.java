package dev.slickcollections.kiwizin.buildbattle;

import dev.slickcollections.kiwizin.Core;
import dev.slickcollections.kiwizin.buildbattle.cmd.Commands;
import dev.slickcollections.kiwizin.buildbattle.game.BuildBattle;
import dev.slickcollections.kiwizin.buildbattle.hook.BBCoreHook;
import dev.slickcollections.kiwizin.buildbattle.listeners.Listeners;
import dev.slickcollections.kiwizin.buildbattle.lobby.DeliveryNPC;
import dev.slickcollections.kiwizin.buildbattle.lobby.Lobby;
import dev.slickcollections.kiwizin.buildbattle.lobby.PlayNPC;
import dev.slickcollections.kiwizin.buildbattle.lobby.StatsNPC;
import dev.slickcollections.kiwizin.libraries.MinecraftVersion;
import dev.slickcollections.kiwizin.plugin.KPlugin;
import dev.slickcollections.kiwizin.utils.BukkitUtils;

public class Main extends KPlugin {
  
  public static boolean kCosmetics, kMysteryBox;
  public static String currentServerName;
  private static Main instance;
  private static boolean validInit;
  
  @Override
  public void start() {
    instance = this;
  }
  
  @Override
  public void load() {}
  
  @Override
  public void enable() {
    if (MinecraftVersion.getCurrentVersion().getCompareId() != 183) {
      this.setEnabled(false);
      this.getLogger().warning("O plugin apenas funciona na versao 1_8_R3 (Atual: " + MinecraftVersion.getCurrentVersion().getVersion() + ")");
      return;
    }
  
    saveDefaultConfig();
    currentServerName = getConfig().getString("lobby");
    if (getConfig().getString("spawn") != null) {
      Core.setLobby(BukkitUtils.deserializeLocation(getConfig().getString("spawn")));
    }
  
    BuildBattle.setupGames();
    Commands.setupCommands();
    StatsNPC.setupNPCs();
  
    Language.setupLanguage();
    PlayNPC.setupNPCs();
    Lobby.setupLobbies();
    BBCoreHook.setupHook();
    DeliveryNPC.setupNPCs();
    Listeners.setupListeners();
    
    validInit = true;
    this.getLogger().info("O plugin foi ativado.");
  }
  
  @Override
  public void disable() {
    this.getLogger().info("O plugin foi desativado.");
  }
  
  public static Main getInstance() {
    return instance;
  }
}
