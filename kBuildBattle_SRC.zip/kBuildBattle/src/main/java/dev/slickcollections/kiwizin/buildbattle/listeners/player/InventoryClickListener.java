package dev.slickcollections.kiwizin.buildbattle.listeners.player;

import dev.slickcollections.kiwizin.buildbattle.cmd.bb.BuildCommand;
import dev.slickcollections.kiwizin.buildbattle.game.BuildBattle;
import dev.slickcollections.kiwizin.game.GameState;
import dev.slickcollections.kiwizin.player.Profile;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

public class InventoryClickListener implements Listener {
  
  @EventHandler(priority = EventPriority.LOWEST)
  public void onInventoryClick(InventoryClickEvent evt) {
    if (evt.getWhoClicked() instanceof Player) {
      Player player = (Player) evt.getWhoClicked();
      Profile profile = Profile.getProfile(player.getName());
      
      if (profile != null) {
        ItemStack item = evt.getCurrentItem();
        BuildBattle game = profile.getGame(BuildBattle.class);
        if (game == null) {
          evt.setCancelled(!BuildCommand.hasBuilder(player));
        } else if (game.isSpectator(player) || game.getState() != GameState.EMJOGO) {
          evt.setCancelled(true);
        } else if (game.getState() == GameState.EMJOGO && !game.isSpectator(player) && item != null && item.getType().equals(Material.NETHER_STAR)) {
          evt.setCancelled(true);
        }
      }
    }
  }
}
