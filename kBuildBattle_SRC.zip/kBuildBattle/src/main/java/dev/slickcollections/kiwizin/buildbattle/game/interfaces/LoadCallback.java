package dev.slickcollections.kiwizin.buildbattle.game.interfaces;

public interface LoadCallback {
  void finish();
}
