package dev.slickcollections.kiwizin.buildbattle.game;

import com.google.gson.JsonObject;
import dev.slickcollections.kiwizin.Manager;
import dev.slickcollections.kiwizin.buildbattle.Language;
import dev.slickcollections.kiwizin.buildbattle.Main;
import dev.slickcollections.kiwizin.buildbattle.game.enums.BuildBattleMode;
import dev.slickcollections.kiwizin.buildbattle.game.interfaces.LoadCallback;
import dev.slickcollections.kiwizin.buildbattle.game.object.BuildBattleBlock;
import dev.slickcollections.kiwizin.buildbattle.game.object.BuildBattleConfig;
import dev.slickcollections.kiwizin.buildbattle.game.object.BuildBattleTask;
import dev.slickcollections.kiwizin.buildbattle.game.object.Vote;
import dev.slickcollections.kiwizin.buildbattle.utils.tagger.TagUtils;
import dev.slickcollections.kiwizin.bukkit.BukkitParty;
import dev.slickcollections.kiwizin.bukkit.BukkitPartyManager;
import dev.slickcollections.kiwizin.game.FakeGame;
import dev.slickcollections.kiwizin.game.Game;
import dev.slickcollections.kiwizin.game.GameState;
import dev.slickcollections.kiwizin.game.GameTeam;
import dev.slickcollections.kiwizin.nms.NMS;
import dev.slickcollections.kiwizin.party.PartyPlayer;
import dev.slickcollections.kiwizin.player.Profile;
import dev.slickcollections.kiwizin.player.hotbar.Hotbar;
import dev.slickcollections.kiwizin.player.role.Role;
import dev.slickcollections.kiwizin.plugin.config.KConfig;
import dev.slickcollections.kiwizin.plugin.logger.KLogger;
import dev.slickcollections.kiwizin.utils.BukkitUtils;
import dev.slickcollections.kiwizin.utils.CubeID;
import dev.slickcollections.kiwizin.utils.StringUtils;
import dev.slickcollections.kiwizin.utils.enums.EnumSound;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Chest;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scoreboard.NameTagVisibility;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.io.File;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;
import java.util.stream.Collectors;

import static dev.slickcollections.kiwizin.buildbattle.hook.BBCoreHook.reloadScoreboard;

public class BuildBattle implements Game<BuildBattleTeam> {
  
  protected String name;
  protected BuildBattleConfig config;
  
  protected int timer;
  protected BuildBattleTask task;
  protected GameState state;
  public Map<BuildBattleTeam, Vote> plotsRating;
  public Map<Player, Long> CACHE_POINTS;
  protected List<UUID> players;
  protected String theme;
  protected List<UUID> spectators;
  protected List<Block> placedBlocks;
  protected int actualPlot;
  
  protected Map<String, BuildBattleBlock> blocks = new HashMap<>();
  
  public BuildBattle(String name, LoadCallback callback) {
    this.name = name;
    this.timer = Language.options$start$waiting + 1;
    this.task = new BuildBattleTask(this);
    this.task.reset();
    this.config = new BuildBattleConfig(this);
    this.config.setupSpawns();
    this.CACHE_POINTS = new HashMap<>();
    this.players = new ArrayList<>();
    this.plotsRating = new HashMap<>();
    this.placedBlocks = new ArrayList<>();
    this.spectators = new ArrayList<>();
    this.state = GameState.AGUARDANDO;
  
    if (!Language.options$regen$world_reload) {
      KConfig config = Main.getInstance().getConfig("blocos", name);
      if (config.contains("dataBlocks")) {
        for (String blockdata : config.getStringList("dataBlocks")) {
          blocks.put(blockdata.split(" : ")[0],
              new BuildBattleBlock(Material.matchMaterial(blockdata.split(" : ")[1].split(", ")[0]), Byte.parseByte(blockdata.split(" : ")[1].split(", ")[1])));
        }
      } else {
        this.state = GameState.ENCERRADO;
        ArenaRollbackerTask.scan(this, config, callback);
      }
    } else if (callback != null) {
      callback.finish();
    }
  }
  
  public void addSpawn(JsonObject spawn) {
    this.listTeams().add(new BuildBattleTeam(this, spawn.toString(), this.getMode().getSize()));
    this.config.listSpawns().add(spawn.toString());
    this.config.getConfig().set("spawns", this.config.listSpawns());
  }
  
  public void setTheme(String newTheme) {
    this.theme = newTheme;
  }
  
  public String getTheme() {
    return this.theme;
  }
  
  public boolean isPlacedBlock(Block block) {
    return !placedBlocks.contains(block);
  }
  
  public void addPlacedBlock(Block block) {
    placedBlocks.add(block);
  }
  
  public void removePlacedBlock(Block block) {
    placedBlocks.remove(block);
  }
  
  @Override
  public void broadcastMessage(String message) {
    this.broadcastMessage(message, true);
  }
  
  @Override
  public void broadcastMessage(String message, boolean spectators) {
    this.listPlayers().forEach(player -> player.sendMessage(message));
  }

  
  public void joinParty(Profile profile, boolean ignoreLeader) {
    Player player = profile.getPlayer();
    if (player == null || !this.state.canJoin() || this.players.size() >= this.getMaxPlayers()) {
      return;
    }
  
    if (profile.getGame() != null && profile.getGame().equals(this)) {
      return;
    }
  
    BuildBattleTeam team = null;
    boolean fullSize = false;
    BukkitParty party = BukkitPartyManager.getMemberParty(player.getName());
    if (party != null) {
      if (!ignoreLeader) {
        if (!party.isLeader(player.getName())) {
          player.sendMessage("§cApenas o líder da Party pode buscar por partidas.");
          return;
        }
      
        if (party.onlineCount() + players.size() > getMaxPlayers()) {
          return;
        }
      
        fullSize = true;
        Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(),
            () -> party.listMembers().stream().filter(PartyPlayer::isOnline).map(pp -> Profile.getProfile(pp.getName()))
                .filter(pp -> pp != null && pp.getGame(FakeGame.class) == null).forEach(pp -> joinParty(pp, true)), 5);
      } else {
        team =
            listTeams().stream().filter(st -> st.canJoin() && (party.listMembers().stream().anyMatch(pp -> pp.isOnline() && st.hasMember((Player) Manager.getPlayer(pp.getName())))))
                .findAny().orElse(null);
      }
    }
  
    team = team == null ? getAvailableTeam(fullSize ? this.getMode().getSize() : 1) : team;
    if (team == null) {
      return;
    }
  
    team.addMember(player);
    if (profile.getGame() != null) {
      profile.getGame().leave(profile, profile.getGame());
    }
  
    this.players.add(player.getUniqueId());
    profile.setGame(this);
    
    player.teleport(this.getConfig().getWaitingLocation());
    reloadScoreboard(profile);
  
    profile.setHotbar(Hotbar.getHotbarById("waiting"));
    profile.refresh();
    for (Player players : Bukkit.getOnlinePlayers()) {
      if (!players.getWorld().equals(player.getWorld())) {
        player.hidePlayer(players);
        players.hidePlayer(player);
        continue;
      }
    
      if (isSpectator(players)) {
        player.hidePlayer(players);
      } else {
        player.showPlayer(players);
      }
      players.showPlayer(player);
    }
  
    this.broadcastMessage(Language.ingame$broadcast$join.replace("{player}", Role.getColored(player.getName())).replace("{players}", String.valueOf(this.getOnline()))
        .replace("{max_players}", String.valueOf(this.getMaxPlayers())));
    if (this.getOnline() == this.getMaxPlayers() && this.timer > Language.options$start$full) {
      this.timer = Language.options$start$full;
    }
  }
  
  @Override
  public void join(Profile profile) {
    this.joinParty(profile, false);
  }
  
  @Override
  public void leave(Profile profile, Game<?> game) {
    Player player = profile.getPlayer();
    if (player == null || profile.getGame() != this) {
      return;
    }
  
    BuildBattleTeam team = this.getTeam(player);
  
    boolean alive = this.players.contains(player.getUniqueId());
    this.players.remove(player.getUniqueId());
    this.spectators.remove(player.getUniqueId());
  
    if (game != null) {
      if (team != null) {
        team.removeMember(player);
      }
      if (Profile.isOnline(player.getName())) {
        profile.setGame(null);
        TagUtils.setTag(player);
      }
      if (this.state == GameState.AGUARDANDO) {
        this.broadcastMessage(Language.ingame$broadcast$leave.replace("{player}", Role.getColored(player.getName())).replace("{players}", String.valueOf(this.getOnline()))
            .replace("{max_players}", String.valueOf(this.getMaxPlayers())));
      }
      this.check();
      return;
    }
  
    if (team != null) {
      team.removeMember(player);
    }
    profile.setGame(null);
    TagUtils.setTag(player);
    reloadScoreboard(profile);
    profile.setHotbar(Hotbar.getHotbarById("lobby"));
    profile.refresh();
    if (this.state == GameState.AGUARDANDO) {
      this.broadcastMessage(Language.ingame$broadcast$leave.replace("{player}", Role.getColored(player.getName())).replace("{players}", String.valueOf(this.getOnline()))
          .replace("{max_players}", String.valueOf(this.getMaxPlayers())));
    }
    this.check();
  }
  
  @Override
  public void kill(Profile profile, Profile killer) {}
  
  @Override
  public void killLeave(Profile profile, Profile killer) {}
  
  @Override
  public void start() {
    this.check();
    
    if (this.getState() != GameState.ENCERRADO) {
      // TODO: Sortear
      new BukkitRunnable() {
        long initTime = 6;
    
        @Override
        public void run() {
          List<Player> players = listPlayers(false);
          String randomTheme = Language.options$themes.get(ThreadLocalRandom.current().nextInt(Language.options$themes.size()));
          players.forEach(a -> NMS.sendTitle(a, "§e§lTema:", "§7§k" + randomTheme));
          initTime--;
          if (initTime <= 0) {
            cancel();
            String generatedTheme = Language.options$themes.get(ThreadLocalRandom.current().nextInt(Language.options$themes.size()));
            players.forEach(player -> NMS.sendTitle(player, "§e§lTema:", "§7" + generatedTheme));
            setTheme(generatedTheme);
            startGame();
          }
        }
      }.runTaskTimer(Main.getInstance(), 0, 11);
    }
  }
  
  public void startGame() {
    this.state = GameState.EMJOGO;
    this.task.swap(null);
  
    this.listTeams().forEach(a -> a.listPlayers().forEach(p -> p.teleport(a.getLocation())));
  
    for (Player player : this.listPlayers(false)) {
      Profile profile = Profile.getProfile(player.getName());
      reloadScoreboard(profile);
      profile.setHotbar(null);
      profile.addStats("kCoreBuildBattle", Language.options$points$play, "points");
      profile.addStats("kCoreBuildBattle", "games");
      profile.refresh();
      player.getInventory().clear();
      player.getInventory().setArmorContents(null);
      player.getInventory().setItem(8, BukkitUtils.deserializeItemStack("NETHER_STAR : 1 : nome>&aOpções"));
      player.updateInventory();
      player.setAllowFlight(true);
      player.setFlying(true);
      player.setGameMode(GameMode.CREATIVE);
    }
  
    this.updateTags();
    this.check();
  }
  
  @Override
  public void stop(BuildBattleTeam winners) {
    this.state = GameState.ENCERRADO;
  
    StringBuilder name = new StringBuilder();
    List<Player> players = winners != null ? winners.listPlayers() : null;
    if (players != null) {
      for (Player player : players) {
        if (!name.toString().isEmpty()) {
          name.append(" §ae ").append(Role.getColored(player.getName()));
        } else {
          name = new StringBuilder(Role.getColored(player.getName()));
        }
      }
    
      players.clear();
    }
    if (name.toString().isEmpty()) {
      this.broadcastMessage("\n §eA partida acabou, não houve vencedores! \n ");
    } else {
      this.broadcastMessage((this.getMode() == BuildBattleMode.SOLO ? Language.ingame$broadcast$win$solo : Language.ingame$broadcast$win$dupla).replace("{name}", name.toString()));
    }
    for (Player player : this.listPlayers(false)) {
      Profile profile = Profile.getProfile(player.getName());
      profile.update();
      BuildBattleTeam team = this.getTeam(player);
      
      List<Vote> cloneRatings = new ArrayList<>(this.plotsRating.values());
      if (!cloneRatings.isEmpty()) {
        cloneRatings.sort((a, b) -> Collections.reverseOrder().compare(a.getAmount(), b.getAmount()));
        StringBuilder T = new StringBuilder();
        if (cloneRatings.size() < 1) {
          T.append("§7Ninguém");
        } else {
          for (Player r : cloneRatings.get(0).getTeam().listPlayers()) {
            if (!T.toString().isEmpty()) {
              T.append(" §ae ").append(Role.getColored(r.getName()));
            } else {
              T = new StringBuilder(Role.getColored(r.getName()));
            }
          }
        }
        StringBuilder F = new StringBuilder();
        if (cloneRatings.size() < 2) {
          F.append("§7Ninguém");
        } else {
          for (Player r : cloneRatings.get(1).getTeam().listPlayers()) {
            if (!F.toString().isEmpty()) {
              F.append(" §ae ").append(Role.getColored(r.getName()));
            } else {
              F = new StringBuilder(Role.getColored(r.getName()));
            }
          }
        }
        StringBuilder X = new StringBuilder();
        if (cloneRatings.size() < 3) {
          X.append("§7Ninguém");
        } else {
          for (Player r : cloneRatings.get(2).getTeam().listPlayers()) {
            if (!X.toString().isEmpty()) {
              X.append(" §ae ").append(Role.getColored(r.getName()));
            } else {
              X = new StringBuilder(Role.getColored(r.getName()));
            }
          }
        }
  
        StringBuilder finalT = T;
        StringBuilder finalF = F;
        StringBuilder finalX = X;
        Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () ->
            player.sendMessage(Language.ingame$broadcast$top.replace("{top_1}", finalT).replace("{top_2}", finalF).replace("{top_3}", finalX).replace("{points}",
                StringUtils.formatNumber(this.plotsRating.get(team).getAmount()))), 30);
      }
      if (winners != null && winners.hasMember(player)) {
        profile.addCoinsWM("kCoreBuildBattle", Language.options$coins$wins);
        profile.addStats("kCoreBuildBattle", Language.options$points$wins, "points");
        profile.addStats("kCoreBuildBattle", "wins");
        NMS.sendTitle(player, Language.ingame$titles$win$header, Language.ingame$titles$win$footer, 10, 80, 10);
      } else {
        NMS.sendTitle(player, Language.ingame$titles$lose$header, Language.ingame$titles$lose$footer, 10, 80, 10);
      }
    
      this.spectators.add(player.getUniqueId());
      profile.setHotbar(Hotbar.getHotbarById("spectator"));
      profile.refresh();
      player.setGameMode(GameMode.ADVENTURE);
      player.setAllowFlight(true);
      player.setFlying(true);
    }
  
    this.updateTags();
    this.task.swap(winners);
  }
  
  public void startVotes() {
    this.actualPlot = 0;
    this.setState(GameState.INICIANDO);
    this.task.swap(null);
    this.nextVote();
  }
  
  public long getVotes(BuildBattleTeam team) {
    return this.plotsRating.get(team) == null ? 0L : this.plotsRating.get(team).getAmount();
  }
  
  public void addVote(BuildBattleTeam team, Player player, long amount) {
    CACHE_POINTS.put(player, amount);
    this.plotsRating.get(team).increasePoints(amount);
  }
  
  public void removeVote(BuildBattleTeam team, Player player) {
    if (CACHE_POINTS.get(player) != null) {
      this.plotsRating.get(team).decreasePoints(CACHE_POINTS.get(player));
    }
  }
  
  public int getActualPlot() {
    return this.actualPlot;
  }
  
  public void nextVote() {
    this.check();
    this.setTimer(15);
    BuildBattleTeam votingTeam = this.listTeams().get(this.actualPlot);
    if (votingTeam == null || !this.getState().equals(GameState.INICIANDO)) {
      return;
    }
    this.plotsRating.put(votingTeam, new Vote(votingTeam, 0L));
    List<Player> players = this.listPlayers(false);
    players.forEach(player -> {
      StringBuilder name = new StringBuilder();
      for (Player playerd : votingTeam.listPlayers()) {
        if (!name.toString().isEmpty()) {
          name.append(" §ae ").append(Role.getColored(playerd.getName()));
        } else {
          name = new StringBuilder(Role.getColored(playerd.getName()));
        }
      }
      player.sendMessage("§eConstrutor: " + name);
      Location a = votingTeam.getLocation();
      a.setY(votingTeam.getLocation().getWorld().getHighestBlockYAt(votingTeam.getLocation()));
      player.teleport(a);
      votingTeam.getManager().applyTo(players);
      player.getInventory().clear();
      player.getInventory().setArmorContents(null);
      if (!votingTeam.equals(this.getTeam(player))) {
        CACHE_POINTS.remove(player);
        player.getInventory().setItem(0, BukkitUtils.deserializeItemStack("159:6 : 1 : nome>&4&lPÉSSIMO"));
        player.getInventory().setItem(1, BukkitUtils.deserializeItemStack("159:14 : 1 : nome>&c&lRUIM"));
        player.getInventory().setItem(2, BukkitUtils.deserializeItemStack("159:5 : 1 : nome>&a&lACEITÁVEL"));
        player.getInventory().setItem(3, BukkitUtils.deserializeItemStack("159:13 : 1 : nome>&2&lBOM"));
        player.getInventory().setItem(4, BukkitUtils.deserializeItemStack("159:11 : 1 : nome>&5&lÉPICO"));
        player.getInventory().setItem(5, BukkitUtils.deserializeItemStack("159:4 : 1 : nome>&6&lLENDÁRIO"));
      }
      EnumSound.ORB_PICKUP.play(player, 1.0f, 1.0f);
    });
    this.actualPlot++;
  }
  
  public void check() {
    if (this.getState() == GameState.ENCERRADO || this.getState() == GameState.AGUARDANDO) {
      return;
    }
  
    List<BuildBattleTeam> teams = this.listTeams().stream().filter(GameTeam::isAlive).collect(Collectors.toList());
    if (this.actualPlot >= teams.size() || teams.size() <= 1) {
      this.stop(teams.size() <= 1 ? teams.isEmpty() ? null : teams.get(0) : this.generateWinner());
    }
  }
  
  public BuildBattleTeam generateWinner() {
    List<Vote> cloneRatings = new ArrayList<>(this.plotsRating.values());
    cloneRatings.sort((a, b) -> Collections.reverseOrder().compare(a.getAmount(), b.getAmount()));
    List<BuildBattleTeam> teams = this.listTeams().stream().filter(GameTeam::isAlive).collect(Collectors.toList());
  
    return cloneRatings.isEmpty() ? teams.isEmpty() ? null : teams.get(0) :
        cloneRatings.get(0).getTeam();
  }
  
  private void updateTags() {
    for (Player player : this.listPlayers()) {
      Scoreboard scoreboard = player.getScoreboard();
      
      for (Player players : this.listPlayers()) {
        BuildBattleTeam gt;
        
        if (this.isSpectator(players)) {
          Team team = scoreboard.getEntryTeam(players.getName());
          if (team != null && !team.getName().equals("spectators")) {
            if (team.getSize() == 1) {
              team.unregister();
            } else {
              team.removeEntry(players.getName());
            }
            team = null;
          }
          
          if (team == null) {
            team = scoreboard.getTeam("spectators");
            if (team == null) {
              team = scoreboard.registerNewTeam("spectators");
              team.setPrefix("§8");
              team.setCanSeeFriendlyInvisibles(true);
            }
            
            if (!team.hasEntry(players.getName())) {
              team.addEntry(players.getName());
            }
          }
        } else if ((gt = this.getTeam(players)) != null) {
          Team team = scoreboard.getTeam(gt.getName());
          if (team == null) {
            team = scoreboard.registerNewTeam(gt.getName());
            team.setPrefix("§a");
          }
          
          if (!team.hasEntry(players.getName())) {
            team.addEntry(players.getName());
          }
        }
      }
    }
  }
  
  @Override
  public void reset() {
    this.plotsRating.clear();
    this.actualPlot = 0;
    this.players.clear();
    this.spectators.clear();
    this.CACHE_POINTS.clear();
    this.task.cancel();
    this.listTeams().forEach(BuildBattleTeam::reset);
    addToQueue(this);
  }
  
  public void setTimer(int timer) {
    this.timer = timer;
  }
  
  public int getTimer() {
    return this.timer;
  }
  
  @Override
  public String getGameName() {
    return this.name;
  }
  
  @Override
  public GameState getState() {
    return this.state;
  }
  
  @Override
  public boolean isSpectator(Player player) {
    return this.spectators.contains(player.getUniqueId());
  }
  
  public void setState(GameState state) {
    this.state = state;
  }
  
  @Override
  public int getOnline() {
    return this.players.size();
  }
  
  @Override
  public int getMaxPlayers() {
    return this.config.listSpawns().size();
  }
  public BuildBattleConfig getConfig() {
    return this.config;
  }
  
  public World getWorld() {
    return this.config.getWorld();
  }
  
  public BuildBattleTask getTask() {
    return this.task;
  }
  
  public CubeID getCubeId() {
    return this.config.getCubeId();
  }
  
  
  public void resetBlock(Block block) {
    BuildBattleBlock sb = this.blocks.get(BukkitUtils.serializeLocation(block.getLocation()));
    
    if (sb != null) {
      block.setType(sb.getMaterial());
      BlockState state = block.getState();
      state.getData().setData(sb.getData());
      if (state instanceof Chest) {
        ((Chest) state).getInventory().clear();
      }
      state.update(true);
    } else {
      block.setType(Material.AIR);
    }
  }
  
  public String getMapName() {
    return this.config.getMapName();
  }
  
  public Map<String, BuildBattleBlock> getBlocks() {
    return this.blocks;
  }
  
  public BuildBattleMode getMode() {
    return this.config.getMode();
  }
  
  public BuildBattleTeam getAvailableTeam(int teamSize) {
    return this.listTeams().stream().filter(team -> team.canJoin(teamSize)).findAny().orElse(null);
  }
  
  @Override
  public BuildBattleTeam getTeam(Player player) {
    return this.listTeams().stream().filter(team -> team.hasMember(player)).findAny().orElse(null);
  }
  
  @Override
  public List<BuildBattleTeam> listTeams() {
    return this.config.listTeams();
  }
  
  @Override
  public List<Player> listPlayers() {
    return this.listPlayers(true);
  }
  
  @Override
  public List<Player> listPlayers(boolean spectators) {
    List<Player> players = new ArrayList<>(
        spectators ? this.spectators.size() + this.players.size() : this.players.size());
    this.players.forEach(id -> players.add(Bukkit.getPlayer(id)));
    if (spectators) {
      this.spectators.stream().filter(id -> !this.players.contains(id))
          .forEach(id -> players.add(Bukkit.getPlayer(id)));
    }
    
    return players.stream().filter(Objects::nonNull).collect(Collectors.toList());
  }
  
  public static final KLogger LOGGER = ((KLogger) Main.getInstance().getLogger()).getModule("GAME");
  protected static final List<BuildBattle> QUEUE = new ArrayList<>();
  private static final Map<String, BuildBattle> GAMES = new HashMap<>();
  
  public static void addToQueue(BuildBattle game) {
    if (QUEUE.contains(game)) {
      return;
    }
    
    QUEUE.add(game);
  }
  
  public static void setupGames() {
    new ArenaRollbackerTask().runTaskTimer(Main.getInstance(), 0, 100);
    
    File ymlFolder = new File("plugins/kBuildBattle/arenas");
    File mapFolder = new File("plugins/kBuildBattle/mundos");
    
    if (!ymlFolder.exists() || !mapFolder.exists()) {
      if (!ymlFolder.exists()) {
        ymlFolder.mkdirs();
      }
      if (!mapFolder.exists()) {
        mapFolder.mkdirs();
      }
    }
    
    for (File file : ymlFolder.listFiles()) {
      load(file, null);
    }
    
    LOGGER.info("Foram carregadas " + GAMES.size() + " salas.");
  }
  
  public static void load(File yamlFile, LoadCallback callback) {
    String arenaName = yamlFile.getName().split("\\.")[0];
    
    try {
      File backup = new File("plugins/kBuildBattle/mundos", arenaName);
      if (!backup.exists() || !backup.isDirectory()) {
        throw new IllegalArgumentException(
            "Backup do mapa nao encontrado para a arena \"" + yamlFile.getName() + "\"");
      }
      
      BuildBattleMode mode = BuildBattleMode
          .fromName(Main.getInstance().getConfig("arenas", arenaName).getString("mode"));
      if (mode == null) {
        throw new IllegalArgumentException(
            "Modo do mapa \"" + yamlFile.getName() + "\" nao e valido");
      }
      
      GAMES.put(arenaName, new BuildBattle(arenaName, callback));
    } catch (Exception ex) {
      LOGGER.log(Level.WARNING, "load(\"" + yamlFile.getName() + "\"): ", ex);
    }
  }
  
  public static BuildBattle getByWorldName(String worldName) {
    return GAMES.get(worldName);
  }
  
  public static int getWaiting(BuildBattleMode mode) {
    int waiting = 0;
    List<BuildBattle> games = listByMode(mode);
    for (BuildBattle game : games) {
      if (game.getState() != GameState.EMJOGO) {
        waiting += game.getOnline();
      }
    }
    
    return waiting;
  }
  
  public static int getPlaying(BuildBattleMode mode) {
    int playing = 0;
    List<BuildBattle> games = listByMode(mode);
    for (BuildBattle game : games) {
      if (game.getState() == GameState.EMJOGO) {
        playing += game.getOnline();
      }
    }
    
    return playing;
  }
  
  public static BuildBattle findRandom(BuildBattleMode mode) {
    List<BuildBattle> games = GAMES.values().stream().filter(
            game -> game.getMode().equals(mode) && game.getState().canJoin() && game.getOnline() < game
                .getMaxPlayers())
        .sorted((g1, g2) -> Integer.compare(g2.getOnline(), g1.getOnline()))
        .collect(Collectors.toList());
    BuildBattle game = games.stream().findFirst().orElse(null);
    if (game != null && game.getOnline() == 0) {
      game = games.get(ThreadLocalRandom.current().nextInt(games.size()));
    }
    
    return game;
  }
  
  public static Map<String, List<BuildBattle>> getAsMap(BuildBattleMode mode) {
    Map<String, List<BuildBattle>> result = new HashMap<>();
    GAMES.values().stream().filter(
        game -> game.getMode().equals(mode) && game.getState().canJoin() && game.getOnline() < game
            .getMaxPlayers()).forEach(game -> {
      List<BuildBattle> list = result.computeIfAbsent(game.getMapName(), k -> new ArrayList<>());
      
      if (game.getState().canJoin() && game.getOnline() < game.getMaxPlayers()) {
        list.add(game);
      }
    });
    
    return result;
  }
  
  public static List<BuildBattle> listByMode(BuildBattleMode mode) {
    return GAMES.values().stream().filter(mm -> mm.getMode().equals(mode))
        .collect(Collectors.toList());
  }
}
