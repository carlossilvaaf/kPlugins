package dev.slickcollections.kiwizin.buildbattle.menus.game;

import dev.slickcollections.kiwizin.buildbattle.Main;
import dev.slickcollections.kiwizin.buildbattle.game.BuildBattle;
import dev.slickcollections.kiwizin.buildbattle.game.BuildBattleTeam;
import dev.slickcollections.kiwizin.buildbattle.game.object.PlotManager;
import dev.slickcollections.kiwizin.libraries.menu.PlayerMenu;
import dev.slickcollections.kiwizin.player.Profile;
import dev.slickcollections.kiwizin.utils.BukkitUtils;
import dev.slickcollections.kiwizin.utils.enums.EnumSound;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class MenuSelectTime extends PlayerMenu {
  
  public MenuSelectTime(Profile profile) {
    super(profile.getPlayer(), "Tempo da Plot", 5);
    
    this.setItem(11, BukkitUtils.deserializeItemStack("159:14 : 1 : nome>&aAmanhecer"));
    this.setItem(12, BukkitUtils.deserializeItemStack("159:14 : 1 : nome>&aDia"));
    this.setItem(13, BukkitUtils.deserializeItemStack("159:14 : 1 : nome>&aAnoitecer"));
    this.setItem(14, BukkitUtils.deserializeItemStack("159:14 : 1 : nome>&aNoite"));
  
    this.setItem(40, BukkitUtils.deserializeItemStack("INK_SACK:1 : 1 : nome>&cVoltar"));
    
    this.register(Main.getInstance());
    this.open();
  }
  
  @EventHandler
  public void onInventoryClick(InventoryClickEvent evt) {
    if (evt.getInventory().equals(this.getInventory())) {
      evt.setCancelled(true);
      
      if (evt.getWhoClicked().equals(this.player)) {
        Profile profile = Profile.getProfile(this.player.getName());
        if (profile == null) {
          this.player.closeInventory();
          return;
        }
        
        if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getInventory())) {
          ItemStack item = evt.getCurrentItem();
          BuildBattleTeam team = profile.getGame(BuildBattle.class).getTeam(this.player);
          PlotManager manager = team.getManager();
          
          if (item != null && item.getType() != Material.AIR) {
            if (evt.getSlot() == 40) {
              EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
              new MenuSettings(profile);
            } else if (evt.getSlot() == 11) {
              EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
              manager.changeTiming(this.player, "amanhecer");
              manager.applyTo(team.listPlayers());
              player.sendMessage("§aTempo alterado para: " + item.getItemMeta().getDisplayName());
            } else if (evt.getSlot() == 12) {
              EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
              manager.changeTiming(this.player, "dia");
              manager.applyTo(team.listPlayers());
              player.sendMessage("§aTempo alterado para: " + item.getItemMeta().getDisplayName());
            } else if (evt.getSlot() == 13) {
              EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
              manager.changeTiming(this.player, "anoitecer");
              manager.applyTo(team.listPlayers());
              player.sendMessage("§aTempo alterado para: " + item.getItemMeta().getDisplayName());
            } else if (evt.getSlot() == 14) {
              EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
              manager.changeTiming(this.player, "noite");
              manager.applyTo(team.listPlayers());
              player.sendMessage("§aTempo alterado para: " + item.getItemMeta().getDisplayName());
            }
          }
        }
      }
    }
  }
  
  public void cancel() {
    HandlerList.unregisterAll(this);
  }
  
  @EventHandler
  public void onPlayerQuit(PlayerQuitEvent evt) {
    if (evt.getPlayer().equals(this.player)) {
      this.cancel();
    }
  }
  
  @EventHandler
  public void onInventoryClose(InventoryCloseEvent evt) {
    if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getInventory())) {
      this.cancel();
    }
  }
}
