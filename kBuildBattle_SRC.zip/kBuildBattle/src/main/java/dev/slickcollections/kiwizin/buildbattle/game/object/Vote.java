package dev.slickcollections.kiwizin.buildbattle.game.object;

import dev.slickcollections.kiwizin.buildbattle.game.BuildBattleTeam;

public class Vote {
  
  protected BuildBattleTeam team;
  protected long amount;
  
  public Vote(BuildBattleTeam team, long amount) {
    this.team = team;
    this.amount = amount;
  }

  public void increasePoints(long add) {
    this.amount =+ add;
  }
  
  public void decreasePoints(long add) {
    this.amount =- add;
  }
  
  public BuildBattleTeam getTeam() { return this.team; }
  
  public long getAmount() { return this.amount; }
}
