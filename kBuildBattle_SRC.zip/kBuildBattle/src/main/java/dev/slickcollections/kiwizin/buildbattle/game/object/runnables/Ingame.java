package dev.slickcollections.kiwizin.buildbattle.game.object.runnables;

import dev.slickcollections.kiwizin.buildbattle.game.BuildBattle;
import dev.slickcollections.kiwizin.player.Profile;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.List;

public class Ingame extends BukkitRunnable {
  
  private BuildBattle game;
  
  public Ingame(BuildBattle game) {
    this.game = game;
  }
  
  @Override
  public void run() {
    if (this.game.getTimer() == 0) {
      this.game.startVotes();
      return;
    }
    
    List<Player> players = this.game.listPlayers();
    players.forEach(player -> {
      if (!this.game.getCubeId().contains(player.getLocation())) {
        player.teleport(this.game.getTeam(player).getLocation());
      }
      Profile.getProfile(player.getName()).update();
    });
    
    this.game.setTimer(game.getTimer() - 1);
  }
  
  @Override
  public synchronized void cancel() throws IllegalStateException {
    super.cancel();
    this.game = null;
  }
}
