package dev.slickcollections.kiwizin.buildbattle.hook;

import com.comphenix.protocol.ProtocolLibrary;
import dev.slickcollections.kiwizin.Core;
import dev.slickcollections.kiwizin.buildbattle.Language;
import dev.slickcollections.kiwizin.buildbattle.Main;
import dev.slickcollections.kiwizin.buildbattle.game.BuildBattle;
import dev.slickcollections.kiwizin.buildbattle.hook.hotbar.BBHotbarActionType;
import dev.slickcollections.kiwizin.buildbattle.hook.protocollib.HologramAdapter;
import dev.slickcollections.kiwizin.game.GameState;
import dev.slickcollections.kiwizin.player.Profile;
import dev.slickcollections.kiwizin.player.hotbar.Hotbar;
import dev.slickcollections.kiwizin.player.hotbar.HotbarAction;
import dev.slickcollections.kiwizin.player.hotbar.HotbarActionType;
import dev.slickcollections.kiwizin.player.hotbar.HotbarButton;
import dev.slickcollections.kiwizin.player.scoreboard.KScoreboard;
import dev.slickcollections.kiwizin.player.scoreboard.scroller.ScoreboardScroller;
import dev.slickcollections.kiwizin.plugin.config.KConfig;
import dev.slickcollections.kiwizin.utils.StringUtils;
import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.logging.Level;

public class BBCoreHook {
  
  public static void setupHook() {
    Core.minigame = "Build Battle";
    
    setupHotbars();
    new BukkitRunnable() {
      @Override
      public void run() {
        Profile.listProfiles().forEach(profile -> {
          if (profile.getScoreboard() != null) {
            profile.getScoreboard().scroll();
          }
        });
      }
    }.runTaskTimerAsynchronously(Main.getInstance(), 0, Language.scoreboards$scroller$every_tick);
    
    new BukkitRunnable() {
      @Override
      public void run() {
        Profile.listProfiles().forEach(profile -> {
          if (!profile.playingGame() && profile.getScoreboard() != null) {
            profile.update();
          }
        });
      }
    }.runTaskTimerAsynchronously(Main.getInstance(), 0, 20);
    
    ProtocolLibrary.getProtocolManager().addPacketListener(new HologramAdapter());
  }
  
  public static void checkAchievements(Profile profile) {
    Bukkit.getScheduler().runTaskAsynchronously(Main.getInstance(), () -> {
     // Achievement.listAchievements(SkyWarsAchievement.class).stream().filter(swa -> swa.canComplete(profile)).forEach(swa -> {
     //   swa.complete(profile);
     //   profile.getPlayer().sendMessage(Language.lobby$achievement.replace("{name}", swa.getName()));
     // });
    });
  }
  
  private static final SimpleDateFormat SDF = new SimpleDateFormat("mm:ss");
  
  public static void reloadScoreboard(Profile profile) {
    if (!profile.playingGame()) {
      checkAchievements(profile);
    }
    Player player = profile.getPlayer();
    BuildBattle game = profile.getGame(BuildBattle.class);
    List<String> lines = game == null ?
        Language.scoreboards$lobby :
        game.getState() == GameState.AGUARDANDO ?
            Language.scoreboards$waiting :
            Language.scoreboards$ingame;
    profile.setScoreboard(new KScoreboard() {
      @Override
      public void update() {
        for (int index = 0; index < Math.min(lines.size(), 15); index++) {
          String line = lines.get(index);
          
          if (game != null) {
            line = line.replace("{map}", game.getMapName())
                .replace("{server}", game.getGameName())
                .replace("{mode}", game.getMode().getName())
                .replace("{max_players}", StringUtils.formatNumber(game.getMaxPlayers()))
                .replace("{theme}", (game.getTheme() == null ? ("§aNenhum") : game.getTheme()))
                .replace("{timeLeft}", SDF.format(game.getTimer() * 1000))
                .replace("{stage}", game.getState() == GameState.INICIANDO ? "§aVotando" : "§aConstruindo")
                .replace("{players}", StringUtils.formatNumber(game.getOnline()))
                .replace("{time}", game.getTimer() == 46 ? Language.scoreboards$time$waiting : Language.scoreboards$time$starting.replace("{time}", StringUtils.formatNumber(game.getTimer())));
          } else {
            line = PlaceholderAPI.setPlaceholders(player, line);
          }
          
          this.add(15 - index, line);
        }
      }
    }.scroller(new ScoreboardScroller(Language.scoreboards$scroller$titles)).to(player).build());
    if (game != null && game.getState() != GameState.AGUARDANDO) {
      profile.getScoreboard().health().updateHealth();
    }
    profile.update();
    profile.getScoreboard().scroll();
  }
  
  private static void setupHotbars() {
    HotbarActionType.addActionType("buildbattle", new BBHotbarActionType());
    
    KConfig config = Main.getInstance().getConfig("hotbar");
    for (String id : new String[] {"lobby", "waiting", "spectator"}) {
      Hotbar hotbar = new Hotbar(id);
      
      ConfigurationSection hb = config.getSection(id);
      for (String button : hb.getKeys(false)) {
        try {
          hotbar.getButtons().add(new HotbarButton(hb.getInt(button + ".slot"), new HotbarAction(hb.getString(button + ".execute")), hb.getString(button + ".icon")));
        } catch (Exception ex) {
          Main.getInstance().getLogger().log(Level.WARNING, "Falha ao carregar o botao \"" + button + "\" da hotbar \"" + id + "\": ", ex);
        }
      }
      
      Hotbar.addHotbar(hotbar);
    }
  }
}
