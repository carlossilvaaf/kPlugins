package dev.slickcollections.kiwizin.buildbattle.game.object;

import dev.slickcollections.kiwizin.buildbattle.Language;
import dev.slickcollections.kiwizin.buildbattle.Main;
import dev.slickcollections.kiwizin.buildbattle.game.BuildBattle;
import dev.slickcollections.kiwizin.buildbattle.game.BuildBattleTeam;
import dev.slickcollections.kiwizin.buildbattle.game.object.runnables.Ingame;
import dev.slickcollections.kiwizin.buildbattle.game.object.runnables.Voting;
import dev.slickcollections.kiwizin.buildbattle.game.object.runnables.Waiting;
import dev.slickcollections.kiwizin.game.GameState;
import dev.slickcollections.kiwizin.player.Profile;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class BuildBattleTask {
  
  private BuildBattle game;
  private BukkitTask task;
  
  public BuildBattleTask(BuildBattle game) {
    this.game = game;
  }
  
  public void cancel() {
    if (this.task != null) {
      this.task.cancel();
      this.task = null;
    }
  }
  
  public void reset() {
    this.cancel();
    this.task = new Waiting(this.game).runTaskTimer(Main.getInstance(), 0, 20);
  }
  
  public void swap(BuildBattleTeam winners) {
    this.cancel();
    if (this.game.getState() == GameState.EMJOGO) {
      this.game.setTimer(Language.options$ingame$time);
      this.game.getWorld().getEntities().stream().filter(entity -> !(entity instanceof Player)).forEach(Entity::remove);
      this.task = new Ingame(this.game).runTaskTimer(Main.getInstance(), 0, 20);
    } else if (this.game.getState() == GameState.INICIANDO) {
      this.game.setTimer(15);
      this.task = new Voting(this.game).runTaskTimer(Main.getInstance(), 0, 20);
    } else if (this.game.getState() == GameState.ENCERRADO) {
      this.game.setTimer(10);
      this.task = new BukkitRunnable() {
        
        @Override
        public void run() {
          if (game.getTimer() == 0) {
            game.listPlayers().forEach(player -> game.leave(Profile.getProfile(player.getName()), null));
            game.reset();
            return;
          }
          
          game.setTimer(game.getTimer() - 1);
        }
      }.runTaskTimer(Main.getInstance(), 0, 20);
    }
  }
}
