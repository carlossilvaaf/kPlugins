package dev.slickcollections.kiwizin.buildbattle.game.object.runnables;

import dev.slickcollections.kiwizin.buildbattle.game.BuildBattle;
import dev.slickcollections.kiwizin.player.Profile;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.List;

public class Voting extends BukkitRunnable {
  
  private BuildBattle game;
  
  public Voting(BuildBattle game) {
    this.game = game;
  }
  
  @Override
  public void run() {
    if (this.game.getTimer() == 0) {
      if (this.game.getActualPlot() >= this.game.listPlayers().size()) {
        this.game.check();
        return;
      }
      this.game.nextVote();
      return;
    }
    
    List<Player> players = this.game.listPlayers();
    players.forEach(player -> {
      Profile.getProfile(player.getName()).update();
    });
    
    this.game.setTimer(game.getTimer() - 1);
  }
  
  @Override
  public synchronized void cancel() throws IllegalStateException {
    super.cancel();
    this.game = null;
  }
}
