package dev.slickcollections.kiwizin.buildbattle.menus.game;

import dev.slickcollections.kiwizin.buildbattle.Main;
import dev.slickcollections.kiwizin.buildbattle.game.BuildBattle;
import dev.slickcollections.kiwizin.buildbattle.game.BuildBattleTeam;
import dev.slickcollections.kiwizin.buildbattle.game.object.PlotManager;
import dev.slickcollections.kiwizin.libraries.menu.PlayerMenu;
import dev.slickcollections.kiwizin.player.Profile;
import dev.slickcollections.kiwizin.utils.BukkitUtils;
import dev.slickcollections.kiwizin.utils.enums.EnumSound;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class MenuSelectClimate extends PlayerMenu {
  
  public MenuSelectClimate(Profile profile) {
    super(profile.getPlayer(), "Clima da Plot", 5);
    
    this.setItem(12, BukkitUtils.deserializeItemStack("326 : 1 : nome>&aChuvoso"));
    this.setItem(14, BukkitUtils.deserializeItemStack("175 : 1 : nome>&aEnsolarado"));
    
    this.setItem(40, BukkitUtils.deserializeItemStack("INK_SACK:1 : 1 : nome>&cVoltar"));
    
    this.register(Main.getInstance());
    this.open();
  }
  
  @EventHandler
  public void onInventoryClick(InventoryClickEvent evt) {
    if (evt.getInventory().equals(this.getInventory())) {
      evt.setCancelled(true);
      
      if (evt.getWhoClicked().equals(this.player)) {
        Profile profile = Profile.getProfile(this.player.getName());
        if (profile == null) {
          this.player.closeInventory();
          return;
        }
        
        if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getInventory())) {
          ItemStack item = evt.getCurrentItem();
          BuildBattleTeam team = profile.getGame(BuildBattle.class).getTeam(this.player);
          PlotManager manager = team.getManager();
          
          if (item != null && item.getType() != Material.AIR) {
            if (evt.getSlot() == 40) {
              EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
              new MenuSettings(profile);
            } else if (evt.getSlot() == 12) {
              EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
              manager.changeWeather(this.player, "DOWNFALL");
              manager.applyTo(team.listPlayers());
              player.sendMessage("§aClima alterado para: " + item.getItemMeta().getDisplayName());
            } else if (evt.getSlot() == 14) {
              EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
              manager.changeWeather(this.player, "CLEAR");
              manager.applyTo(team.listPlayers());
              player.sendMessage("§aClima alterado para: " + item.getItemMeta().getDisplayName());
            }
          }
        }
      }
    }
  }
  
  public void cancel() {
    HandlerList.unregisterAll(this);
  }
  
  @EventHandler
  public void onPlayerQuit(PlayerQuitEvent evt) {
    if (evt.getPlayer().equals(this.player)) {
      this.cancel();
    }
  }
  
  @EventHandler
  public void onInventoryClose(InventoryCloseEvent evt) {
    if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getInventory())) {
      this.cancel();
    }
  }
}
