package dev.slickcollections.kiwizin.buildbattle.game.object;

import org.bukkit.Material;

public class BuildBattleBlock {
  
  private Material material;
  private byte data;
  
  public BuildBattleBlock(Material material, byte data) {
    this.material = material;
    this.data = data;
  }
  
  public Material getMaterial() {
    return this.material;
  }
  
  public byte getData() {
    return this.data;
  }
  
  @Override
  public String toString() {
    return "BuildBattleBlock{material=" + material + ", data=" + data + "}";
  }
}
