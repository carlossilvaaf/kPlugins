package dev.slickcollections.kiwizin.buildbattle.hook.hotbar;

import dev.slickcollections.kiwizin.buildbattle.game.BuildBattle;
import dev.slickcollections.kiwizin.buildbattle.menus.MenuLobbies;
import dev.slickcollections.kiwizin.buildbattle.menus.MenuPlay;
import dev.slickcollections.kiwizin.player.Profile;
import dev.slickcollections.kiwizin.player.hotbar.HotbarActionType;
import dev.slickcollections.kiwizin.utils.enums.EnumSound;

public class BBHotbarActionType extends HotbarActionType {
  
  @Override
  public void execute(Profile profile, String action) {
    if (action.equalsIgnoreCase("loja")) {
      EnumSound.ENDERMAN_TELEPORT.play(profile.getPlayer(), 1.0F, 1.0F);
      profile.getPlayer().sendMessage("§cEm breve.");
 //     new MenuShop(profile);
    } else if (action.equalsIgnoreCase("lobbies")) {
      new MenuLobbies(profile);
    } else if (action.equalsIgnoreCase("jogar")) {
      BuildBattle game = profile.getGame(BuildBattle.class);
      if (game != null) {
        new MenuPlay(profile, game.getMode());
      }
    } else if (action.equalsIgnoreCase("sair")) {
      BuildBattle game = profile.getGame(BuildBattle.class);
      if (game != null) {
        game.leave(profile, null);
      }
    }
  }
}
