package dev.slickcollections.kiwizin.buildbattle.cmd.bb;

import dev.slickcollections.kiwizin.buildbattle.Main;
import dev.slickcollections.kiwizin.buildbattle.cmd.SubCommand;
import dev.slickcollections.kiwizin.buildbattle.game.BuildBattle;
import dev.slickcollections.kiwizin.buildbattle.game.enums.BuildBattleMode;
import dev.slickcollections.kiwizin.player.Profile;
import dev.slickcollections.kiwizin.player.hotbar.Hotbar;
import dev.slickcollections.kiwizin.plugin.config.KConfig;
import dev.slickcollections.kiwizin.utils.BukkitUtils;
import dev.slickcollections.kiwizin.utils.CubeID;
import dev.slickcollections.kiwizin.utils.StringUtils;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CreateCommand extends SubCommand {
  
  public static final Map<Player, Object[]> CREATING = new HashMap<>();
  
  public CreateCommand() {
    super("criar", "criar [solo/dupla] [nome]", "Criar uma sala.", true);
  }
  
  @Override
  public void perform(Player player, String[] args) {
    if (BuildBattle.getByWorldName(player.getWorld().getName()) != null) {
      player.sendMessage("§cJá existe uma sala neste mundo.");
      return;
    }
    
    if (args.length <= 1) {
      player.sendMessage("§cUtilize /bb " + this.getUsage());
      return;
    }
  
    BuildBattleMode mode = BuildBattleMode.fromName(args[0]);
    if (mode == null) {
      player.sendMessage("§cUtilize /bb " + this.getUsage());
      return;
    }
    
    String name = StringUtils.join(args, 1, " ");
    Object[] array = new Object[6];
    array[0] = player.getWorld();
    array[1] = name;
    array[2] = mode.name();
    CREATING.put(player, array);
    
    player.getInventory().clear();
    player.getInventory().setArmorContents(null);
    
    player.getInventory().setItem(0, BukkitUtils.deserializeItemStack("BLAZE_ROD : 1 : nome>&aCuboID da Arena"));
    player.getInventory().setItem(1, BukkitUtils.deserializeItemStack("STAINED_CLAY:13 : 1 : nome>&aConfirmar"));
    player.getInventory().setItem(4, BukkitUtils.deserializeItemStack("BEACON : 1 : nome>&aLocal de Espera"));
    
    player.updateInventory();
    
    Profile.getProfile(player.getName()).setHotbar(null);
  }
  
  public static void handleClick(Profile profile, String display, PlayerInteractEvent evt) {
    Player player = profile.getPlayer();
    
    switch (display) {
      case "§aCuboID da Arena": {
        evt.setCancelled(true);
        if (evt.getAction() == Action.LEFT_CLICK_BLOCK) {
          CREATING.get(player)[3] = evt.getClickedBlock().getLocation();
          player.sendMessage("§aBorda da Arena 1 setada.");
        } else if (evt.getAction() == Action.RIGHT_CLICK_BLOCK) {
          CREATING.get(player)[4] = evt.getClickedBlock().getLocation();
          player.sendMessage("§aBorda da Arena 2 setada.");
        } else {
          player.sendMessage("§cClique em um bloco.");
        }
        break;
      }
      case "§aLocal de Espera": {
        evt.setCancelled(true);
        Location location = player.getLocation().getBlock().getLocation().clone().add(.5, 0, .5);
        location.setYaw(player.getLocation().getYaw());
        location.setPitch(player.getLocation().getPitch());
        CREATING.get(player)[5] = BukkitUtils.serializeLocation(location);
        player.sendMessage("§aLocal de espera adicionado!");        break;
      }
      case "§aConfirmar": {
        evt.setCancelled(true);
        if (CREATING.get(player)[3] == null) {
          player.sendMessage("§cBorda da Arena 1 não setada.");
          return;
        }
        
        if (CREATING.get(player)[4] == null) {
          player.sendMessage("§cBorda da Arena 2 não setada.");
          return;
        }
        
        if (CREATING.get(player)[5] == null) {
          player.sendMessage("§cLocal de Espera não setado.");
          return;
        }
        
        Object[] array = CREATING.get(player);
        World world = player.getWorld();
        KConfig config = Main.getInstance().getConfig("arenas", world.getName());
        player.getInventory().clear();
        player.getInventory().setArmorContents(null);
        player.updateInventory();
        CREATING.remove(player);
        player.sendMessage("§aCriando sala...");
        
        CubeID cube = new CubeID((Location) array[3], (Location) array[4]);
        config.set("name", array[1]);
        config.set("mode", array[2]);
        config.set("minPlayers", 4);
        config.set("cubeId", cube.toString());
        config.set("waitingLocation", array[5]);
        config.set("spawns", new ArrayList<>());
        world.save();
        
        player.sendMessage("§aCriando backup do mapa...");
        Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> {
          Main.getInstance().getFileUtils().copyFiles(new File(world.getName()), new File("plugins/kBuildBattle/mundos/" + world.getName()), "playerdata", "stats", "uid.dat");
          
          profile.setHotbar(Hotbar.getHotbarById("lobby"));
          profile.refresh();
          BuildBattle.load(config.getFile(), () -> player.sendMessage("§aSala criada com sucesso."));
        }, 60);
        break;
      }
    }
  }
}
