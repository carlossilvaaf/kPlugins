package dev.slickcollections.kiwizin.buildbattle.game;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.slickcollections.kiwizin.buildbattle.game.object.PlotManager;
import dev.slickcollections.kiwizin.game.GameTeam;
import dev.slickcollections.kiwizin.utils.CubeID;
import org.bukkit.Material;
import org.bukkit.block.Block;

public class BuildBattleTeam extends GameTeam {
  
  private final int index;
  
  protected PlotManager manager;
  protected CubeID cubeId;
  protected CubeID cubeIdDown;
  
  public BuildBattleTeam(BuildBattle game, String serialized, int size) {
    super(game, new JsonParser().parse(serialized).getAsJsonObject().get("spawn").getAsString(), size);
    this.index = game.listTeams().size();
  
    JsonObject team = new JsonParser().parse(serialized).getAsJsonObject();
    this.manager = new PlotManager(this);
    this.cubeIdDown = new CubeID(team.get("cubeIdDown").getAsString());
    this.cubeId = new CubeID(team.get("cubeId").getAsString());
  }
  
  public CubeID getCubeIdDown() { return this.cubeIdDown; }
  
  public PlotManager getManager() {
    return this.manager;
  }
  
  @Override
  public void reset() {
    super.reset();
  }
  
  public CubeID getCubeId() {
    return this.cubeId;
  }
}
