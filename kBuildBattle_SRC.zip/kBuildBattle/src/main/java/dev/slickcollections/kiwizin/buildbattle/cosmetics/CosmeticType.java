package dev.slickcollections.kiwizin.buildbattle.cosmetics;

public enum CosmeticType {
 //  CLOTHES("Roupas"),
  HAT("Chapéus"),
  WIN_ANIMATION("Comemorações de Vitória");
  
  private String[] names;
  
  CosmeticType(String... names) {
    this.names = names;
  }
  
  public String getName(long index) {
    return this.names[(int) (index - 1)];
  }
}
