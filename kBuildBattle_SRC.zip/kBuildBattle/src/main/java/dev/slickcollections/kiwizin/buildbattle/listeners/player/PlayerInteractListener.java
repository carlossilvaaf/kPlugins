package dev.slickcollections.kiwizin.buildbattle.listeners.player;

import dev.slickcollections.kiwizin.Core;
import dev.slickcollections.kiwizin.buildbattle.cmd.bb.BuildCommand;
import dev.slickcollections.kiwizin.buildbattle.cmd.bb.CreateCommand;
import dev.slickcollections.kiwizin.buildbattle.cmd.bb.SpawnCommand;
import dev.slickcollections.kiwizin.buildbattle.game.BuildBattle;
import dev.slickcollections.kiwizin.buildbattle.game.BuildBattleTeam;
import dev.slickcollections.kiwizin.buildbattle.game.enums.BuildBattleMode;
import dev.slickcollections.kiwizin.buildbattle.game.object.Vote;
import dev.slickcollections.kiwizin.buildbattle.menus.MenuPlay;
import dev.slickcollections.kiwizin.buildbattle.menus.MenuStatsNPC;
import dev.slickcollections.kiwizin.buildbattle.menus.game.MenuSettings;
import dev.slickcollections.kiwizin.game.GameState;
import dev.slickcollections.kiwizin.libraries.npclib.api.event.NPCRightClickEvent;
import dev.slickcollections.kiwizin.libraries.npclib.api.npc.NPC;
import dev.slickcollections.kiwizin.menus.MenuDeliveries;
import dev.slickcollections.kiwizin.player.Profile;
import dev.slickcollections.kiwizin.utils.enums.EnumSound;
import net.minecraft.server.v1_8_R3.DamageSource;
import org.bukkit.Material;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.ItemStack;

import java.util.stream.Collectors;

import static dev.slickcollections.kiwizin.buildbattle.cmd.bb.CreateCommand.CREATING;
import static dev.slickcollections.kiwizin.buildbattle.cmd.bb.SpawnCommand.SPAWN;

public class PlayerInteractListener implements Listener {
  
  @EventHandler
  public void onNPCLeftClick(NPCRightClickEvent evt) {
    Player player = evt.getPlayer();
    Profile profile = Profile.getProfile(player.getName());
    
    if (profile != null) {
      NPC npc = evt.getNPC();
      BuildBattle game = profile.getGame(BuildBattle.class);
      if (npc.data().has("play-npc")) {
        BuildBattleMode mode = BuildBattleMode.fromName(npc.data().get("play-npc"));
        if (mode != null) {
          new MenuPlay(profile, mode);
        }
      } else if (npc.data().has("delivery-npc")) {
        new MenuDeliveries(profile);
      } else if (npc.data().has("stats-npc")) {
        new MenuStatsNPC(profile);
      }
    }
  }
  
  
  @EventHandler(priority = EventPriority.LOWEST)
  public void onPlayerInteract(PlayerInteractEvent evt) {
    Player player = evt.getPlayer();
    Profile profile = Profile.getProfile(player.getName());

    if (profile != null) {
      if (CREATING.containsKey(player) && CREATING.get(player)[0].equals(player.getWorld())) {
        ItemStack item = player.getItemInHand();
        if (item != null && item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
          CreateCommand.handleClick(profile, item.getItemMeta().getDisplayName(), evt);
        }
      } else if (SPAWN.containsKey(player) && ((BuildBattle) SPAWN.get(player)[0]).getWorld().equals(player.getWorld())) {
        ItemStack item = player.getItemInHand();
        if (item != null && item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
          SpawnCommand.handleClick(profile, item.getItemMeta().getDisplayName(), evt);
        }
      }
      
      BuildBattle game = profile.getGame(BuildBattle.class);
      ItemStack item = player.getItemInHand();
      if (game != null && game.getState() == GameState.EMJOGO && item != null && item.getType() == Material.NETHER_STAR) {
        new MenuSettings(profile);
        evt.setCancelled(true);
        return;
      }
      if (game == null && !BuildCommand.hasBuilder(player)) {
        evt.setCancelled(true);
      } else if (game != null && (game.getState() != GameState.EMJOGO || game.isSpectator(player))) {
        player.updateInventory();
        evt.setCancelled(true);
        if (game.getState() == GameState.INICIANDO && item != null && item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
          BuildBattleTeam votingTeam = game.listTeams().get(game.getActualPlot() - 1);
          String name = item.getItemMeta().getDisplayName();
          if (item.getType().name().contains("CLAY")) {
            game.removeVote(votingTeam, player);
            if (name.contains("PÉSSIMO")) {
              game.addVote(votingTeam, player, 1L);
            } else if (name.contains("RUIM")) {
              game.addVote(votingTeam, player, 2L);
            } else if (name.contains("ACEITÁVEL")) {
              game.addVote(votingTeam, player, 3L);
            } else if (name.contains("BOM")) {
              game.addVote(votingTeam, player, 4L);
            } else if (name.contains("ÉPICO")) {
              game.addVote(votingTeam, player, 5L);
            } else if (name.contains("LENDÁRIO")) {
              game.addVote(votingTeam, player, 6L);
            }
            player.sendMessage("§e§lVocê votou: " + item.getItemMeta().getDisplayName());
          }
        } else {
          evt.setCancelled(true);
        }
      }
    }
  }
  
  @EventHandler
  public void onPlayerMove(PlayerMoveEvent evt) {
    if (evt.getTo().getBlockY() != evt.getFrom().getBlockY() && evt.getTo().getBlockY() < 0) {
      Player player = evt.getPlayer();
      Profile profile = Profile.getProfile(player.getName());
      
      if (profile != null) {
        BuildBattle game = profile.getGame(BuildBattle.class);
        if (game == null) {
          player.teleport(Core.getLobby());
        } else {
          if (game.getState() != GameState.EMJOGO || game.isSpectator(player)) {
            player.teleport(game.getCubeId().getCenterLocation());
          } else if (game.getState() == GameState.EMJOGO && !game.isSpectator(player)) {
            player.teleport(game.getTeam(player).getLocation());
          } else {
            ((CraftPlayer) player).getHandle().damageEntity(DamageSource.OUT_OF_WORLD, (float) player.getMaxHealth());
          }
        }
      }
    }
  }
}
