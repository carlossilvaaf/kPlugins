package dev.slickcollections.kiwizin.buildbattle.game.enums;

public enum BuildBattleMode {
  SOLO(1, "Solo"),
  DUPLA(2, "Duplas");
  
  private int size;
  private String name;
  
  BuildBattleMode(int size, String name) {
    this.size = size;
    this.name = name;
  }
  
  public int getSize() {
    return this.size;
  }
  
  public String getName() {
    return this.name;
  }
  
  private static final BuildBattleMode[] VALUES = values();
  
  public static BuildBattleMode fromName(String name) {
    for (BuildBattleMode mode : VALUES) {
      if (name.equalsIgnoreCase(mode.name())) {
        return mode;
      }
    }
    
    return null;
  }
}
