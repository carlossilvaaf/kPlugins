package dev.slickcollections.kiwizin.buildbattle.game.object;

import dev.slickcollections.kiwizin.Core;
import dev.slickcollections.kiwizin.buildbattle.game.BuildBattleTeam;
import org.bukkit.Material;
import org.bukkit.WeatherType;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

import java.util.Iterator;
import java.util.List;

public class PlotManager {
  
  protected BuildBattleTeam team;
  protected String timeType, weatherType;
  
  public PlotManager(BuildBattleTeam bt) {
    this.team = bt;
    this.timeType = "dia";
    this.weatherType = "CLEAR";
  }
  
  public void changeDown(Material block, byte data) {
    Iterator<Block> iterator = team.getCubeIdDown().iterator();
    int count = 0;
    while (iterator.hasNext() && count < 50000) {
      Block b = iterator.next();
      b.setType(block);
      count++;
    }
  }

  public void changeTiming(Player player, String type) {
    this.timeType = type;
    player.setPlayerTime(type.equals("dia") ? 1000 : type.equals("amanhecer") ? 0 : type.equals("anoitecer") ? 12000 : 13000, true);
  }
  
  public void changeWeather(Player player, String type) {
    try {
      this.weatherType = type;
      player.setPlayerWeather(WeatherType.valueOf(type));
    } catch (Exception ex) {
      Core.getInstance().getLogger().warning("O tipo de chuva " + type + " e invalido.");
    }
  }
  
  public void applyTo(List<Player> showTo) {
    showTo.forEach(a -> { this.changeWeather(a, this.weatherType); this.changeTiming(a, this.timeType); });
  }
}
