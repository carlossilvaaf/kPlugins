package dev.slickcollections.kiwizin.buildbattle.listeners.entity;

import dev.slickcollections.kiwizin.Core;
import dev.slickcollections.kiwizin.buildbattle.game.BuildBattle;
import dev.slickcollections.kiwizin.game.GameState;
import dev.slickcollections.kiwizin.player.Profile;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;

public class EntityListener implements Listener {
  
  @EventHandler(priority = EventPriority.HIGH)
  public void onEntityDamageByEntity(EntityDamageByEntityEvent evt) {
    evt.setCancelled(true);
  }
  
  @EventHandler
  public void onEntityDamage(EntityDamageEvent evt) {
    if (evt.getEntity() instanceof Player) {
      Player player = (Player) evt.getEntity();
      Profile profile = Profile.getProfile(player.getName());
      if (profile != null) {
        BuildBattle game = profile.getGame(BuildBattle.class);
        if (game == null) {
          evt.setCancelled(true);
          if (evt.getCause() == EntityDamageEvent.DamageCause.VOID) {
            player.teleport(Core.getLobby());
          }
        } else {
          if (game.getState() == GameState.AGUARDANDO || game.getState() == GameState.ENCERRADO || game.getState() == GameState.EMJOGO) {
            evt.setCancelled(true);
          } else if (game.isSpectator(player)) {
            evt.setCancelled(true);
          } else if (player.getNoDamageTicks() > 0 && evt.getCause() == EntityDamageEvent.DamageCause.FALL) {
            evt.setCancelled(true);
          } else if (evt.getCause() == EntityDamageEvent.DamageCause.VOID) {
            evt.setDamage(player.getMaxHealth());
          }
        }
      }
    }
  }
  
  @EventHandler
  public void onFoodLevelChange(FoodLevelChangeEvent evt) {
    evt.setCancelled(true);
  }
}
