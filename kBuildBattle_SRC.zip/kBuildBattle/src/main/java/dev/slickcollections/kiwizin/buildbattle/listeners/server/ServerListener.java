package dev.slickcollections.kiwizin.buildbattle.listeners.server;

import dev.slickcollections.kiwizin.buildbattle.game.BuildBattle;
import dev.slickcollections.kiwizin.game.GameState;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.LeavesDecayEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.weather.WeatherChangeEvent;

public class ServerListener implements Listener {
  
  @EventHandler
  public void onBlockIgnite(BlockIgniteEvent evt) {
    BuildBattle game = BuildBattle.getByWorldName(evt.getBlock().getWorld().getName());
    if (game == null || game.getState() != GameState.EMJOGO || game.isPlacedBlock(evt.getBlock())) {
      evt.setCancelled(true);
    }
  }
  
  @EventHandler
  public void onBlockBurn(BlockBurnEvent evt) {
    BuildBattle game = BuildBattle.getByWorldName(evt.getBlock().getWorld().getName());
    if (game == null || game.getState() != GameState.EMJOGO || game.isPlacedBlock(evt.getBlock())) {
      evt.setCancelled(true);
    }
  }
  
  @EventHandler
  public void onBlockExplode(BlockExplodeEvent evt) {
    evt.setCancelled(true);
  }
  
  @EventHandler
  public void onLeavesDecay(LeavesDecayEvent evt) {
    evt.setCancelled(true);
  }
  
  @EventHandler
  public void onEntityExplode(EntityExplodeEvent evt) {
    evt.setCancelled(true);
  }
  
  @EventHandler
  public void onWeatherChange(WeatherChangeEvent evt) {
    evt.setCancelled(evt.toWeatherState());
  }
}