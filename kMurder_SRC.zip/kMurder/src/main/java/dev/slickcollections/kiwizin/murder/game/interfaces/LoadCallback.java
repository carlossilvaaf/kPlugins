package dev.slickcollections.kiwizin.murder.game.interfaces;

public interface LoadCallback {
  void finish();
}
