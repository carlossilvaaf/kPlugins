package tk.kiwicollections.kiwizin.utils.utils;

public enum SliceChecker {
    STARTING, CHECKING;
}
