package dev.slickcollections.kiwizin.cash;

public class CashException extends Exception {
  
  private static final long serialVersionUID = 1L;
  
  public CashException(String msg) {
    super(msg);
  }
}
