package dev.slickcollections.kiwizin.servers.balancer.elements;

public interface NumberConnection {
  
  int getActualNumber();
  
  int getMaxNumber();
}
