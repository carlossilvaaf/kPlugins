package dev.slickcollections.kiwizin.hook;

public class FriendsHook {
  
  public static boolean isFriend(String player, String friend) {
    return false;
  }
  
  public static boolean isBlacklisted(String player, String blacklisted) {
    return false;
  }
}