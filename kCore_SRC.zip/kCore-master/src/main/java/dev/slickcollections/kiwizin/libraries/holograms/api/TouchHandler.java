package dev.slickcollections.kiwizin.libraries.holograms.api;

import org.bukkit.entity.Player;

public interface TouchHandler {
  
  void onTouch(Player player);
}
