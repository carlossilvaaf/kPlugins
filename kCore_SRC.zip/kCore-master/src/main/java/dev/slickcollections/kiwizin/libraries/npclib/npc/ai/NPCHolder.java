package dev.slickcollections.kiwizin.libraries.npclib.npc.ai;

import dev.slickcollections.kiwizin.libraries.npclib.api.npc.NPC;

public interface NPCHolder {
  
  NPC getNPC();
}
