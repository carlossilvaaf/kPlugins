package dev.slickcollections.kiwizin.servers.balancer.elements;

public interface LoadBalancerObject {
  
  boolean canBeSelected();
}
