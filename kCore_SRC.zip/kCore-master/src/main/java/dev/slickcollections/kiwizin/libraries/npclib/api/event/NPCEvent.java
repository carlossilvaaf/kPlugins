package dev.slickcollections.kiwizin.libraries.npclib.api.event;

import org.bukkit.event.Event;

public abstract class NPCEvent extends Event {
}
