/*    */ package tk.kiwicollections.kiwizin.tell;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import net.md_5.bungee.api.connection.ProxiedPlayer;
/*    */ import net.md_5.bungee.api.plugin.Plugin;
/*    */ import tk.kiwicollections.kiwizin.tell.cmd.Commands;
/*    */ 
/*    */ public class Main
/*    */   extends Plugin
/*    */ {
/*    */   private static Main instance;
/* 12 */   public static HashMap<ProxiedPlayer, ProxiedPlayer> reply = new HashMap<ProxiedPlayer, ProxiedPlayer>();
/*    */   
/*    */   public Main() {
/* 15 */     instance = this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 21 */     Commands.setupCommands();
/*    */     
/* 23 */     getLogger().info("O plugin foi ativado.");
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 28 */     getLogger().info("O plugin foi desativado.");
/*    */   }
/*    */   
/*    */   public static Main getInstance() {
/* 32 */     return instance;
/*    */   }
/*    */ }


/* Location:              C:\Users\JOÃO E TONY\Desktop\kTell.jar!\tk\kiwicollections\kiwizin\tell\Main.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */