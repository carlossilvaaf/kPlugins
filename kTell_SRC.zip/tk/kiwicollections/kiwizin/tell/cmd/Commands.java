/*    */ package tk.kiwicollections.kiwizin.tell.cmd;
/*    */ 
/*    */ import net.md_5.bungee.api.CommandSender;
/*    */ import net.md_5.bungee.api.ProxyServer;
/*    */ import net.md_5.bungee.api.plugin.Command;
/*    */ import net.md_5.bungee.api.plugin.Plugin;
/*    */ import tk.kiwicollections.kiwizin.tell.Main;
/*    */ 
/*    */ public abstract class Commands extends Command {
/*    */   public Commands(String name, String... aliases) {
/* 11 */     super(name, null, aliases);
/* 12 */     ProxyServer.getInstance().getPluginManager().registerCommand((Plugin)Main.getInstance(), this);
/*    */   }
/*    */ 
/*    */   
/*    */   public abstract void perform(CommandSender paramCommandSender, String[] paramArrayOfString);
/*    */   
/*    */   public void execute(CommandSender sender, String[] args) {
/* 19 */     perform(sender, args);
/*    */   }
/*    */   
/*    */   public static void setupCommands() {
/* 23 */     new TellCommand();
/* 24 */     new ReplyCommand();
/*    */   }
/*    */ }


/* Location:              C:\Users\JOÃO E TONY\Desktop\kTell.jar!\tk\kiwicollections\kiwizin\tell\cmd\Commands.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */