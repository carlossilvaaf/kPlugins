/*    */ package tk.kiwicollections.kiwizin.tell.cmd;
/*    */ 
/*    */ import net.md_5.bungee.api.CommandSender;
/*    */ import net.md_5.bungee.api.ProxyServer;
/*    */ import net.md_5.bungee.api.chat.TextComponent;
/*    */ import net.md_5.bungee.api.connection.ProxiedPlayer;
/*    */ import tk.kiwicollections.kiwizin.tell.Main;
/*    */ import tk.slicecollections.maxteer.player.role.Role;
/*    */ import tk.slicecollections.maxteer.utils.StringUtils;
/*    */ 
/*    */ public class TellCommand
/*    */   extends Commands {
/*    */   public TellCommand() {
/* 14 */     super("tell", new String[] { "whisper" });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void perform(CommandSender sender, String[] args) {
/* 20 */     if (!(sender instanceof ProxiedPlayer)) {
/* 21 */       sender.sendMessage(TextComponent.fromLegacyText("§cApenas jogadores podem utilizar este comando."));
/*    */       
/*    */       return;
/*    */     } 
/* 25 */     ProxiedPlayer player = (ProxiedPlayer)sender;
/* 26 */     if (args.length <= 1) {
/* 27 */       player.sendMessage(TextComponent.fromLegacyText("§cUtilize /tell [jogador] [mensangem]"));
/*    */       return;
/*    */     } 
/* 30 */     ProxiedPlayer target = ProxyServer.getInstance().getPlayer(args[0]);
/* 31 */     if (target == player) {
/* 32 */       player.sendMessage(TextComponent.fromLegacyText("§cVocê não pode mandar mensagens privadas para sí mesmo."));
/*    */       return;
/*    */     } 
/* 35 */     if (target == null) {
/* 36 */       player.sendMessage(TextComponent.fromLegacyText("§cUsuário não encontrado."));
/*    */       return;
/*    */     } 
/* 39 */     if (Main.reply.get(player) != null) {
/* 40 */       Main.reply.remove(player);
/*    */     }
/* 42 */     if (Main.reply.get(target) != null) {
/* 43 */       Main.reply.remove(target);
/*    */     }
/* 45 */     Main.reply.put(player, target);
/* 46 */     Main.reply.put(target, player);
/* 47 */     target.sendMessage(TextComponent.fromLegacyText("§8Mensagem de " + Role.getPrefixed(player.getName()) + "§8:§6 " + StringUtils.join((Object[])args, 1, " ").replace("&", player.hasPermission("ktell.color") ? "§" : "&")));
/* 48 */     player.sendMessage(TextComponent.fromLegacyText("§8Mensagem para " + Role.getPrefixed(target.getName()) + "§8:§6 " + StringUtils.join((Object[])args, 1, " ").replace("&", player.hasPermission("ktell.color") ? "§" : "&")));
/*    */   }
/*    */ }


/* Location:              C:\Users\JOÃO E TONY\Desktop\kTell.jar!\tk\kiwicollections\kiwizin\tell\cmd\TellCommand.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */