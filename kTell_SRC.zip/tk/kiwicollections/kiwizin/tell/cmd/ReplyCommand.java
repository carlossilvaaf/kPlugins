/*    */ package tk.kiwicollections.kiwizin.tell.cmd;
/*    */ 
/*    */ import net.md_5.bungee.api.CommandSender;
/*    */ import net.md_5.bungee.api.chat.TextComponent;
/*    */ import net.md_5.bungee.api.connection.ProxiedPlayer;
/*    */ import tk.kiwicollections.kiwizin.tell.Main;
/*    */ import tk.slicecollections.maxteer.player.role.Role;
/*    */ import tk.slicecollections.maxteer.utils.StringUtils;
/*    */ 
/*    */ public class ReplyCommand
/*    */   extends Commands
/*    */ {
/*    */   public ReplyCommand() {
/* 14 */     super("r", new String[] { "reply" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void perform(CommandSender sender, String[] args) {
/* 19 */     if (!(sender instanceof ProxiedPlayer)) {
/* 20 */       sender.sendMessage(TextComponent.fromLegacyText("§cApenas jogadores podem utilizar este comando."));
/*    */       
/*    */       return;
/*    */     } 
/* 24 */     ProxiedPlayer player = (ProxiedPlayer)sender;
/* 25 */     if (args.length == 0) {
/* 26 */       player.sendMessage(TextComponent.fromLegacyText("§cUtilize /r [mensagem]"));
/*    */       return;
/*    */     } 
/* 29 */     ProxiedPlayer target = (ProxiedPlayer)Main.reply.get(player);
/* 30 */     if (target == null) {
/* 31 */       player.sendMessage(TextComponent.fromLegacyText("§cVocê não tem ninguém para responder."));
/*    */       return;
/*    */     } 
/* 34 */     if (!target.isConnected()) {
/* 35 */       player.sendMessage(TextComponent.fromLegacyText("§cJogador offline."));
/*    */       return;
/*    */     } 
/* 38 */     target.sendMessage(TextComponent.fromLegacyText("§8Mensagem de " + Role.getPrefixed(player.getName()) + "§8:§6 " + StringUtils.join((Object[])args, " ").replace("&", player.hasPermission("ktell.color") ? "§" : "&")));
/* 39 */     player.sendMessage(TextComponent.fromLegacyText("§8Mensagem para " + Role.getPrefixed(target.getName()) + "§8:§6 " + StringUtils.join((Object[])args, " ").replace("&", player.hasPermission("ktell.color") ? "§" : "&")));
/*    */   }
/*    */ }


/* Location:              C:\Users\JOÃO E TONY\Desktop\kTell.jar!\tk\kiwicollections\kiwizin\tell\cmd\ReplyCommand.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */