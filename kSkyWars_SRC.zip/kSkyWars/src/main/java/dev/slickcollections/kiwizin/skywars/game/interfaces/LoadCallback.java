package dev.slickcollections.kiwizin.skywars.game.interfaces;

public interface LoadCallback {
  void finish();
}
