package dev.slickcollections.kiwizin.skywars.nms.interfaces;

import org.bukkit.entity.Entity;

public interface BalloonEntity {
  
  void kill();
  
  Entity getBukkitEntity();
}
